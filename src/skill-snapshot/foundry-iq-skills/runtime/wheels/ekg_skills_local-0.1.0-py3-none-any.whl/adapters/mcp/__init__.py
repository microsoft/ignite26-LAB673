"""Harness transport adapters."""
