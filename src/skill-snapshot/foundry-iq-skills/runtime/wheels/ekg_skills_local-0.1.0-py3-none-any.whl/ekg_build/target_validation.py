from __future__ import annotations

import re
from dataclasses import replace

from ekg_core.models import BuildSpec, OntologyMode

GRAPH_MODEL_POLICY_VERSION = "search-model-name-2026-10-16"
_CHAT_MODELS = frozenset({
    "gpt-4o", "gpt-4o-mini", "gpt-4.1", "gpt-4.1-mini", "gpt-4.1-nano",
    "gpt-5", "gpt-5-mini", "gpt-5-nano", "gpt-5.1", "gpt-5.2",
    "gpt-5.4", "gpt-5.4-mini", "gpt-5.4-nano", "gpt-5.5",
    "gpt-5.6-sol", "gpt-5.6-terra", "gpt-5.6-luna",
})
_NOVEMBER_MODELS = frozenset({"gpt-6-astra", "gpt-6-sol", "gpt-6-luna", "gpt-6.1-sol"})

# Reviewed model capabilities, not Search defaults. Each model's reference is at
# https://developers.openai.com/api/docs/models/<model-name>.
_CHAT_OUTPUT_LIMITS = {
    "gpt-4o": 16_384, "gpt-4o-mini": 16_384,
    "gpt-4.1": 32_768, "gpt-4.1-mini": 32_768, "gpt-4.1-nano": 32_768,
    "gpt-5": 128_000, "gpt-5-mini": 128_000, "gpt-5-nano": 128_000,
}


def new_build_spec(spec: BuildSpec) -> BuildSpec:
    """Bind concrete defaults when constructing a new extraction plan.

    Reading stored specs and planning/reconciling their exact identities must not
    call this constructor. Explicit settings remain unchanged.
    """
    if spec.ontology_mode is OntologyMode.NONE:
        return spec
    if not spec.chat_model:
        # Incomplete plans remain blocked by the existing explicit-model prerequisite.
        return spec
    if spec.extraction_parallelism is None:
        from .managed_pipeline import DEFAULT_EXTRACTION_PARALLELISM

        spec = replace(spec, extraction_parallelism=DEFAULT_EXTRACTION_PARALLELISM)
    if spec.extraction_max_tokens is not None:
        return spec
    maximum = _CHAT_OUTPUT_LIMITS.get(spec.chat_model or "")
    if maximum is None:
        raise ValueError(
            f"MODEL_OUTPUT_LIMIT_UNKNOWN: no verified maximum for {spec.chat_model!r}; "
            "supply --chat-model and an explicit --extraction-max-tokens from its "
            "documented capability before planning. No service-default fallback is used.")
    return replace(spec, extraction_max_tokens=maximum)


def graph_model_error(spec: BuildSpec) -> str | None:
    from .managed_pipeline import search_api_version

    version = search_api_version(spec)
    # AzureOpenAIParameters.modelName has API-versioned AllowedValues.
    supported = {
        "2026-08-01-preview": _CHAT_MODELS,
        "2026-11-01-preview": _CHAT_MODELS | _NOVEMBER_MODELS,
    }.get(version, frozenset())
    if spec.chat_model and spec.chat_model not in supported:
        return (f"GRAPH_MODEL_UNSUPPORTED: chat model {spec.chat_model!r} is not admitted "
                f"by the pinned Search {version} model-name policy; choose a documented model "
                "for this API and create a new plan before uploading")
    return None


def search_resource_id(spec: BuildSpec) -> str:
    target = spec.target
    endpoint = target.search_endpoint or ""
    match = re.fullmatch(r"https://([a-z0-9][a-z0-9-]{0,58}[a-z0-9])\.search\.windows\.net", endpoint)
    if (
        not match
        or not isinstance(target.subscription_id, str)
        or not re.fullmatch(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}",
                            target.subscription_id)
        or not isinstance(target.resource_group, str)
        or not re.fullmatch(r"[a-zA-Z0-9_.()\-]{1,90}", target.resource_group)
    ):
        raise ValueError("managed graph requires an exact Search service endpoint, subscription and RG")
    return (
        f"/subscriptions/{target.subscription_id}/resourceGroups/{target.resource_group}"
        f"/providers/Microsoft.Search/searchServices/{match.group(1)}"
    )


def graph_input_error(spec: BuildSpec) -> str | None:
    try:
        search_resource_id(spec)
    except ValueError:
        return "GRAPH_TARGET_INVALID: exact Search endpoint, subscription and resource group are required"
    if not isinstance(spec.tenant_id, str) or not re.fullmatch(
        r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", spec.tenant_id
    ):
        return "TENANT_REQUIRED: explicit tenant_id is required for fresh identity verification"
    if not isinstance(spec.search_sku, str) or not spec.search_sku.strip():
        return "SEARCH_SKU_REQUIRED: explicit Search SKU is required"
    if not isinstance(spec.target.location, str) or not spec.target.location.strip():
        return "SEARCH_REGION_REQUIRED: explicit Search region is required"
    return None
