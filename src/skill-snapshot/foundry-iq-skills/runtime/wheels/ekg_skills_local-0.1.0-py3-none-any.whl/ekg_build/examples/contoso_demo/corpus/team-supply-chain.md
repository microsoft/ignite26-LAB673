# Team: Supply Chain

The Supply Chain team plans logistics, freight and inventory for hardware programs. Members of Supply Chain: Marcus Okafor, Hamid Karimi, Nadia Petrova and Oscar Lindqvist.
