# Incident INC-2091

On 2026-05-27, INC-2091 recorded a dataset delivered with missing store regions. INC-2091 was caused by Trey Research. INC-2091 impacted Project Meridian. The incident is closed.
