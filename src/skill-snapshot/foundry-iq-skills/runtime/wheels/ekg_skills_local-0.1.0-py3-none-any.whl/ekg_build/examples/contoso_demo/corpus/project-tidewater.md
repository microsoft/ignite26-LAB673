# Project Tidewater

Project Tidewater delivers a cross-border equipment rental and return program. It is led by Hamid Karimi. Project Tidewater depends on Wide World Importers. Project Tidewater serves Southridge Video and Alpine Ski House. Project Tidewater is governed by the Cobalt policy.
