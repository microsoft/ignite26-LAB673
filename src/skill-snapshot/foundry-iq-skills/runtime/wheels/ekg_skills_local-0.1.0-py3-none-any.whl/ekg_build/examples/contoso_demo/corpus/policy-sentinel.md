# Policy: Sentinel

Sentinel is Contoso's the data-residency policy: customer data must stay in its home region. Sentinel governs Project Lighthouse, Project Beacon and Project Keystone.
