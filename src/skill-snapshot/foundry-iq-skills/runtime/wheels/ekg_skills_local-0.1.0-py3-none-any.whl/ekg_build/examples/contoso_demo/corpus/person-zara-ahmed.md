# Zara Ahmed

Zara Ahmed is a Solutions Consultant and a member of the Customer Success team. Zara does not lead a project this year.
