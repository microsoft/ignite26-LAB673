# Project Harbor

Project Harbor delivers a smart-locker network for seasonal equipment. It is led by Marcus Okafor. Project Harbor depends on Northwind Traders and Wide World Importers. Project Harbor serves Alpine Ski House. Project Harbor is governed by the Bastion policy.
