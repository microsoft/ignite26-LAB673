# Q2 all-hands notes

The Q2 all-hands covered hiring, the new badge system and the benefits enrollment window. Leadership thanked everyone for a strong quarter.
