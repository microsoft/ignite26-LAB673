# Customer: Fourth Coffee

Fourth Coffee is a coffee chain analyzing store traffic. Fourth Coffee is served by Project Meridian. The account is in good standing.
