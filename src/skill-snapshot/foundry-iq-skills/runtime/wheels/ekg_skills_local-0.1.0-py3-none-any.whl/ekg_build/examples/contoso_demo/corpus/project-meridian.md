# Project Meridian

Project Meridian delivers foot-traffic and demand forecasting dashboards. It is led by Aiko Tanaka. Project Meridian depends on Trey Research. Project Meridian serves Fourth Coffee and Blue Yonder Airlines. Project Meridian is governed by the Lantern policy.
