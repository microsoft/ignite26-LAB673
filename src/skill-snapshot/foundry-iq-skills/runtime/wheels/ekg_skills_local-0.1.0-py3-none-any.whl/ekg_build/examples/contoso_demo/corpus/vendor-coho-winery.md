# Vendor: Coho Winery

Coho Winery caters Contoso offsite events. No Contoso project depends on Coho Winery.
