# Customer: Blue Yonder Airlines

Blue Yonder Airlines is an airline running baggage-handling pilots. Blue Yonder Airlines is served by Project Meridian and Project Juniper. The account is in good standing.
