# Project Juniper

Project Juniper delivers baggage-tracking sensor tags. It is led by Ingrid Solberg. Project Juniper depends on Northwind Traders. Project Juniper serves Blue Yonder Airlines. Project Juniper is governed by the Lantern policy.
