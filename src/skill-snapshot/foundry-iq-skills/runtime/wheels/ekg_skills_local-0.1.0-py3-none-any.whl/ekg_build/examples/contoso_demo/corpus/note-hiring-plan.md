# Second-half hiring plan

The second-half hiring plan adds twelve engineering roles and four program managers. Requisitions open on 2026-07-01.
