Ben works for Contoso.
