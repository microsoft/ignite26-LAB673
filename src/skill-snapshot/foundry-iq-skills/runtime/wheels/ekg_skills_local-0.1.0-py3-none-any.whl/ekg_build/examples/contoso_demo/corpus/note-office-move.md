# Office move

Teams on floor 3 move to floor 5 on 2026-08-12. Pack desks by Friday. Parking passes do not change.
