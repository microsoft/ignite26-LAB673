# Holiday calendar

Offices close on the standard public holidays plus two company-wide recharge days in 2026.
