# Elena Varga

Elena Varga is a Data Architect and a member of the Data Services team. Elena leads Project Beacon.
