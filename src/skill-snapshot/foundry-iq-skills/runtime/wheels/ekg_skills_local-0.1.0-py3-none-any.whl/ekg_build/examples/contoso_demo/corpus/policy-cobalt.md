# Policy: Cobalt

Cobalt is Contoso's the export-control policy for cross-border hardware shipments. Cobalt governs Project Tidewater.
