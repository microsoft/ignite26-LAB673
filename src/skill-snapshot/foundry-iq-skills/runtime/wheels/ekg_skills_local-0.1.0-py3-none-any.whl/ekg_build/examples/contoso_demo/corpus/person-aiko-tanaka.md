# Aiko Tanaka

Aiko Tanaka is a Product Manager and a member of the Data Services team. Aiko leads Project Meridian.
