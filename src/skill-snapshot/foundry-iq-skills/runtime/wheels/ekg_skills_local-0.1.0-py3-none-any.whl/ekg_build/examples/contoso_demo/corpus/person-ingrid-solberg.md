# Ingrid Solberg

Ingrid Solberg is a Engineering Manager and a member of the Field Robotics team. Ingrid leads Project Juniper.
