# Team: Field Robotics

The Field Robotics team builds the warehouse robots and edge sensors Contoso ships to customers. Members of Field Robotics: Priya Raman, Ingrid Solberg, Kofi Mensah and Lena Fischer.
