# Project Compass

Project Compass delivers a guided onboarding and training portal. It is led by Diego Alvarez. Project Compass depends on Proseware. Project Compass serves Wingtip Toys. Project Compass is governed by the Quill policy.
