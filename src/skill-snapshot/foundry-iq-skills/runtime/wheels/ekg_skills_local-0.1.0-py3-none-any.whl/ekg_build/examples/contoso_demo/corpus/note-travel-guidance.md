# Travel guidance update

Book travel at least 14 days ahead. Customer visits need manager approval. Economy class applies to flights under six hours.
