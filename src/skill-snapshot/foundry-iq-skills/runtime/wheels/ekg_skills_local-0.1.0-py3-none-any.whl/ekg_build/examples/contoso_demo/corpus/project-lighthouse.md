# Project Lighthouse

Project Lighthouse delivers autonomous inventory robots with on-device route planning. It is led by Priya Raman. Project Lighthouse depends on Northwind Traders and Litware. Project Lighthouse serves Tailspin Toys and Woodgrove Bank. Project Lighthouse is governed by the Sentinel policy.
