# Vendor: Proseware

Proseware provides a hosted identity and single sign-on service. Projects that depend on Proseware: Project Atlas and Project Compass. The current Proseware delivery deadline is 2026-10-15.
