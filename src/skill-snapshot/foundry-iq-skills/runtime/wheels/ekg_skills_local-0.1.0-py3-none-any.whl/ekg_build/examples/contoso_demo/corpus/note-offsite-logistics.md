# Engineering offsite logistics

The engineering offsite runs 2026-09-18. Coffee is at 8:30, sessions start at 9:00 and dinner is at 18:30.
