# Yusuf Demir

Yusuf Demir is a Account Manager and a member of the Customer Success team. Yusuf does not lead a project this year.
