# Policy: Ledger

Ledger is Contoso's the financial controls policy for anything that moves money. Ledger governs Project Beacon and Project Summit.
