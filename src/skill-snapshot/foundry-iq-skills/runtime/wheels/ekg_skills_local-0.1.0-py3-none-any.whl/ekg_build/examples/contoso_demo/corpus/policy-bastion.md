# Policy: Bastion

Bastion is Contoso's the vendor security review policy for any third-party integration. Bastion governs Project Harbor and Project Atlas.
