# Incident INC-2078

On 2026-04-21, INC-2078 recorded a customs hold on a container of hardware. INC-2078 was caused by Wide World Importers. INC-2078 impacted Project Tidewater and Project Harbor. The incident is closed.
