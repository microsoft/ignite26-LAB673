# Vendor: Wide World Importers

Wide World Importers handles international freight and customs brokerage. Projects that depend on Wide World Importers: Project Harbor and Project Tidewater. The current Wide World Importers delivery deadline is 2026-10-15.
