# Vendor: Litware

Litware licenses a route-planning software library. Projects that depend on Litware: Project Lighthouse and Project Atlas. The current Litware delivery deadline is 2026-10-15.
