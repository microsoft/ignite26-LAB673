# Bianca Rossi

Bianca Rossi is a Trainer and a member of the Customer Success team. Bianca does not lead a project this year.
