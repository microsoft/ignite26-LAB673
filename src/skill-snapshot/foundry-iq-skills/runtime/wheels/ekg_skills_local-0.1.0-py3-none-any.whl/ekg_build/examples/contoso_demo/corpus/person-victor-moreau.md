# Victor Moreau

Victor Moreau is a Site Reliability Engineer and a member of the Platform Engineering team. Victor does not lead a project this year.
