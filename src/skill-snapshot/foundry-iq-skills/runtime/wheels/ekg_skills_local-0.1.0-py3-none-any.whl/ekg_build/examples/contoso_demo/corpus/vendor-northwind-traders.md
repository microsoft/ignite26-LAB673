# Vendor: Northwind Traders

Northwind Traders supplies edge sensors and ruggedized controller boards. Projects that depend on Northwind Traders: Project Lighthouse, Project Harbor and Project Juniper. The current Northwind Traders delivery deadline is 2026-10-15.
