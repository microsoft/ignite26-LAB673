# Project Atlas

Project Atlas delivers a multi-tenant developer portal. It is led by Tomasz Nowak. Project Atlas depends on Litware and Proseware. Project Atlas serves Relecloud. Project Atlas is governed by the Bastion policy.
