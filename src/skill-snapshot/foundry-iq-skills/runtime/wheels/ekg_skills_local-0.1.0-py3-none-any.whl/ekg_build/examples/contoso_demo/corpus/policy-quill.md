# Policy: Quill

Quill is Contoso's the customer communications and training records policy. Quill governs Project Compass.
