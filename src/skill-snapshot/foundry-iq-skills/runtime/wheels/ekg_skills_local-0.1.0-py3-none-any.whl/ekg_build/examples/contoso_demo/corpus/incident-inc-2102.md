# Incident INC-2102

On 2026-06-10, INC-2102 recorded a firmware defect in a hardware security module batch. INC-2102 was caused by VanArsdel. INC-2102 impacted Project Keystone. The incident is closed.
