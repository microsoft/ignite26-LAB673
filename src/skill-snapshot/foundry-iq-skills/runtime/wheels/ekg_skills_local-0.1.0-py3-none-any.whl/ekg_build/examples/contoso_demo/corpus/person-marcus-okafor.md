# Marcus Okafor

Marcus Okafor is a Program Director and a member of the Supply Chain team. Marcus leads Project Harbor.
