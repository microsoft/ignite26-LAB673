# Fatima Haddad

Fatima Haddad is a Security Architect and a member of the Security Office team. Fatima leads Project Keystone.
