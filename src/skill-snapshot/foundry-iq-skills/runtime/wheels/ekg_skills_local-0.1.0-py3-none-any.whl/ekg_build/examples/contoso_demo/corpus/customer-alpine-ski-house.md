# Customer: Alpine Ski House

Alpine Ski House is a resort operator with seasonal equipment logistics. Alpine Ski House is served by Project Harbor and Project Tidewater. The account is in good standing.
