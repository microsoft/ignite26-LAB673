# Project Beacon

Project Beacon delivers a usage-based billing and reporting service. It is led by Elena Varga. Project Beacon depends on Fabrikam. Project Beacon serves Woodgrove Bank and Humongous Insurance. Project Beacon is governed by the Sentinel and Ledger policies.
