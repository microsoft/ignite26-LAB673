# Team: Customer Success

The Customer Success team runs onboarding and adoption programs for customers. Members of Customer Success: Diego Alvarez, Yusuf Demir, Zara Ahmed and Bianca Rossi.
