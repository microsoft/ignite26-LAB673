# June internal newsletter

June highlights: a new mentoring circle, the summer intern cohort, and the charity run. Vendor deadlines and customer escalations are tracked elsewhere.
