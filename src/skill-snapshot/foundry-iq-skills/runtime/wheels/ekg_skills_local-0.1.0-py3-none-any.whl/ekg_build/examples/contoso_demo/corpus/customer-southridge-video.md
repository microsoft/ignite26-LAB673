# Customer: Southridge Video

Southridge Video is a video studio with global equipment shipments. Southridge Video is served by Project Tidewater. The account is in good standing.
