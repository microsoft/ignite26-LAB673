# Customer: Wingtip Toys

Wingtip Toys is an online toy retailer. Wingtip Toys is served by Project Compass. The account is in good standing.
