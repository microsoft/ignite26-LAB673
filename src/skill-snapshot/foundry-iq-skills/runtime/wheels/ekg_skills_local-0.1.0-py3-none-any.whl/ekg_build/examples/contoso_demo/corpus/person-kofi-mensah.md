# Kofi Mensah

Kofi Mensah is a Hardware Engineer and a member of the Field Robotics team. Kofi does not lead a project this year.
