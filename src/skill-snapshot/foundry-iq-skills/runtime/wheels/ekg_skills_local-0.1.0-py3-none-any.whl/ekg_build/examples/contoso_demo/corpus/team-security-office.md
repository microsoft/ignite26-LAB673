# Team: Security Office

The Security Office team owns identity, compliance and security engineering. Members of Security Office: Fatima Haddad, Chen Wei, Mateo Silva and Olga Ivanova.
