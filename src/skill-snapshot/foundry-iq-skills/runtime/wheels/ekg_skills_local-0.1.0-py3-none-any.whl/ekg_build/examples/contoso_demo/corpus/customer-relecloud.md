# Customer: Relecloud

Relecloud is a cloud hosting provider using Contoso tooling. Relecloud is served by Project Atlas. The account is in good standing.
