# Nadia Petrova

Nadia Petrova is a Planner and a member of the Supply Chain team. Nadia does not lead a project this year.
