# Lena Fischer

Lena Fischer is a Test Engineer and a member of the Field Robotics team. Lena does not lead a project this year.
