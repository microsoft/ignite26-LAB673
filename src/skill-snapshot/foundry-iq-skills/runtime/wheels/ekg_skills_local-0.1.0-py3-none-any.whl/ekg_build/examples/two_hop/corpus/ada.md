Ada works for Contoso.
