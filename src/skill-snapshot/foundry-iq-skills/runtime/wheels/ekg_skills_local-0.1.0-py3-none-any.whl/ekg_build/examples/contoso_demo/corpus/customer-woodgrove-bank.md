# Customer: Woodgrove Bank

Woodgrove Bank is a regional bank modernizing branch operations. Woodgrove Bank is served by Project Lighthouse, Project Beacon and Project Keystone. The account is in good standing.
