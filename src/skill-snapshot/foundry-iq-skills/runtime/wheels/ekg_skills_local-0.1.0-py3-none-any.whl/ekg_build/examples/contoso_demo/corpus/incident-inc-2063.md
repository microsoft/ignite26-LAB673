# Incident INC-2063

On 2026-04-02, INC-2063 recorded a breaking change in a route-planning library release. INC-2063 was caused by Litware. INC-2063 impacted Project Atlas. The incident is closed.
