# Tomasz Nowak

Tomasz Nowak is a Staff Engineer and a member of the Platform Engineering team. Tomasz leads Project Atlas.
