# Oscar Lindqvist

Oscar Lindqvist is a Buyer and a member of the Supply Chain team. Oscar does not lead a project this year.
