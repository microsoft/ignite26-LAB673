# Customer: Humongous Insurance

Humongous Insurance is an insurer digitizing claims intake. Humongous Insurance is served by Project Beacon and Project Keystone. The account is in good standing.
