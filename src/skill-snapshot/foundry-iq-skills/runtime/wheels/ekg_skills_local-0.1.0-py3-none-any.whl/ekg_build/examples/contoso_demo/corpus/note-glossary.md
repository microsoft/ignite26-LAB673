# Glossary

A project is a funded delivery effort. A vendor is an external supplier. An incident is an unplanned disruption. A policy is a mandatory control.
