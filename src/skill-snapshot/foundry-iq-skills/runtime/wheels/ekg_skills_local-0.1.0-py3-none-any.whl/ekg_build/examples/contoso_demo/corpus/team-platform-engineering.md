# Team: Platform Engineering

The Platform Engineering team owns the shared cloud platform and developer tooling. Members of Platform Engineering: Tomasz Nowak, Grace Liu, Victor Moreau and Wen Zhao.
