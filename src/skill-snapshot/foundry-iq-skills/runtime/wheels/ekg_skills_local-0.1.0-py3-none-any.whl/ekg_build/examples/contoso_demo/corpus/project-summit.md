# Project Summit

Project Summit delivers a subscription checkout for the retail storefront kit. It is led by Grace Liu. Project Summit depends on Fabrikam. Project Summit serves Adventure Works. Project Summit is governed by the Ledger policy.
