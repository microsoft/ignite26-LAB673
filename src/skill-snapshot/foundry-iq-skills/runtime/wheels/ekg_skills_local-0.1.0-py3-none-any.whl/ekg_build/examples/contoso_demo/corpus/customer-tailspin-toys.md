# Customer: Tailspin Toys

Tailspin Toys is a toy manufacturer automating two distribution centers. Tailspin Toys is served by Project Lighthouse. The account is in good standing.
