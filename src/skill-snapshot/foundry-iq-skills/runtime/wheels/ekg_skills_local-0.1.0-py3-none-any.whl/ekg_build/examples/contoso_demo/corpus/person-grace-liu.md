# Grace Liu

Grace Liu is a Engineering Manager and a member of the Platform Engineering team. Grace leads Project Summit.
