# Supplier Day agenda

Supplier Day is on 2026-09-30 in Building 4. Morning talks cover sustainability reporting and invoice timelines. Lunch is provided.
