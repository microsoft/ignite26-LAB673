# Developer tooling survey results

Engineers rated build speed and test flakiness as the top pain points. Platform tooling satisfaction rose six points.
