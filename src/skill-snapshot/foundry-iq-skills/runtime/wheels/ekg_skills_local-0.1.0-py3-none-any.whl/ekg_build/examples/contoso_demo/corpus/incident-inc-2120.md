# Incident INC-2120

On 2026-07-22, INC-2120 recorded duplicate invoices from a billing API retry bug. INC-2120 was caused by Fabrikam. INC-2120 impacted Project Beacon. The incident is closed.
