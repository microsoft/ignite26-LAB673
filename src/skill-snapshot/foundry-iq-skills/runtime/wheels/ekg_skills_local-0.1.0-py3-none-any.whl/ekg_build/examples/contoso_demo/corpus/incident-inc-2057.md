# Incident INC-2057

On 2026-03-19, INC-2057 recorded a four-hour payments API outage. INC-2057 was caused by Fabrikam. INC-2057 impacted Project Beacon and Project Summit. The incident is closed.
