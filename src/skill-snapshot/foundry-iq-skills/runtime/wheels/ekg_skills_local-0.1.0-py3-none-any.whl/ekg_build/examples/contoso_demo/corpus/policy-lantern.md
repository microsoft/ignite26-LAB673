# Policy: Lantern

Lantern is Contoso's the responsible data-use policy for analytics on third-party data. Lantern governs Project Meridian and Project Juniper.
