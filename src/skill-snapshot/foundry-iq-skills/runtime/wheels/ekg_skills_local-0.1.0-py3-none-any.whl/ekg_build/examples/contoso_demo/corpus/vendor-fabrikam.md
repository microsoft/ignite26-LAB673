# Vendor: Fabrikam

Fabrikam provides a payments and billing API. Projects that depend on Fabrikam: Project Beacon and Project Summit. The current Fabrikam delivery deadline is 2026-10-15.
