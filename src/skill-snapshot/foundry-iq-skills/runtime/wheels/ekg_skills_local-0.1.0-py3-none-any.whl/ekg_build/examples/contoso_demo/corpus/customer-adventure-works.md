# Customer: Adventure Works

Adventure Works is an outdoor gear retailer. Adventure Works is served by Project Summit. The account is in good standing.
