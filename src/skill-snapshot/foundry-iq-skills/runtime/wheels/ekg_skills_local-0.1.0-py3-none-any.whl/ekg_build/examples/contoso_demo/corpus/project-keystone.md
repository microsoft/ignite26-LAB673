# Project Keystone

Project Keystone delivers customer-managed encryption keys for regulated tenants. It is led by Fatima Haddad. Project Keystone depends on VanArsdel. Project Keystone serves Humongous Insurance and Woodgrove Bank. Project Keystone is governed by the Sentinel policy.
