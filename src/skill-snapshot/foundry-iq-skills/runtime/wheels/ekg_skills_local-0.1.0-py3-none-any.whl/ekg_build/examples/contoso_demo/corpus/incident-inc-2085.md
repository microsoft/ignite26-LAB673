# Incident INC-2085

On 2026-05-06, INC-2085 recorded an expired single sign-on signing certificate. INC-2085 was caused by Proseware. INC-2085 impacted Project Compass. The incident is closed.
