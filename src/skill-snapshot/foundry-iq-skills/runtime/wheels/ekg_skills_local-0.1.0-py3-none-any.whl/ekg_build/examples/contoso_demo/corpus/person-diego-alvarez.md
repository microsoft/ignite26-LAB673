# Diego Alvarez

Diego Alvarez is a Engagement Lead and a member of the Customer Success team. Diego leads Project Compass.
