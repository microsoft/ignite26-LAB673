# Hamid Karimi

Hamid Karimi is a Logistics Lead and a member of the Supply Chain team. Hamid leads Project Tidewater.
