"""Header-visible ARM discovery for plans with the bounded request policy."""
from __future__ import annotations

import json
from typing import Any, Callable
from urllib.parse import urlsplit

from ekg_core.arm_retry import POLICY_ID, report, sdk_retry_policy
from ekg_core.az_identity import IdentityError, az_json, claims
from ekg_core.models import ProvisioningSpec


class ArmReadError(IdentityError):
    def __init__(self, status: int) -> None:
        super().__init__(f"ARM read returned HTTP {status}; no workflow replay or cleanup.")
        self.status_code = status


def read_json(
    spec: ProvisioningSpec, method: str, url: str, *,
    runner: Callable[..., Any] | None = None,
    observe: Callable[[dict[str, Any]], None] = report,
) -> Any:
    if spec.request_retry_policy != POLICY_ID:
        return az_json(["rest", "--method", method, "--url", url],
                       **({"runner": runner} if runner is not None else {}))
    tenant = spec.public_endpoint.tenant_id if spec.public_endpoint else None
    if not tenant:
        raise IdentityError("bounded ARM discovery requires an explicit public plan tenant")
    parsed = urlsplit(url)
    if (parsed.scheme != "https" or parsed.netloc != "management.azure.com"
            or method.lower() not in ("get", "post")
            or (method.lower() == "post"
                and parsed.path.casefold() != "/providers/microsoft.search/fetchofferings")):
        raise IdentityError("unsupported ARM discovery request")
    from azure.core.pipeline import Pipeline
    from azure.core.pipeline.policies import BearerTokenCredentialPolicy
    from azure.core.pipeline.transport import HttpRequest, RequestsTransport
    from azure.identity import AzureCliCredential

    class TenantCredential:
        def __init__(self) -> None:
            self.credential = AzureCliCredential(tenant_id=tenant)

        def get_token(self, *scopes: str, **kwargs: Any) -> Any:
            token = self.credential.get_token(*scopes, **kwargs)
            if str(claims(token.token).get("tid", "")).casefold() != tenant.casefold():
                raise IdentityError("ARM token tenant differs from the approved tenant")
            return token

    with Pipeline(transport=RequestsTransport(), policies=[
        sdk_retry_policy(observe), BearerTokenCredentialPolicy(
            TenantCredential(), "https://management.azure.com/.default"),
    ]) as pipeline:
        response = pipeline.run(HttpRequest(method.upper(), url)).http_response
        if response.status_code != 200:
            raise ArmReadError(response.status_code)
        return json.loads(response.text())
