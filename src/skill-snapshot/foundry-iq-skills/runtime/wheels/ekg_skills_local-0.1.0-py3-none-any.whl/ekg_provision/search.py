"""Search provisioning policy and read-only Serverless availability preflight."""
from __future__ import annotations

from typing import Any

from ekg_core.az_identity import az_json
from ekg_core.models import ProvisioningSpec
from .arm import read_json

DEDICATED_API = "2025-05-01"
SERVERLESS_API = "2026-09-01-preview"
SEARCH_SKUS = (
    "serverless", "basic", "standard", "standard2", "standard3",
    "storage_optimized_l1", "storage_optimized_l2",
)
# Published support plus live FetchOfferings evidence for westus3 (2026-10-24);
# not a capacity or subscription-entitlement guarantee.
# https://learn.microsoft.com/azure/search/search-region-support (2026-10-09)
SERVERLESS_REGIONS = (
    "australiaeast", "centralindia", "centralus", "italynorth", "japaneast",
    "northcentralus", "norwayeast", "swedencentral", "switzerlandnorth",
    "uaenorth", "uksouth", "westcentralus", "westus", "westus2", "westus3",
)
SERVERLESS_WARNING = (
    "Serverless preview: no SLA, index aliases, tier migration, private networking "
    "for indexers or shared private links. Inbound private endpoints do not provide "
    "outbound indexer connectivity. Compute Units and indexed storage are billable; "
    "usage cost is unknown, not zero. Provisioning readiness does not prove managed "
    "Azure Blob graphExtraction support; a separately approved exact-service Build "
    "and extraction/retrieval trial are still required."
)


def management_api(spec: ProvisioningSpec) -> str:
    return SERVERLESS_API if spec.search_sku == "serverless" else DEDICATED_API


def validate_search(spec: ProvisioningSpec) -> None:
    if spec.search_sku not in SEARCH_SKUS:
        raise ValueError(f"Search SKU must be one of {', '.join(SEARCH_SKUS)}")
    if spec.search_sku != "serverless":
        return
    if spec.network is not None:
        raise ValueError(
            "Serverless cannot use this private-indexer configuration: inbound private "
            "endpoints do not enable outbound indexer networking. Explicitly opt in to "
            "a compatible Dedicated SKU and review its private-indexer requirements."
        )
    if spec.target.location and spec.target.location not in SERVERLESS_REGIONS:
        raise ValueError(
            f"Serverless is not supported by this provisioner in {spec.target.location}; "
            "choose a documented Serverless region or explicitly opt in with "
            "--search-sku basic (Dedicated). No automatic SKU fallback."
        )
    if spec.public_endpoint and spec.public_endpoint.mode != "entra_only":
        raise ValueError(
            "Serverless provisioning supports only explicit entra_only public mode; "
            "IP-allowlist provisioning requires an explicit Dedicated --search-sku."
        )


def read_serverless_availability(spec: ProvisioningSpec, **kwargs: Any) -> dict[str, Any]:
    """No writes: provider registration metadata and regional offering discovery."""
    root = "https://management.azure.com"
    def read(method: str, url: str) -> Any:
        if spec.request_retry_policy is None:
            return az_json(["rest", "--method", method, "--url", url])
        return read_json(spec, method, url, **kwargs)

    provider = read("get",
        f"{root}/subscriptions/{spec.target.subscription_id}/providers/Microsoft.Search"
        "?api-version=2021-04-01",
        )
    # Fetch Offerings is a read-only action (POST with no request body).
    offerings = read("post",
        f"{root}/providers/Microsoft.Search/fetchOfferings?api-version={SERVERLESS_API}",
        )
    return {"provider": provider, "offerings": offerings}


def serverless_preflight(spec: ProvisioningSpec, observed: dict[str, Any]) -> dict[str, str]:
    provider = observed.get("provider")
    if not isinstance(provider, dict) or provider.get("registrationState") != "Registered":
        raise ValueError("Serverless preflight: Microsoft.Search must already be Registered")
    types = provider.get("resourceTypes")
    if not isinstance(types, list) or not any(
        isinstance(item, dict)
        and str(item.get("resourceType", "")).lower() == "searchservices"
        and isinstance(item.get("apiVersions"), list)
        and any(isinstance(version, str) and version.casefold() == SERVERLESS_API.casefold()
                for version in item["apiVersions"])
        for item in types
    ):
        raise ValueError(
            f"Serverless preflight: management API {SERVERLESS_API} is not advertised "
            "by the target subscription; no writes and no Dedicated fallback"
        )
    offerings = observed.get("offerings")
    regions = offerings.get("regions") if isinstance(offerings, dict) else None
    location = spec.target.location or ""
    if not isinstance(regions, list) or not any(
        isinstance(region, dict)
        and str(region.get("regionName", "")).replace(" ", "").casefold() == location.casefold()
        and isinstance(region.get("skus"), list)
        and any(isinstance(item, dict) and item.get("name") == "serverless"
                for item in region["skus"])
        for region in regions
    ):
        raise ValueError(
            f"Serverless preflight: no current Serverless offering for {location}; "
            "no writes and no Dedicated fallback"
        )
    return {"origin": "arm_provider_and_fetch_offerings", "api_version": SERVERLESS_API,
            "location": location, "sku": "serverless"}
