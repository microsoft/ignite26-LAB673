"""Retained, hash-bound input artifacts; never a producer freeze or Azure snapshot."""

from __future__ import annotations

import hashlib
import os
import stat
import tempfile
import time
from dataclasses import asdict
from datetime import datetime
from pathlib import Path, PureWindowsPath
from typing import Any

from grz_build.inputs import Snapshot, _json, load_snapshot
from grz_core.contracts import ContractError, Source, canonical_json, digest

VERSION = "grz-captured-input-v1"
COVERAGE_VERSION = "grz-capture-coverage-v1"
LIMITS = {"documents": 100_000, "page_documents": 500, "total_bytes": 512 * 1024 * 1024,
          "document_bytes": 15 * 1024 * 1024, "duration_seconds": 1800, "passes": 3}
LIMITATION = (
    "This retained input is immutable, not a producer-frozen or transactional Azure snapshot. "
    "Managed ingestion remains unchanged. Three matching scans detect observed changes but "
    "cannot exclude undetected mixed-time reads. Evidence describes captured content, not "
    "guaranteed-current live content. Retain the artifact and compatibility copy; no automatic cleanup."
)
FILES = ("rows.jsonl", "vectors.jsonl", "source-documents.jsonl", "source-schema.json",
         "capture-evidence.json")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def valid_hash(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def validate_coverage(coverage: Any, documents: tuple[dict[str, Any], ...] | None,
                      key_field: str) -> dict[str, Any]:
    required = {"version", "document_field", "original_ids", "chunk_originals", "approval", "evidence_sha256"}
    if (not isinstance(coverage, dict) or set(coverage) != required
            or coverage["version"] != COVERAGE_VERSION
            or any(not isinstance(coverage[k], str) or not coverage[k].strip()
                   for k in ("document_field", "approval"))
            or not isinstance(coverage["original_ids"], list) or not coverage["original_ids"]
            or any(not isinstance(v, str) or not v.strip() for v in coverage["original_ids"])
            or len(set(coverage["original_ids"])) != len(coverage["original_ids"])
            or not isinstance(coverage["chunk_originals"], dict)
            or not isinstance(coverage["evidence_sha256"], dict) or not coverage["evidence_sha256"]
            or any(not isinstance(k, str) or not k or not valid_hash(v)
                   for k, v in coverage["evidence_sha256"].items())):
        raise ContractError("CAPTURE_COVERAGE_INVALID", "Complete approved original-document mapping and evidence hashes required")
    if documents is None:
        return coverage
    field = coverage["document_field"]
    actual = {doc.get(key_field): doc.get(field) for doc in documents}
    if (len(actual) != len(documents) or actual != coverage["chunk_originals"]
            or any(not isinstance(v, str) for v in actual.values())
            or set(actual.values()) != set(coverage["original_ids"])):
        raise ContractError("CAPTURE_COVERAGE_INVALID", "Every captured chunk must map to exactly the approved original inventory")
    return coverage


def retain(store: Any, identity: Source, root: Path, coverage_path: Path) -> dict[str, Any]:
    """Finalize a new artifact atomically. Failed attempts retain diagnostics, never retry."""
    root = root.resolve()
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    folder = Path(tempfile.mkdtemp(prefix="capture-pending-", dir=root))
    started = time.monotonic()
    try:
        coverage = _json(coverage_path.read_text(encoding="utf-8"), "capture coverage")
        validate_coverage(coverage, None, store.fields.key)
        manifest_path = store.export_snapshot(identity, folder)
        snapshot = load_snapshot(manifest_path)
        validate_coverage(coverage, snapshot.source_documents, store.fields.key)
        evidence_path = folder / "capture-evidence.json"
        evidence = _json(evidence_path.read_text(encoding="utf-8"), evidence_path.name)
        evidence["coverage"] = coverage
        evidence_path.write_text(canonical_json(evidence) + "\n", encoding="utf-8")
        manifest = _json(manifest_path.read_text(encoding="utf-8"), manifest_path.name)
        manifest["capture"]["files_sha256"] = {name: sha256(folder / name) for name in FILES}
        manifest_path.write_text(canonical_json(manifest) + "\n", encoding="utf-8")
        if sum(path.stat().st_size for path in folder.iterdir()) > LIMITS["total_bytes"]:
            raise ContractError("CAPTURE_LIMIT_EXCEEDED", "Total retained artifact byte bound exceeded")
        capture_id = digest(manifest)
        destination = root / capture_id
        if destination.exists():
            raise ContractError("CAPTURE_ARTIFACT_INVALID", "Refusing to overwrite an existing retained capture")
        spec = {"version": VERSION, "input_kind": "immutable-capture", "capture_id": capture_id,
                "artifact_path": str(destination / "manifest.json"),
                "manifest_sha256": sha256(manifest_path), "manifest": manifest,
                "atomic_snapshot": False, "limitation": LIMITATION,
                "retention": "protected-no-automatic-cleanup"}
        validate_artifact(spec, manifest_path=manifest_path)
        if time.monotonic() - started >= LIMITS["duration_seconds"]:
            raise ContractError("CAPTURE_LIMIT_EXCEEDED", "Capture finalization duration bound exceeded")
        for path in folder.iterdir():
            path.chmod(stat.S_IRUSR)
        os.rename(folder, destination)
        return spec
    except BaseException as exc:
        diagnostic = folder / "capture-failure.json"
        if folder.is_dir():
            diagnostic.write_text(canonical_json({"status": "failed", "error_code": getattr(
                exc, "code", "CAPTURE_FAILED"), "retry": "Explicit new capture required; no automatic retry"}) + "\n",
                encoding="utf-8")
        raise


def validate_contract(spec: Any) -> None:
    if (not isinstance(spec, dict) or spec.get("version") != VERSION
            or spec.get("input_kind") != "immutable-capture" or spec.get("atomic_snapshot") is not False
            or spec.get("limitation") != LIMITATION or spec.get("retention") != "protected-no-automatic-cleanup"
            or not valid_hash(spec.get("capture_id")) or not valid_hash(spec.get("manifest_sha256"))
            or not isinstance(spec.get("manifest"), dict) or digest(spec["manifest"]) != spec["capture_id"]
            or not isinstance(spec.get("artifact_path"), str)
            or not (Path(spec["artifact_path"]).is_absolute() or PureWindowsPath(spec["artifact_path"]).is_absolute())):
        raise ContractError("CAPTURE_ARTIFACT_INVALID", "Invalid plan-bound captured input authority")
    manifest = spec["manifest"]
    capture = manifest.get("capture")
    if (manifest.get("version") != VERSION or not isinstance(capture, dict)
            or capture.get("version") != VERSION or capture.get("atomic_snapshot") is not False
            or capture.get("passes") != 3 or capture.get("limits") != LIMITS
            or not isinstance(capture.get("files_sha256"), dict) or set(capture["files_sha256"]) != set(FILES)
            or any(not valid_hash(v) for v in capture["files_sha256"].values())
            or not all(isinstance(capture.get(k), str) and capture[k] for k in ("started_at", "completed_at"))
            or not isinstance(manifest.get("source"), dict)
            or manifest["source"].get("input_kind") != "immutable-capture"):
        raise ContractError("CAPTURE_ARTIFACT_INVALID", "Unsupported capture manifest or consistency contract")
    try:
        started = datetime.fromisoformat(capture["started_at"])
        completed = datetime.fromisoformat(capture["completed_at"])
        elapsed = (completed - started).total_seconds()
        if started.tzinfo is None or completed.tzinfo is None or not 0 <= elapsed <= LIMITS["duration_seconds"]:
            raise ValueError("Invalid observation interval")
    except (ValueError, TypeError) as exc:
        raise ContractError("CAPTURE_ARTIFACT_INVALID", "Invalid bounded capture observation interval") from exc
    count = manifest["source"].get("expected_count")
    if type(count) is not int or not 1 <= count <= LIMITS["documents"]:
        raise ContractError("CAPTURE_ARTIFACT_INVALID", "Captured inventory exceeds the document bound")
    if any(manifest.get(key) != value for key, value in (
            ("rows_file", "rows.jsonl"), ("vectors_file", "vectors.jsonl"),
            ("source_documents_file", "source-documents.jsonl"))):
        raise ContractError("CAPTURE_ARTIFACT_INVALID", "Captured files must be the exact hashed inventory")


def validate_artifact(spec: dict[str, Any], *, manifest_path: Path | None = None) -> Snapshot:
    """Read only the exact retained path, validating bytes before and after loading."""
    validate_contract(spec)
    path = manifest_path or Path(spec["artifact_path"])
    try:
        def verify() -> None:
            if sum(file.stat().st_size for file in [path, *(path.parent / name for name in FILES)]) > LIMITS["total_bytes"]:
                raise ContractError("CAPTURE_ARTIFACT_INVALID", "Retained capture exceeds the byte bound")
            if path.is_symlink() or sha256(path) != spec["manifest_sha256"]:
                raise ContractError("CAPTURE_ARTIFACT_INVALID", "Retained manifest changed; no recapture permitted")
            for name, expected in spec["manifest"]["capture"]["files_sha256"].items():
                file = path.parent / name
                if file.is_symlink() or sha256(file) != expected:
                    raise ContractError("CAPTURE_ARTIFACT_INVALID", "Retained capture bytes changed; no recapture permitted")
        verify()
        snapshot = load_snapshot(path)
        if snapshot.snapshot_manifest != spec["manifest"]:
            raise ContractError("CAPTURE_ARTIFACT_INVALID", "Retained manifest does not match approved authority")
        evidence = _json((path.parent / "capture-evidence.json").read_text(encoding="utf-8"), "capture evidence")
        schema = _json((path.parent / "source-schema.json").read_text(encoding="utf-8"), "source schema")
        if (evidence.get("atomic_snapshot") is not False or evidence.get("passes") != 3
                or evidence.get("source") != asdict(snapshot.source)
                or evidence.get("schema_digest") != digest(schema)
                or evidence.get("started_at") != spec["manifest"]["capture"]["started_at"]
                or evidence.get("completed_at") != spec["manifest"]["capture"]["completed_at"]):
            raise ContractError("CAPTURE_ARTIFACT_INVALID", "Captured provenance or observation interval differs")
        approval = evidence.get("source_approval")
        if (not isinstance(approval, dict) or not approval.get("tenant") or not approval.get("security_inspection")
                or approval.get("owner_approval") != snapshot.source.owner_approval
                or approval.get("resource") != snapshot.source.service or approval.get("dataset") != snapshot.source.index
                or approval.get("frozen_evidence")):
            raise ContractError("CAPTURE_ARTIFACT_INVALID", "Captured source approval is incomplete or claims a producer freeze")
        validate_coverage(evidence.get("coverage"), snapshot.source_documents, evidence["key_field"])
        verify()
        return snapshot
    except (OSError, ValueError, KeyError, TypeError) as exc:
        if isinstance(exc, ContractError) and exc.code == "CAPTURE_ARTIFACT_INVALID":
            raise
        raise ContractError("CAPTURE_ARTIFACT_INVALID", "Retained capture missing, corrupt or invalid; never reconstruct from live source") from exc
