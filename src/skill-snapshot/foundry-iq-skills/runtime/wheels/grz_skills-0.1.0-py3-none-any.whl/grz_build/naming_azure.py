"""Opt-in community naming with an Azure OpenAI chat deployment, bounded by the plan's naming budget."""

from __future__ import annotations

import time
from math import isfinite
from dataclasses import dataclass, field
from typing import Any, NoReturn
from urllib.parse import unquote, urlparse

import numpy as np

from grz_core.azure_auth import get_token
from grz_core.contracts import ContractError

from .centroids import Centroid
from .inputs import Snapshot
from .naming import NamingRefused, NamingResult

PROMPT_VERSION = "grz-naming-v1"
COGNITIVE_SCOPE = "https://cognitiveservices.azure.com/.default"
API_VERSION = "2025-04-01-preview"
REQUEST_POLICY_VERSION = "chat-naming-defaults-2026-10-20-v2"
MAX_LABEL_CHARS = 60
MAX_THROTTLE_RETRIES = 2
MAX_RETRY_AFTER_SECONDS = 30
SYSTEM_PROMPT = (
    "You name clusters of documents. You get sample documents from one cluster, the ones closest "
    "to its center. Reply with one short topic label of at most six words that covers the cluster "
    "as a whole. Reply with the label only: no quotes, no trailing punctuation, no explanation."
)


def request_policy(model: str) -> dict[str, Any]:
    non_reasoning = {"gpt-4o", "gpt-4o-mini", "gpt-4.1", "gpt-4.1-mini", "gpt-4.1-nano"}
    minimal = {"gpt-5", "gpt-5-mini", "gpt-5-nano"}
    low = {"gpt-5.1", "gpt-5.2", "gpt-5.4", "gpt-5.4-mini", "gpt-5.4-nano", "gpt-5.5",
           "gpt-5.6-sol", "gpt-5.6-terra", "gpt-5.6-luna"}
    if not isinstance(model, str) or model not in non_reasoning | minimal | low:
        raise ContractError("NAMING_MODEL_UNSUPPORTED",
                            "The model has no pinned Chat Completions naming request policy; "
                            "verify its model identity and support for this transport/API before planning")
    return {"version": REQUEST_POLICY_VERSION,
            "reasoning_effort": "minimal" if model in minimal else "low" if model in low else None}


def validate_prices(input_rate: float, output_rate: float) -> None:
    if any(type(rate) not in (int, float) or not isfinite(rate) or rate < 0
           for rate in (input_rate, output_rate)):
        raise ContractError("NAMING_PRICING_INVALID", "Both naming token prices must be finite nonnegative numbers")


def source_title(source: str) -> str:
    path = urlparse(source).path or source
    return unquote(path.rstrip("/").rsplit("/", 1)[-1]).replace("_", " ") or source


def naming_contexts(snapshot: Snapshot, hierarchy: list[dict[str, Centroid]], *,
                    members_per_prompt: int, excerpt_chars: int) -> dict[str, str]:
    """Context per community key, top level first, from the members nearest its centroid."""
    if any(c.vector is None for communities in hierarchy for c in communities.values()):
        raise ContractError("NATIVE_REPRESENTATIVE_MISSING", "Naming requires an actual native representative vector for every community")
    positions = {key: i for i, key in enumerate(snapshot.ids)}
    contexts: dict[str, str] = {}
    for level in reversed(range(len(hierarchy))):
        for local in sorted(hierarchy[level]):
            centroid = hierarchy[level][local]
            assert centroid.vector is not None
            members = list(centroid.members)
            scores = snapshot.vectors[[positions[m] for m in members]] @ centroid.vector.astype(np.float32)
            ranked = [members[i] for i in np.lexsort((np.array(members), -scores))]
            lines, seen = [], set()
            for member in ranked:
                row = snapshot.rows[positions[member]]
                title = source_title(row["source"])
                if title in seen:
                    continue
                seen.add(title)
                excerpt = " ".join(row["text"].split())[:excerpt_chars]
                lines.append(f"- {title}: {excerpt}")
                if len(lines) == members_per_prompt:
                    break
            contexts[f"{level}:{local}"] = f"Cluster of {len(members)} documents. Samples:\n" + "\n".join(lines)
    return contexts


def clean_label(text: str | None) -> str | None:
    if not text:
        return None
    line = text.strip().splitlines()[0].strip().strip("\"'`*").rstrip(".").strip()
    if not line or len(line) > MAX_LABEL_CHARS or not any(c.isalpha() for c in line):
        return None
    return line


@dataclass
class AzureOpenAIChatNamer:
    """Calls one chat deployment per community and keeps usage totals for the apply report."""

    endpoint: str
    deployment: str
    model: str
    tenant_id: str
    credential: Any
    max_output_tokens: int
    input_price_per_1m: float
    output_price_per_1m: float
    post: Any = None
    sleep: Any = time.sleep
    usage: dict[str, Any] = field(default_factory=lambda: {"calls": 0, "throttled": 0, "failed": 0,
                                                          "input_tokens": 0, "output_tokens": 0,
                                                          "spend_usd": 0.0, "known_spend_usd": 0.0,
                                                          "cost_complete": True})

    def __post_init__(self) -> None:
        request_policy(self.model)
        validate_prices(self.input_price_per_1m, self.output_price_per_1m)

    @classmethod
    def from_plan(cls, spec: dict[str, Any], tenant_id: str, credential: Any, **kwargs: Any) -> AzureOpenAIChatNamer:
        if spec.get("api_version") != API_VERSION or spec.get("request_policy") != request_policy(spec["model"]):
            raise ContractError("NAMING_POLICY_CHANGED", "Naming request policy differs; create and approve a fresh plan")
        return cls(endpoint=spec["endpoint"], deployment=spec["deployment"], model=spec["model"], tenant_id=tenant_id,
                   credential=credential, max_output_tokens=spec["max_output_tokens"],
                   input_price_per_1m=spec["input_price_per_1m"], output_price_per_1m=spec["output_price_per_1m"],
                   **kwargs)

    def _unknown_usage(self, reason: str) -> NoReturn:
        self.usage.update(cost_complete=False, spend_usd=None, unknown_reason=reason)
        self.usage["failed"] += 1
        raise ContractError("NAMING_USAGE_UNKNOWN",
                            "Naming usage is incomplete; total cost is UNKNOWN. Stop and review provider usage before a new approval")

    def _post(self, url: str, body: dict[str, Any], headers: dict[str, str], timeout: float) -> Any:
        if self.post is not None:
            return self.post(url, body, headers, timeout)
        import requests

        try:
            return requests.post(url, json=body, headers=headers, timeout=timeout)
        except requests.Timeout as exc:
            raise TimeoutError("naming call timed out") from exc
        except requests.RequestException as exc:
            raise ConnectionError("naming call failed") from exc

    def __call__(self, context: str, timeout_seconds: float) -> NamingResult:
        if not self.usage["cost_complete"]:
            raise ContractError("NAMING_USAGE_UNKNOWN", "Prior naming usage is unknown; no additional calls permitted")
        url = (f"{self.endpoint.rstrip('/')}/openai/deployments/{self.deployment}/chat/completions"
               f"?api-version={API_VERSION}")
        body = {"messages": [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": context}],
                "max_completion_tokens": self.max_output_tokens}
        if (effort := request_policy(self.model)["reasoning_effort"]) is not None:
            body["reasoning_effort"] = effort
        for attempt in range(MAX_THROTTLE_RETRIES + 1):
            headers = {"Authorization": "Bearer " + get_token(self.credential, COGNITIVE_SCOPE, self.tenant_id)}
            self.usage["calls"] += 1
            try:
                response = self._post(url, body, headers, timeout_seconds)
            except (TimeoutError, ConnectionError):
                self._unknown_usage("transport_outcome_unknown")
            if response.status_code != 429:
                break
            # A 429 is refused before any tokens are billed, so waiting and asking again stays in budget.
            self.usage["throttled"] += 1
            self.usage["calls"] -= 1
            if attempt == MAX_THROTTLE_RETRIES:
                self.usage["failed"] += 1
                raise NamingRefused("naming deployment kept throttling")
            self.sleep(min(float(response.headers.get("retry-after") or 5), MAX_RETRY_AFTER_SECONDS))
        if response.status_code in (401, 403):
            raise ContractError("NAMING_ACCESS_DENIED", "The naming deployment refused this identity")
        if response.status_code != 200:
            self._unknown_usage("http_outcome_unknown")
        try:
            data = response.json()
        except ValueError:
            self._unknown_usage("invalid_response_json")
        usage = data.get("usage") if isinstance(data, dict) else None
        if (not isinstance(usage, dict)
                or any(type(usage.get(key)) is not int or usage[key] < 0
                       for key in ("prompt_tokens", "completion_tokens"))):
            self._unknown_usage("token_usage_missing_or_invalid")
        prompt_tokens, completion_tokens = usage["prompt_tokens"], usage["completion_tokens"]
        try:
            spend = (prompt_tokens * self.input_price_per_1m + completion_tokens * self.output_price_per_1m) / 1_000_000
        except OverflowError:
            self._unknown_usage("cost_overflow")
        if not isfinite(spend) or not isfinite(self.usage["known_spend_usd"] + spend):
            self._unknown_usage("cost_nonfinite")
        self.usage["input_tokens"] += prompt_tokens
        self.usage["output_tokens"] += completion_tokens
        self.usage["known_spend_usd"] += spend
        self.usage["spend_usd"] = self.usage["known_spend_usd"]
        choices = data.get("choices") or [{}]
        label = clean_label((choices[0].get("message") or {}).get("content"))
        if label is None:
            self.usage["failed"] += 1
        return NamingResult(label, prompt_tokens + completion_tokens, spend)
