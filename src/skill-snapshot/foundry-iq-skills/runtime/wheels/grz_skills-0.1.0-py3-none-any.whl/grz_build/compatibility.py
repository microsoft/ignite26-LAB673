"""Explicit, approval-bound source copies for the immutable native input contract."""

from __future__ import annotations

import tempfile
import time
from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np

from grz_adapters.azure_publication import _is_sdk_client
from grz_adapters.azure_source import get_field, validate_compatibility_fields
from grz_build.inputs import Snapshot, load_snapshot
from grz_core.contracts import CapturedSourceIdentity, ContractError, Source, canonical_json, digest

VERSION = "grz-source-compatibility-v1"
MAX_DOCUMENTS = 100_000


def wire(value: Any) -> dict[str, Any]:
    return deepcopy(value if isinstance(value, dict) else value.as_dict())


def inspection(store: Any, identity: Source) -> dict[str, Any]:
    definition = store.index_client.get_index(identity.index)
    key = next(f for f in get_field(definition, "fields") if get_field(f, "name") == store.fields.key)
    direct = bool(get_field(key, "filterable", False) and get_field(key, "sortable", False))
    mode = store.source_compatibility_mode
    captured = isinstance(identity, CapturedSourceIdentity)
    if not direct or captured:
        _schema(store, identity)
    return {
        "version": VERSION, "requested_mode": mode,
        "resolved_mode": "direct" if direct and not captured else "snapshot-copy",
        "native_direct_supported": direct,
        "export_strategy": "keyset" if get_field(key, "filterable", False) else "bounded-offset",
        "max_export_documents": None if get_field(key, "filterable", False) else MAX_DOCUMENTS,
    }


def _schema(store: Any, identity: Source) -> dict[str, Any]:
    original = wire(store.index_client.get_index(identity.index))
    validate_compatibility_fields(original)
    vector_field = next(field for field in original["fields"] if field["name"] == store.fields.vector)
    vector_search = original.get("vectorSearch", {})
    profile = next((profile for profile in vector_search.get("profiles", [])
                    if profile["name"] == vector_field.get("vectorSearchProfile")), {})
    algorithm = next((algorithm for algorithm in vector_search.get("algorithms", [])
                      if algorithm["name"] == profile.get("algorithm")), {})
    parameters = algorithm.get("hnswParameters") or algorithm.get("exhaustiveKnnParameters") or {}
    metric = parameters.get("metric", "cosine")
    if algorithm.get("kind") not in ("hnsw", "exhaustiveKnn") or metric not in ("cosine", "dotProduct", "euclidean"):
        raise ContractError("COMPATIBILITY_UNSUPPORTED", "Cannot preserve the approved source vector metric")
    fields = []
    for field in original["fields"]:
        copied = {key: field[key] for key in ("name", "type", "fields") if key in field}
        if "ComplexType" not in field["type"]:
            copied["retrievable"] = True
        if field["name"] == store.fields.key:
            copied.update(key=True, filterable=True, sortable=True)
        if field["name"] == store.fields.vector:
            copied.update(searchable=True, stored=True, dimensions=identity.dimension,
                          vectorSearchProfile="grz-compat-hnsw")
        fields.append(copied)
    return {
        "fields": fields,
        "vectorSearch": {
            "algorithms": [{"name": "grz-compat-hnsw", "kind": "hnsw", "hnswParameters": {"metric": metric}}],
            "profiles": [{"name": "grz-compat-hnsw", "algorithm": "grz-compat-hnsw"}],
        },
    }


def plan_source(store: Any, identity: Source, inspected: dict[str, Any], workspace: Path,
                *, plan_binding: str | None = None, capture_coverage: Path | None = None) -> dict[str, Any]:
    resolved = inspected["source_compatibility"]
    data = {**resolved, "original_source": asdict(identity),
            "original_schema_fingerprint": inspected["definition_fingerprint"],
            "field_mapping": {**asdict(store.fields), "security_fields": list(store.fields.security_fields)},
            "document_count": identity.expected_count,
            "dimension": identity.dimension, "embedding_model_id": identity.embedding_model_id,
            "native_input": {"endpoint": store.endpoint, "source_index": identity.index,
                             "vector_field": store.fields.vector},
            "direct_handoff": resolved["resolved_mode"] == "direct",
            "lifecycle": {"automatic_cleanup": False, "original_source_unchanged": True}}
    if resolved["resolved_mode"] == "direct":
        return data
    if plan_binding is not None:
        data["plan_binding_digest"] = plan_binding
    if resolved["requested_mode"] != "auto":
        raise ContractError("SOURCE_SCAN_UNSUPPORTED", "Compatibility is off; original source cannot feed the native builder")
    schema = _schema(store, identity)
    workspace.mkdir(parents=True, exist_ok=True)
    if isinstance(identity, CapturedSourceIdentity):
        if capture_coverage is None:
            raise ContractError("CAPTURE_COVERAGE_INVALID", "Captured planning requires explicit approved original-document coverage")
        from grz_build.captured_input import retain, validate_artifact
        data["captured_input"] = retain(store, identity, workspace.parent / "captures", capture_coverage)
        snapshot = validate_artifact(data["captured_input"])
    else:
        if capture_coverage is not None:
            raise ContractError("CAPTURE_MODE_INVALID", "Coverage is only accepted for explicitly captured input")
        with tempfile.TemporaryDirectory(prefix="compat-plan-", dir=workspace) as folder:
            snapshot = load_snapshot(store.export_snapshot(identity, Path(folder)))
    data.update(snapshot_digest=snapshot.digest, source_documents_sha256=snapshot.source_documents_sha256,
                snapshot_manifest=snapshot.snapshot_manifest,
                snapshot_manifest_digest=digest(snapshot.snapshot_manifest),
                estimated_copy_bytes=sum(len(canonical_json(doc).encode("utf-8")) + 1
                                         for doc in snapshot.source_documents))
    after = store.inspect(identity)
    if after["definition_fingerprint"] != inspected["definition_fingerprint"]:
        raise ContractError("SOURCE_CHANGED", "Original source definition changed while planning its copy")
    data["estimated_copy_storage_bytes"] = max(
        data["estimated_copy_bytes"], identity.expected_count * (identity.dimension * 4 + 1024) * 5)
    index = f"grz-{store.publisher.approval.dataset}-compat-{digest(data)[:20]}"
    if len(index) > 128:
        raise ContractError("PUBLICATION_TARGET_INVALID", "Compatibility index name exceeds Search limit")
    schema.update(name=index, description=f"{VERSION}:{digest(data)}")
    data.update(copy_index=index, copy_schema=schema)
    data["native_input"] = {**data["native_input"], "source_index": index}
    return data


def assert_snapshot(spec: dict[str, Any], snapshot: Snapshot) -> None:
    if (snapshot.digest != spec["snapshot_digest"] or snapshot.source_documents_sha256 != spec["source_documents_sha256"]
            or digest(snapshot.snapshot_manifest) != spec["snapshot_manifest_digest"]):
        raise ContractError("SOURCE_CHANGED", "Original source keys/content/vectors/provenance changed since the approved copy plan")
    key = spec["field_mapping"]["key"]
    vector = spec["field_mapping"]["vector"]
    text = spec["field_mapping"]["text"]
    reference = spec["field_mapping"]["source"]
    docs = snapshot.source_documents
    if len(docs) != spec["document_count"] or tuple(doc.get(key) for doc in docs) != snapshot.ids:
        raise ContractError("INPUT_ID_MISMATCH", "Compatibility inventory must preserve every original physical ID exactly")
    for doc, row in zip(docs, snapshot.rows):
        if doc[text] != row["text"] or doc[reference] != row["source"] or len(doc[vector]) != snapshot.source.dimension:
            raise ContractError("INPUT_ID_MISMATCH", "Compatibility evidence/vector mapping differs from frozen input")


def _normal(value: Any, field: dict[str, Any]) -> Any:
    if value is None:
        return None
    kind = field["type"]
    if kind == "Edm.Single":
        return float(np.float32(value))
    if kind == "Collection(Edm.Single)":
        return [float(np.float32(item)) for item in value]
    if "ComplexType" in kind:
        children = field.get("fields", [])
        def item(record):
            return {f["name"]: _normal(record.get(f["name"]), f) for f in children}
        return [item(record) for record in value] if kind.startswith("Collection(") else item(value)
    return value


def normalized(doc: dict[str, Any], schema: dict[str, Any]) -> dict[str, Any]:
    return {field["name"]: _normal(doc.get(field["name"]), field) for field in schema["fields"]}


def assert_schema(store: Any, spec: dict[str, Any]) -> None:
    expected = spec["copy_schema"]
    actual = wire(store.index_client.get_index(spec["copy_index"]))
    if actual.get("description") != expected["description"]:
        raise ContractError("INDEX_COLLISION", "Compatibility index is not owned by this exact snapshot contract")
    actual_fields = {f["name"]: f for f in actual["fields"]}
    if set(actual_fields) != {f["name"] for f in expected["fields"]}:
        raise ContractError("COMPATIBILITY_PARITY_FAILED", "Compatibility fields differ from approved schema")
    for field in expected["fields"]:
        observed = actual_fields[field["name"]]
        if (observed["type"] != field["type"] or observed.get("retrievable", True) is False
                or any(bool(observed.get(flag, False)) != bool(field.get(flag, False))
                       for flag in ("key", "filterable", "sortable", "searchable"))
                or observed.get("fields", []) != field.get("fields", [])
                or (field["name"] == spec["field_mapping"]["vector"] and (
                    observed.get("dimensions", observed.get("vectorSearchDimensions")) != spec["dimension"]
                    or observed.get("stored", True) is False
                    or observed.get("vectorSearchProfile") != "grz-compat-hnsw"))):
            raise ContractError("COMPATIBILITY_PARITY_FAILED", "Compatibility field capabilities differ from approval")
    search = actual.get("vectorSearch", {})
    algorithms = search.get("algorithms", [])
    if (search.get("compressions") or len(algorithms) != 1
            or algorithms[0].get("name") != "grz-compat-hnsw" or algorithms[0].get("kind") != "hnsw"
            or algorithms[0].get("hnswParameters", {}).get("metric") != expected["vectorSearch"]["algorithms"][0]["hnswParameters"]["metric"]
            or search.get("profiles") != expected["vectorSearch"]["profiles"]):
        raise ContractError("COMPATIBILITY_PARITY_FAILED", "Compatibility vector index does not preserve the approved metric/uncompressed profile")


def read_copy(store: Any, spec: dict[str, Any]) -> list[dict[str, Any]]:
    client = store.publisher.search_client(spec["copy_index"])
    key_field = spec["field_mapping"]["key"]
    rows, seen, last = [], set(), None
    while True:
        where = None if last is None else f"{key_field} gt '{last.replace(chr(39), chr(39) * 2)}'"
        page = list(client.search(search_text="*", filter=where, order_by=[f"{key_field} asc"],
                                  select=[f["name"] for f in spec["copy_schema"]["fields"]], top=500))
        if len(page) > 500:
            raise ContractError("COMPATIBILITY_PARITY_FAILED", "Copy readback exceeded bounded page")
        for row in page:
            doc = dict(row)
            key = doc.get(key_field)
            if not isinstance(key, str) or key in seen or (last is not None and key <= last):
                raise ContractError("COMPATIBILITY_PARITY_FAILED", "Copy has duplicate or unordered physical IDs")
            seen.add(key)
            last = key
            rows.append(normalized(doc, spec["copy_schema"]))
        if len(rows) > spec["document_count"]:
            raise ContractError("COMPATIBILITY_PARITY_FAILED", "Copy exceeds approved inventory")
        if len(page) < 500:
            break
    return rows


def prepare_copy(service: Any, planned: dict[str, Any], snapshot: Snapshot, *, resume: bool) -> None:
    from grz_build.execution import _journaled_write

    store, state = service.store, service.state
    spec = planned["source_compatibility"]
    assert_snapshot(spec, snapshot)
    if spec.get("captured_input") is not None:
        assert_input(service, spec, snapshot, "compat-before-copy-")
    index = spec["copy_index"]
    if (spec["original_source"] != asdict(snapshot.source) or spec["copy_schema"]["name"] != index
            or index == snapshot.source.index or spec["native_input"] != {
                "endpoint": store.endpoint, "source_index": index, "vector_field": store.fields.vector}):
        raise ContractError("PLAN_CHANGED", "Compatibility copy/native input differs from approved original binding")
    # Reuse the existing publication scope and explicit write/budget approval gate.
    store.publisher._approve(index)
    expected = [normalized(doc, spec["copy_schema"]) for doc in snapshot.source_documents]
    if any(len(canonical_json(doc).encode("utf-8")) > 15 * 1024 * 1024 for doc in snapshot.source_documents):
        raise ContractError("COMPATIBILITY_UNSUPPORTED", "Source document exceeds bounded Search upload size; no copy writes made")
    expected_by_id = {doc[spec["field_mapping"]["key"]]: doc for doc in expected}
    exists = store.target_exists(index)
    if exists:
        if not state.owns_index(planned["plan_id"], index):
            raise ContractError("INDEX_COLLISION", "Never overwrite an unknown compatibility index")
        assert_schema(store, spec)
        present = read_copy(store, spec)
        if any(doc != expected_by_id.get(doc[spec["field_mapping"]["key"]]) for doc in present):
            raise ContractError("COMPATIBILITY_PARITY_FAILED", "Existing copy differs from approved original snapshot")
        if len(present) != len(expected) and not (resume and state.has_reconcile(planned["plan_id"])):
            raise ContractError("RECONCILE_REQUIRED", "Partial compatibility copy requires read-only reconcile and explicit resume")
    else:
        if state.owns_index(planned["plan_id"], index):
            raise ContractError("RECONCILE_REQUIRED", "Previously created compatibility index disappeared; do not recreate it under an old plan")
        definition = spec["copy_schema"]
        if _is_sdk_client(store.index_client):
            from azure.search.documents.indexes.models import SearchIndex
            definition = SearchIndex(definition)
        _journaled_write(state, planned["plan_id"], None, "compatibility", "create-index", index,
                         lambda: store.index_client.create_index(definition),
                         detail={"snapshot_digest": snapshot.digest, "source_index": snapshot.source.index})
        assert_schema(store, spec)
        present = []
    have = {doc[spec["field_mapping"]["key"]] for doc in present}
    missing = [doc for doc in snapshot.source_documents if doc[spec["field_mapping"]["key"]] not in have]
    batch, size = [], 0
    def upload():
        client = store.publisher.search_client(index)
        _journaled_write(state, planned["plan_id"], None, "compatibility", "compatibility-upload", index,
                         lambda: store.publisher._upload_once(client, batch, spec["field_mapping"]["key"]),
                         key_digest=digest([doc[spec["field_mapping"]["key"]] for doc in batch]),
                         detail={"count": len(batch)})
    for doc in missing:
        encoded_size = len(canonical_json(doc).encode("utf-8"))
        if batch and (len(batch) >= 500 or size + encoded_size > 15 * 1024 * 1024):
            upload()
            batch, size = [], 0
        batch.append(doc)
        size += encoded_size
    if batch:
        upload()
    deadline = time.monotonic() + 120
    while True:
        actual = read_copy(store, spec)
        if actual == expected:
            break
        if any(doc != expected_by_id.get(doc[spec["field_mapping"]["key"]]) for doc in actual):
            raise ContractError("COMPATIBILITY_PARITY_FAILED", "Copy changed original IDs, vectors or evidence")
        if time.monotonic() >= deadline:
            raise ContractError("COMPATIBILITY_PARITY_FAILED", "Copy inventory did not settle to original snapshot")
        time.sleep(0.25)
    count = store.publisher.search_client(index).get_document_count()
    if count != spec["document_count"]:
        raise ContractError("COMPATIBILITY_PARITY_FAILED", "Copy count differs from original")
    # Re-read the original after copy writes. Never cluster a copy while the producer refreshes.
    assert_input(service, spec, snapshot, "compat-recheck-")
    for event in state.unresolved_writes(planned["plan_id"]):
        if event["target"] == index and event["phase"] in ("create-index", "compatibility-upload"):
            state.record_write(planned["plan_id"], None, "compatibility", event["phase"], index,
                               key_digest=event["key_digest"], status="reconciled",
                               detail={"snapshot_digest": snapshot.digest, "documents_digest": digest(actual)})
    state.record_write(planned["plan_id"], None, "compatibility", "compatibility-verified", index,
                       status="confirmed", detail={"snapshot_digest": snapshot.digest,
                                                   "documents_digest": digest(actual)})


def verify_native_source(service: Any, spec: dict[str, Any], snapshot: Snapshot) -> None:
    assert_schema(service.store, spec)
    if read_copy(service.store, spec) != [normalized(doc, spec["copy_schema"]) for doc in snapshot.source_documents]:
        raise ContractError("COMPATIBILITY_PARITY_FAILED", "Native input copy changed while clustering")
    assert_input(service, spec, snapshot, "compat-native-recheck-")


def assert_input(service: Any, spec: dict[str, Any], snapshot: Snapshot, prefix: str) -> None:
    capture = spec.get("captured_input")
    if capture is not None:
        from grz_build.captured_input import validate_artifact
        loaded = validate_artifact(capture)
        assert_snapshot(spec, loaded)
        if loaded.digest != snapshot.digest or loaded.source != snapshot.source:
            raise ContractError("CAPTURE_ARTIFACT_INVALID", "Captured authority changed while building")
    else:
        if isinstance(snapshot.source, CapturedSourceIdentity):
            raise ContractError("CAPTURE_ARTIFACT_INVALID", "Captured identity without approved retained authority")
        with tempfile.TemporaryDirectory(prefix=prefix, dir=service.workspace) as folder:
            assert_snapshot(spec, load_snapshot(service.store.export_snapshot(snapshot.source, Path(folder))))
        assert_source_definition(service, spec, snapshot)


def assert_source_definition(service: Any, spec: dict[str, Any], snapshot: Snapshot) -> None:
    if service.store.inspect(snapshot.source)["definition_fingerprint"] != spec["original_schema_fingerprint"]:
        raise ContractError("SOURCE_CHANGED", "Original source schema changed since the approved compatibility plan")
