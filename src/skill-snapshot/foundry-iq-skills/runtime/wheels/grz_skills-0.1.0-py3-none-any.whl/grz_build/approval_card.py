"""One approval card format for every grz-build write gate: apply, publish and retire.

The card is display-only. It is attached to command output after the plan is saved, so it never feeds a plan digest.
"""

from __future__ import annotations

import math
from typing import Any

from grz_core.cli_output import mb
from grz_core.contracts import attestation_text

# Measured live: apply took about 4 min for 7,296 chunks; each naming call took about 2.4 s.
_MIN_PER_1K_CHUNKS = (0.3, 0.7)
_NAMING_SECONDS_PER_CALL = 2.4


def _minutes(low: float, high: float) -> tuple[int, int]:
    lo = max(1, math.floor(low))
    return lo, max(lo + 1, math.ceil(high))


def build(*, what: str, account: dict[str, Any], plan_id: str, changes: list[str],
          minutes: tuple[int, int], one_time_usd: float | None = 0.0, ongoing: str = "none",
          source_content_confirmation: str | None = None) -> dict[str, Any]:
    tenant_id = account.get("tenant_id") or ""
    tenant = f"{account.get('tenant_name') or 'name unavailable'} ({tenant_id[:8]}…)"
    subscription = account.get("subscription_name") or f"{(account.get('subscription_id') or '')[:8]}…"
    group = f"{account.get('resource_group')} (existing)"
    one_time_text = f"about ${one_time_usd:.2f}" if one_time_usd is not None else "unknown"
    lines = [f"APPROVAL: {what}",
             f"Tenant: {tenant} · Subscription: {subscription} · Resource group: {group}",
             f"Plan ID: {plan_id}",
             f"Changes ({len(changes)}):",
             *(f"  {n}. {change}" for n, change in enumerate(changes, 1)),
             *([f"Source content confirmation (not an access change): {source_content_confirmation}"]
               if source_content_confirmation else []),
             f"Time: about {minutes[0]}–{minutes[1]} min",
             f"Cost: {one_time_text} one-time; ongoing: {ongoing}",
             "No automatic retry or cleanup.",
             f'Reply "approved {plan_id}" to proceed.']
    result = {"what": what, "tenant": tenant, "subscription": subscription, "resource_group": group,
              "plan_id": plan_id, "changes": changes, "minutes": list(minutes),
              "one_time_usd": round(one_time_usd, 2) if one_time_usd is not None else None, "ongoing": ongoing,
              "reply": f"approved {plan_id}", "text": "\n".join(lines)}
    if source_content_confirmation:
        result["source_content_confirmation"] = source_content_confirmation
    return result


def for_apply(plan: dict[str, Any], account: dict[str, Any]) -> dict[str, Any]:
    source = plan["source"]
    compatibility = plan.get("source_compatibility") or {}
    community_bytes = plan["estimated_bytes"] - compatibility.get("estimated_copy_bytes", 0)
    changes = [f"Create a new search index {plan['target_index']} on {plan['search_service']}.",
               f"Upload up to {plan['estimated_documents']:,} community documents to it, within a budget of {mb(community_bytes)} "
               "(apply stops before writing if they come out larger)."]
    if compatibility.get("resolved_mode") == "snapshot-copy":
        changes[:0] = [
            f"Create a separate compatibility source index {compatibility['copy_index']} on {plan['search_service']}. "
            f"Copy {compatibility['document_count']:,} original chunks and stored vectors "
            f"({mb(compatibility['estimated_copy_bytes'])} upload; "
            f"estimated {mb(compatibility['estimated_copy_storage_bytes'])} additional indexed storage).",
            f"Leave original source {source['index']} unchanged. The unchanged native builder uses the verified "
            "compatibility copy, not the original index: this is not a direct-handoff pass. "
            "Preserve original IDs, evidence, provenance and vector values; no re-embedding. "
            "Retain the copy after failure or publication; no automatic refresh or cleanup.",
        ]
    capture = compatibility.get("captured_input")
    if capture is not None:
        from grz_build.captured_input import LIMITATION
        interval = capture["manifest"]["capture"]
        changes[:0] = [
            f"Use only retained captured input {capture['capture_id']} at {capture['artifact_path']} "
            f"(manifest SHA-256 {capture['manifest_sha256']}; observed "
            f"{interval['started_at']} to {interval['completed_at']}). {LIMITATION}",
        ]
    budget = plan.get("naming_budget")
    one_time = 0.0
    naming_minutes = (0.0, 0.0)
    if budget:
        one_time = float(budget["max_spend"])
        changes.append(f"Call your model deployment up to {budget['max_calls']} times to name communities "
                       f"(at most {budget['max_tokens']:,} tokens, ${one_time:.2f}).")
        naming_minutes = (budget["max_calls"] * _NAMING_SECONDS_PER_CALL / 120, budget["max_calls"] * _NAMING_SECONDS_PER_CALL / 60)
    readers = plan.get("reader_grants")
    if readers and readers.get("grant"):
        changes.append(f"Grant read access to {len(readers['grant'])} identit{'y' if len(readers['grant']) == 1 else 'ies'} on the new index.")
    attested = plan.get("source_visibility")
    confirmation = attestation_text(attested["index"]) if attested else None
    chunks = source["expected_count"] / 1000
    minutes = _minutes(chunks * _MIN_PER_1K_CHUNKS[0] + naming_minutes[0], chunks * _MIN_PER_1K_CHUNKS[1] + naming_minutes[1] + 1)
    sku = (plan.get("source_binding") or {}).get("search_sku")
    serverless = isinstance(sku, str) and sku.casefold() == "serverless"
    ongoing = "unknown (billable Serverless CU/indexed storage; existing Blob/model usage excluded)" if serverless else "none"
    if serverless:
        changes.append(f"The ${one_time:.2f} model-only maximum excludes billable Serverless compute/indexed storage; total usage cost is unknown.")
    card = build(what=f"build GRZ communities from {source['index']} (local default unchanged until publish)",
                 account=account, plan_id=plan["plan_id"], changes=changes, minutes=minutes,
                 one_time_usd=None if serverless else one_time, ongoing=ongoing,
                 source_content_confirmation=confirmation)
    if serverless:
        card["model_only_max_usd"] = one_time
    return card


def for_publish(generation_id: str, physical_index: str, account: dict[str, Any]) -> dict[str, Any]:
    changes = [f"Select the verified physical index {physical_index} for new readers on this machine.",
               "Other machines and running readers stay pinned; distribute the descriptor explicitly. Completed indexes are retained."]
    return build(what="publish the new communities on this machine", account=account, plan_id=generation_id,
                 changes=changes, minutes=(1, 2))


def for_retire(plan: dict[str, Any], account: dict[str, Any]) -> dict[str, Any]:
    changes = [f"Delete the search index {plan['index']} ({plan['document_count']:,} docs, {mb(plan['storage_bytes'])}). "
               "The published generation and the source index are untouched."]
    readers = plan.get("reader_grants") or []
    if readers:
        changes.append(f"Remove {len(readers)} reader grant(s) on that index.")
    return build(what=f"retire the unexposed staging index {plan['index']}", account=account, plan_id=plan["plan_id"],
                 changes=changes, minutes=(1, 2))
