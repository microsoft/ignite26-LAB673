"""Approval-gated Build: export, cluster, upload, verify and publish one generation."""

from __future__ import annotations

from grz_core.hierarchy import native_coverage, validate_native_forest

import tempfile
import time
import uuid
from contextlib import contextmanager
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterator

from grz_adapters.native_adapter import (
    NativeBuildAdapter,
    PartialCoverage,
)
from grz_build import load_snapshot
from grz_build.inputs import Snapshot
from grz_build.naming import NamingBudget, NamingResult, enrich_assigned_communities, name_communities
from grz_build.naming_azure import MAX_LABEL_CHARS, naming_contexts
from grz_build.planner import approve_plan, plan
from grz_build.readback import check_readback
from grz_build.reader_grants import missing_readers
from grz_build.sidecar_documents import (
    community_documents, documents_bytes, generation_id, hierarchy_digest, manifest_payload,
    provisional_documents_bytes, sidecar_record,
    staging_bytes_estimate,
)
from grz_consume.checks import documents_digest, normalize_document
from grz_core.adapters import BuildStore
from grz_core.contracts import (
    PUBLICATION_VERSION, BuildProfile, ContractError, Descriptor, Source, source_identity, digest, require_publication_version,
)
from grz_core.current import (
    checked_current, commit_current, current_record, grz_home, publication_context, publication_lock,
)
from grz_core.state import State

UPLOAD_BATCH_SIZE = 500


def _visibility_basis(planned: dict[str, Any]) -> str:
    return (planned.get("source_binding") or {}).get("visibility_basis", "per-document")


def _source_binding(store: BuildStore, inspected: dict[str, Any]) -> dict[str, Any] | None:
    binder = getattr(store, "source_binding", None)
    return binder(inspected) if callable(binder) else None


def _ambiguous_write(exc: BaseException) -> bool:
    """A timeout or 5xx may have landed server-side, so the journal must not call it failed."""
    current: BaseException | None = exc
    while current is not None:
        status = getattr(current, "status_code", getattr(getattr(current, "response", None), "status_code", None))
        if status == 408 or (isinstance(status, int) and status >= 500):
            return True
        name = type(current).__name__.lower()
        if "timeout" in name or "connection" in name:
            return True
        current = current.__cause__
    return False


def _journaled_write(state: State, plan_id: str, generation: str | None, stage: str, phase: str, target: str,
                     action: Callable[[], None], *, key_digest: str | None = None,
                     detail: dict[str, Any] | None = None) -> None:
    """Journal intent, run one write, then journal its outcome; never retry here."""
    state.record_write(plan_id, generation, stage, phase, target, key_digest=key_digest, detail=detail)
    try:
        action()
    except BaseException as exc:
        state.record_write(plan_id, generation, stage, phase, target, key_digest=key_digest,
                           status="ambiguous" if _ambiguous_write(exc) else "failed",
                           error_code=getattr(exc, "code", "WRITE_FAILED"), detail=detail)
        raise
    state.record_write(plan_id, generation, stage, phase, target, key_digest=key_digest, status="confirmed", detail=detail)


def _check_upload(results: list[dict[str, Any]], expected: int, message: str) -> None:
    if len(results) != expected or any(not result.get("succeeded") for result in results):
        raise ContractError("UPLOAD_FAILED", message)


class BuildService:
    def __init__(self, store: BuildStore, state: State, workspace: Path, *,
                 native_adapter: NativeBuildAdapter | None = None):
        self.store, self.state, self.workspace = store, state, Path(workspace)
        self.native_adapter = native_adapter or NativeBuildAdapter()
        self.workspace.mkdir(parents=True, exist_ok=True)

    def inspect(self, source: Source) -> dict[str, Any]:
        source.validate()
        return self.store.inspect(source)

    def plan(self, source: Source, profile: BuildProfile,
             naming_budget: NamingBudget | None = None) -> dict[str, Any]:
        inspected = self.inspect(source)
        return plan(source, profile, target_service=source.service,
                    publication=publication_context({"endpoint": source.service, "source_index": source.index,
                                                     "tenant_id": getattr(self.store, "tenant_id", "")}),
                    inspected=inspected, naming_budget=naming_budget)

    def _await_ids(self, index: str, expected_ids: set[str], timeout_seconds: float = 120) -> list[dict[str, Any]]:
        # Search indexing is near-real-time: uploaded keys, and the document count, can lag the upload.
        deadline = time.monotonic() + timeout_seconds
        delay = 0.25
        while True:
            try:
                observed = self.store.readback(index)
            except ContractError as exc:
                if exc.code != "READBACK_NOT_SETTLED" or time.monotonic() >= deadline:
                    raise
                observed = None
            if observed is not None and {d["id"] for d in observed} == expected_ids and len(observed) == len(expected_ids):
                return observed
            if time.monotonic() >= deadline:
                raise ContractError("READBACK_MISMATCH", "Physical index records not visible before timeout")
            time.sleep(min(delay, max(0, deadline - time.monotonic())))
            delay = min(delay * 2, 8)

    def compute_local_sidecar(
        self,
        planned: dict[str, Any],
        plan_id: str,
        approved_budget_bytes: int,
        *,
        naming_provider: Callable[[str, float], NamingResult] | None = None,
        naming_approved: bool = False,
    ) -> tuple[Descriptor, list[dict[str, Any]], dict[str, Any], PartialCoverage]:
        """Compute the full local sidecar without publishing or uploading to an Azure output index.

        Keeps Azure output-index publication separate from local sidecar computation.
        """
        approve_plan(planned, plan_id, approved_budget_bytes)
        if (planned.get("source_compatibility") or {}).get("resolved_mode") == "snapshot-copy":
            raise ContractError("WRITE_CONFIRMATION_REQUIRED", "Local-only computation cannot create the approved compatibility index; use apply")
        source = source_identity(planned["source"])
        profile = BuildProfile(**planned["profile"])
        inspected = self.inspect(source)
        binding = self._check_source_matches_plan(planned, inspected)
        timings: dict[str, int] = {}
        with tempfile.TemporaryDirectory(prefix="grz-export-", dir=self.workspace) as folder:
            snapshot = self._export_frozen(source, Path(folder), binding if binding is not None else inspected, timings)
            with self.state.publisher_lock():
                generation, index, documents, manifest_doc, coverage = self._build_documents(
                    planned, snapshot, source, profile, approved_budget_bytes, naming_provider, naming_approved,
                    scratch_dir=Path(folder),
                )
            descriptor = Descriptor(
                physical_index=index,
                generation_id=generation,
                source_service=source.service,
                source_index=source.index,
                embedding_model_id=source.embedding_model_id,
                dimension=source.dimension,
                visibility=source.visibility,
                visibility_basis=_visibility_basis(planned),
            )
            return descriptor, documents, manifest_doc, coverage

    def apply(self, planned: dict[str, Any], plan_id: str, approved_budget_bytes: int, *,
              naming_provider: Callable[[str, float], NamingResult] | None = None,
              naming_approved: bool = False, resume_after_reconcile: bool = False) -> Descriptor:
        approve_plan(planned, plan_id, approved_budget_bytes)
        source = source_identity(planned["source"])
        profile = BuildProfile(**planned["profile"])
        with self.state.publisher_lock():
            self._check_naming_usage(plan_id)
            if planned.get("target_index") and (self.state.unresolved_writes(plan_id)
                    or (self.state.resume_required(plan_id) and not resume_after_reconcile)):
                raise ContractError("RECONCILE_REQUIRED", "Reconcile every unresolved write, then explicitly approve resume with --resume-after-reconcile")
            if self.state.resume_required(plan_id):
                self.state.record_write(plan_id, None, "apply", "resume-approved", planned["target_index"], status="confirmed")
            capture = (planned.get("source_compatibility") or {}).get("captured_input")
            retained_snapshot = None
            if capture is not None:
                from grz_build.captured_input import validate_artifact
                from grz_build.compatibility import assert_snapshot
                retained_snapshot = validate_artifact(capture)
                assert_snapshot(planned["source_compatibility"], retained_snapshot)
                if retained_snapshot.source != source:
                    raise ContractError("CAPTURE_ARTIFACT_INVALID", "Captured authority differs from approved source")
                before, binding = None, None
            else:
                if planned["source"].get("input_kind") == "immutable-capture":
                    raise ContractError("CAPTURE_ARTIFACT_INVALID", "Captured source requires retained authority")
                before = self.inspect(source)
                binding = self._check_source_matches_plan(planned, before)
            self._check_target_index_free(planned, plan_id)
            if self.state.retiring_index(planned.get("target_index", "")):
                raise ContractError("RETIRE_TARGET_PROTECTED", "This staging index has a retirement intent; reconcile it, never resume apply")
            self.state.record(plan_id, None, "apply", "running", expected={"evidence": source.expected_count})
            timings: dict[str, int] = {}
            generation: str | None = None
            try:
                with tempfile.TemporaryDirectory(prefix="grz-export-", dir=self.workspace) as folder:
                    snapshot = retained_snapshot if retained_snapshot is not None else self._export_frozen(
                        source, Path(folder), binding if binding is not None else before, timings)
                    if (planned.get("source_compatibility") or {}).get("resolved_mode") == "snapshot-copy":
                        from grz_build.compatibility import prepare_copy
                        prepare_copy(self, planned, snapshot, resume=resume_after_reconcile)
                    copy_bytes = (planned.get("source_compatibility") or {}).get("estimated_copy_bytes", 0)
                    phase_started = time.perf_counter()
                    generation, index, documents, manifest_doc, _coverage = self._build_documents(
                        planned, snapshot, source, profile, approved_budget_bytes - copy_bytes, naming_provider, naming_approved,
                        scratch_dir=Path(folder))
                    try:
                        retained = self.state.generation(generation)
                    except ContractError as exc:
                        if exc.code != "GENERATION_UNKNOWN":
                            raise
                    else:
                        require_publication_version(retained)
                        if retained["plan_id"] != plan_id:
                            raise ContractError("GENERATION_CHANGED", "This same-content generation is already bound to another approval in this state directory. Select its retained physical descriptor explicitly; do not rebuild it here to refresh publication approval. No index or grant writes were made.")
                    self._upload_generation(plan_id, generation, index, documents, manifest_doc, source,
                                            (planned.get("reader_grants") or {}).get("grant", []),
                                            planned["publication"]["binding"])
                    timings["build_and_upload"] = int((time.perf_counter() - phase_started) * 1000)
                    counts = manifest_doc["payload"]["counts"]
                    return self._save_candidate(planned, plan_id, generation, index, source,
                                                timings, counts)
            except (ContractError, ValueError, OSError) as exc:
                self.state.record(plan_id, generation, "apply", "failed", error_code=getattr(exc, "code", "BUILD_FAILED"))
                raise

    def _check_naming_usage(self, plan_id: str) -> None:
        attempts = [event for event in self.state.write_events()
                    if event.get("plan_id") == plan_id and event.get("phase") == "naming-usage"]
        unknown = any(event.get("error_code") == "NAMING_USAGE_UNKNOWN" for event in attempts)
        unknown = unknown or bool(attempts and attempts[-1].get("status") in {"intent", "ambiguous"})
        unknown = unknown or any(event.get("operation_id") == plan_id
                                 and event.get("error_code") == "NAMING_USAGE_UNKNOWN"
                                 for event in self.state.events())
        if unknown:
            raise ContractError("NAMING_USAGE_UNKNOWN",
                                "This plan has unknown prior inference usage; Search reconcile cannot resolve billing. "
                                "Review provider usage and explicitly approve a new budget before more calls")

    @contextmanager
    def _naming_attempt(self, planned: dict[str, Any],
                        provider: Callable[[str, float], NamingResult] | None,
                        approved: bool) -> Iterator[None]:
        budget = planned.get("naming_budget")
        if provider is None or budget is None or not approved:
            yield
            return
        NamingBudget(**budget).validate()
        plan_id = planned["plan_id"]
        self._check_naming_usage(plan_id)
        self.state.record_write(plan_id, None, "apply", "naming-usage", "model-naming", status="intent")
        try:
            yield
        except ContractError as exc:
            self.state.record_write(plan_id, None, "apply", "naming-usage", "model-naming",
                                    status="ambiguous" if exc.code == "NAMING_USAGE_UNKNOWN" else "failed",
                                    error_code=exc.code, detail={"usage": getattr(provider, "usage", None)})
            raise
        else:
            self.state.record_write(plan_id, None, "apply", "naming-usage", "model-naming",
                                    status="confirmed", detail={"usage": getattr(provider, "usage", None)})

    def _check_source_matches_plan(self, planned: dict[str, Any], inspected: dict[str, Any]) -> dict[str, Any] | None:
        binding = _source_binding(self.store, inspected)
        if binding is not None:
            if binding != planned.get("source_binding"):
                raise ContractError("SOURCE_CHANGED", "Source definition, count or vector binding changed since approved plan")
        elif digest(inspected) != planned["source_inspection_digest"]:
            raise ContractError("SOURCE_CHANGED", "Source schema or field mapping changed since approved plan")
        return binding

    def _check_target_index_free(self, planned: dict[str, Any], plan_id: str) -> None:
        target_index = planned.get("target_index")
        target_exists = getattr(self.store, "target_exists", None)
        if target_index and callable(target_exists) and target_exists(target_index) and not self.state.owns_index(plan_id, target_index):
            raise ContractError("INDEX_COLLISION", "Planned target index already exists outside this journal")

    def _export_frozen(self, source: Source, folder: Path, pre_export: dict[str, Any],
                       timings: dict[str, int]) -> Snapshot:
        """Export, then re-inspect: any change to the source during export invalidates the snapshot."""
        started = time.perf_counter()
        manifest = self.store.export_snapshot(source, folder)
        timings["export"] = int((time.perf_counter() - started) * 1000)
        snapshot = load_snapshot(manifest)
        after_export = self.inspect(source)
        after_binding = _source_binding(self.store, after_export)
        if snapshot.source != source or (after_binding if after_binding is not None else after_export) != pre_export:
            raise ContractError("SOURCE_CHANGED", "Frozen source identity/schema/stats changed during export")
        return snapshot

    def _cluster_native(
        self,
        planned: dict[str, Any],
        snapshot: Snapshot,
        source: Source,
        profile: BuildProfile,
        scratch_dir: Path,
    ) -> tuple[list[dict[str, Any]], PartialCoverage]:
        """Cluster vectors using the native binary orchestration adapter."""
        from grz_adapters.native_adapter import build_native_config

        native_out = scratch_dir / "native-output"
        native_out.mkdir(parents=True, exist_ok=True)
        binding = planned.get("source_binding") or {}
        live = planned.get("backend") == "azure"
        vector_field = (binding.get("vector_field") if live else
                        binding.get("vector_field") or planned.get("source", {}).get("vector_field"))
        if live and (not isinstance(vector_field, str) or not vector_field.strip()):
            raise ContractError("NATIVE_SOURCE_BINDING_INVALID",
                                "Live native execution requires the approved vector-field binding")
        api_version = binding.get("search_api_version") if live else binding.get("search_api_version", "2025-09-01")
        tenant_id = planned.get("tenant_id") if live else getattr(self.store, "tenant_id", None)
        if live and (not isinstance(tenant_id, str) or not tenant_id.strip()
                     or not isinstance(api_version, str) or not api_version.strip()):
            raise ContractError("NATIVE_SOURCE_BINDING_INVALID",
                                "Live native execution requires an explicit tenant and Search API")
        config = build_native_config(
            endpoint=getattr(self.store, "endpoint", f"https://{source.service}.search.windows.net"),
            source_index=source.index,
            vector_field=vector_field if vector_field is not None else "vector",
            api_version=api_version,
            output_directory=native_out,
            auth_mode=planned.get("auth_mode", "defaultAzureCredential"),
            tenant_id=tenant_id,
        )
        compatibility = planned.get("source_compatibility") or {}
        if compatibility.get("resolved_mode") == "snapshot-copy":
            from grz_build.compatibility import assert_snapshot
            assert_snapshot(compatibility, snapshot)
            if compatibility.get("captured_input") is not None:
                from grz_build.compatibility import assert_input
                assert_input(self, compatibility, snapshot, "compat-before-native-")
            config["search"].update(
                endpoint=compatibility["native_input"]["endpoint"],
                sourceIndex=compatibility["native_input"]["source_index"],
                vectorField=compatibility["native_input"]["vector_field"])
        hierarchy, coverage, _cli_res = self.native_adapter.build_from_config(config, dimension=source.dimension)
        if compatibility.get("resolved_mode") == "snapshot-copy":
            from grz_build.compatibility import verify_native_source
            verify_native_source(self, compatibility, snapshot)
            known = set(snapshot.ids)
            if coverage.source_document_count != source.expected_count or any(
                    not set(community.members) <= known for level in hierarchy for community in level.values()):
                raise ContractError("COMPATIBILITY_PARITY_FAILED", "Native results differ from authoritative original source IDs/count")
        return hierarchy, coverage

    def _build_documents(self, planned: dict[str, Any], snapshot: Snapshot, source: Source,
                         profile: BuildProfile, approved_budget_bytes: int,
                         naming_provider: Callable[[str, float], NamingResult] | None,
                         naming_approved: bool,
                         scratch_dir: Path | None = None) -> tuple[str, str, list[dict[str, Any]], dict[str, Any], PartialCoverage]:
        scratch = scratch_dir or self.workspace
        centroids, coverage = self._cluster_native(planned, snapshot, source, profile, scratch)
        validate_native_forest(
            {f"{level}:{local}": {
                "level": level, "parent_id": f"{level + 1}:{c.parent}" if c.parent is not None else None,
                "member_count": len(c.members),
            } for level, communities in enumerate(centroids) for local, c in communities.items()},
            {f"{level}:{local}": set(c.members)
             for level, communities in enumerate(centroids) for local, c in communities.items()},
            set(snapshot.ids), asdict(coverage))
        staging_bytes = staging_bytes_estimate(snapshot, centroids, source.dimension)
        if staging_bytes > profile.memory_budget_bytes:
            raise ContractError("MEMORY_BUDGET_EXCEEDED", "Predicted sidecar document staging exceeds configured memory")
        budget_spec = planned.get("naming_budget")
        if budget_spec is not None and naming_provider is None:
            raise ContractError("NAMING_PROVIDER_REQUIRED", "Approved naming plan needs an injected provider")
        if budget_spec is not None:
            # Stop before any model spend: naming can't shrink the documents below this bound.
            bound = provisional_documents_bytes(centroids, snapshot, source, MAX_LABEL_CHARS)
            if bound > approved_budget_bytes:
                raise ContractError("BUDGET_APPROVAL_REQUIRED",
                                    f"Documents could reach {bound} bytes, over the approved {approved_budget_bytes}; "
                                    "no model calls or community index writes were made")
        local_keys = [f"{level}:{local}" for level, communities in enumerate(centroids) for local in sorted(communities)]
        contexts, reserve_tokens, reserve_spend = None, 0, 0.0
        model = planned.get("naming_model")
        if model is not None and naming_provider is not None:
            contexts = naming_contexts(snapshot, centroids, members_per_prompt=model["members_per_prompt"],
                                       excerpt_chars=model["excerpt_chars"])
            local_keys = list(contexts)
            # Roughly 4 characters per token, plus the system prompt, rounded up.
            reserve_tokens = max(len(c) for c in contexts.values()) // 3 + 200 + model["max_output_tokens"]
            reserve_spend = reserve_tokens * max(model["input_price_per_1m"], model["output_price_per_1m"]) / 1_000_000
        with self._naming_attempt(planned, naming_provider, naming_approved):
            labels = enrich_assigned_communities(local_keys, naming_provider, NamingBudget(**budget_spec) if budget_spec else None,
                                                 approved=naming_approved, contexts=contexts, reserve_tokens=reserve_tokens,
                                                 reserve_spend=reserve_spend)
        hierarchy = hierarchy_digest(centroids)
        generation = generation_id(snapshot, profile, hierarchy, labels)
        if (planned.get("source_compatibility") or {}).get("resolved_mode") == "snapshot-copy":
            generation = digest({"generation_id": generation,
                                 "source_compatibility": planned["source_compatibility"]})
        index = planned.get("target_index") or self.store.generation_index_name(generation)
        documents = community_documents(generation, centroids, labels, snapshot, source)
        actual = documents_bytes(documents)
        if actual > approved_budget_bytes:
            raise ContractError("BUDGET_APPROVAL_REQUIRED",
                                f"Documents are {actual} bytes, over the approved community budget {approved_budget_bytes}; no community index writes were made")
        payload = manifest_payload(
            generation=generation, index=index, source=source, documents=documents, snapshot=snapshot,
            hierarchy=hierarchy, labels=labels, graph_edges=coverage.graph_edge_count, levels=len(centroids),
            staging_bytes=staging_bytes, visibility_basis=_visibility_basis(planned),
            partial_coverage=asdict(coverage))
        if (planned.get("source_compatibility") or {}).get("resolved_mode") == "snapshot-copy":
            payload["source_compatibility"] = planned["source_compatibility"]
        return generation, index, documents, sidecar_record(generation, "manifest", "reserved-manifest", payload=payload), coverage

    def _upload_generation(self, plan_id: str, generation: str, index: str, documents: list[dict[str, Any]],
                           manifest_doc: dict[str, Any], source: Source,
                           readers: list[dict[str, Any]] = (), binding: dict[str, Any] | None = None) -> None:
        """Create the index, grant planned readers, upload community/evidence docs, then add the manifest."""
        check_readback([*documents, manifest_doc], generation, source)
        if (native_coverage(manifest_doc["payload"]) is None
                and callable(getattr(self.store, "compatibility_probe", None))) and any(
            doc["kind"] == "representative" and "centroid" not in doc for doc in documents
        ):
            raise ContractError("NATIVE_REPRESENTATIVE_MISSING", "Vector-required publication needs actual native representatives before any index, grant or upload writes")
        present = self._existing_or_new_index(plan_id, generation, index, [*documents, manifest_doc], source, binding)
        self._grant_readers(plan_id, generation, index, readers)
        for start in range(0, len(documents), UPLOAD_BATCH_SIZE):
            batch = [d for d in documents[start:start + UPLOAD_BATCH_SIZE] if d["id"] not in present]
            if batch:
                _journaled_write(
                    self.state, plan_id, generation, "apply", "upload-batch", index,
                    lambda batch=batch: _check_upload(self.store.upload_batch(index, batch), len(batch),
                                                      "Unresolved partial document upload"),
                    key_digest=digest([d["id"] for d in batch]), detail={"count": len(batch)})
        manifest_present = manifest_doc["id"] in present
        visible = self._await_ids(index, {d["id"] for d in documents} | ({manifest_doc["id"]} if manifest_present else set()))
        uploaded = [d for d in visible if d["kind"] != "manifest"]
        if len(uploaded) != len(documents) or documents_digest(uploaded) != manifest_doc["payload"]["documents_digest"]:
            raise ContractError("READBACK_MISMATCH", "Uploaded records not visible or not identical")
        if not manifest_present:
            self.state.record_write(plan_id, generation, "apply", "retention-protect", index, status="confirmed")
            _journaled_write(
                self.state, plan_id, generation, "apply", "manifest-upload", index,
                lambda: _check_upload(self.store.upload_batch(index, [manifest_doc]), 1, "Manifest upload failed"),
                key_digest=digest([manifest_doc["id"]]))
        self._await_ids(index, {d["id"] for d in [*documents, manifest_doc]})
        self.verify(generation, index, source)

    def _grant_readers(self, plan_id: str, generation: str, index: str, readers: list[dict[str, Any]]) -> None:
        """Each physical generation needs its own approved index-scoped grants."""
        if not readers:
            return
        grants = getattr(self.store, "reader_grants", None)
        if grants is None:
            raise ContractError("READER_GRANTS_UNSUPPORTED", "This backend can't grant readers; re-plan without readers")
        for wanted in readers:
            _journaled_write(self.state, plan_id, generation, "apply", "reader-grant", index,
                             lambda wanted=wanted: grants.grant(index, wanted),
                             key_digest=digest([wanted["principal_id"], wanted["role_definition_id"]]),
                             detail={"principal_id": wanted["principal_id"], "role": wanted["role"]})

    def _check_readers_follow(self, record: dict[str, Any], current: str | None, new_index: str) -> None:
        """Check both approved readers and readers added to the previous physical index."""
        grants = getattr(self.store, "reader_grants", None)
        wanted = (record.get("reader_grants") or {}).get("grant", [])
        if grants is None:
            if wanted:
                raise ContractError("READER_GRANTS_UNSUPPORTED", "Cannot verify approved reader assignments")
            return
        dropped = (record.get("reader_grants") or {}).get("dropped", [])
        carried = grants.list(current) if current and current != new_index else []
        missing = missing_readers([*carried, *wanted], grants.list(new_index), dropped)
        if missing:
            raise ContractError("READERS_MISSING", f"{len(missing)} reader(s) can't read {new_index} yet: "
                                f"{', '.join(missing)}. Next step: run apply again with the same plan, or re-plan "
                                "with --drop-reader for each one you mean to remove.")

    def _existing_or_new_index(self, plan_id: str, generation: str, index: str,
                               expected: list[dict[str, Any]], source: Source,
                               binding: dict[str, Any] | None = None) -> set[str]:
        """Resume only missing immutable keys; reject changed content or index-name collisions."""
        expected_by_id = {d["id"]: d for d in expected}
        if self.state.retiring_index(index):
            raise ContractError("RETIRE_TARGET_PROTECTED", "A retired or retiring index cannot be reused")
        try:
            existing = self.store.readback(index)
        except ContractError as exc:
            if exc.code != "INDEX_MISSING":
                raise
            _journaled_write(self.state, plan_id, generation, "apply", "create-index", index,
                             lambda: self.store.create_generation_index(index, source.dimension),
                             detail={"publication_version": PUBLICATION_VERSION, "binding": binding,
                                     **({"input_kind": "immutable-capture"}
                                        if getattr(source, "input_kind", None) == "immutable-capture" else {})})
            return set()
        if not self.state.owns_index(plan_id, index):
            raise ContractError("INDEX_COLLISION", "Existing physical index is not owned by this journal")
        if any(d["generation_id"] != generation for d in existing):
            raise ContractError("INDEX_COLLISION", "Truncated index-name digest collision")
        if len({d["id"] for d in existing}) != len(existing):
            raise ContractError("READBACK_MISMATCH", "Duplicate keys in generation index")
        if any(d["id"] not in expected_by_id or normalize_document(d) != normalize_document(expected_by_id[d["id"]])
               for d in existing):
            raise ContractError("REPRODUCIBILITY_DEVIATION", "Existing generation output differs")
        return {d["id"] for d in existing}

    def _save_candidate(self, planned: dict[str, Any], plan_id: str, generation: str, index: str,
                        source: Source, timings: dict[str, int],
                        counts: dict[str, int]) -> Descriptor:
        descriptor = Descriptor(index, generation, source.service, source.index,
                                source.embedding_model_id, source.dimension,
                                visibility_basis=_visibility_basis(planned),
                                source_compatibility=(planned.get("source_compatibility")
                                                      if (planned.get("source_compatibility") or {}).get("resolved_mode") == "snapshot-copy"
                                                      else None))
        built_at = datetime.now(timezone.utc).isoformat()
        candidate = {
            "descriptor": descriptor.to_dict(),
            "publication_version": PUBLICATION_VERSION, "publication": planned["publication"], "plan_id": plan_id,
            "status": "verified", "source": asdict(source), "source_binding": planned.get("source_binding"),
            "timings_ms": timings, "built_at": built_at,
            "inventory_digest": digest(sorted(self.store.readback(index), key=lambda row: row["id"])),
        }
        if planned.get("reader_grants"):
            candidate["reader_grants"] = planned["reader_grants"]
        if planned.get("source_compatibility"):
            candidate["source_compatibility"] = planned["source_compatibility"]
        try:
            previous = self.state.generation(generation)
        except ContractError as exc:
            if exc.code != "GENERATION_UNKNOWN":
                raise
            self.state.save_generation(generation, candidate)
        else:
            if (previous["descriptor"] != candidate["descriptor"] or previous["plan_id"] != plan_id
                    or previous["source"] != candidate["source"]):
                raise ContractError("GENERATION_CHANGED", "Saved generation approval/identity differs")
        self.state.record(plan_id, generation, "apply", "verified", expected=counts, observed=counts, evidence_ids=[index])
        self.state.record_write(plan_id, generation, "apply", "built-at", index, status="confirmed", detail={"built_at": built_at})
        return descriptor
    def verify(self, generation: str, index: str, source: Source) -> dict[str, int]:
        started = time.perf_counter()
        documents = self.store.readback(index)
        if source.__dict__.get("input_kind") == "immutable-capture":
            payload = next((doc["payload"] for doc in documents if doc["kind"] == "manifest"), {})
            spec = payload.get("source_compatibility") or {}
            from grz_build.captured_input import validate_artifact
            from grz_build.compatibility import assert_snapshot
            snapshot = validate_artifact(spec.get("captured_input"))
            assert_snapshot(spec, snapshot)
            if snapshot.source != source:
                raise ContractError("CAPTURE_ARTIFACT_INVALID", "Generation differs from captured source authority")
        counts = check_readback(documents, generation, source)
        self.store.verify(index, documents)
        probe = getattr(self.store, "compatibility_probe", None)
        if callable(probe):
            representatives = [doc for doc in documents if doc.get("kind") == "representative"]
            payload = next(doc["payload"] for doc in documents if doc["kind"] == "manifest")
            if native_coverage(payload) is not None:
                representatives = [doc for doc in representatives if "centroid" in doc]
            if representatives:
                probe(index, generation, representatives, 5)
        try:
            record = self.state.generation(generation)
            operation_id = record.get("plan_id", generation)
        except ContractError:
            operation_id = generation
        self.state.record(operation_id, generation, "verify", "verified", expected=counts, observed=counts, evidence_ids=[index])
        self.state.record_write(operation_id, generation, "verify", "readback", index, status="confirmed", detail={"timings_ms": {"verify": int((time.perf_counter() - started) * 1000)}})
        return counts

    def _verify_publication(self, generation: str, record: dict[str, Any]) -> Descriptor:
        descriptor = Descriptor(**record["descriptor"])
        if "source" not in record:
            raise ContractError("SOURCE_IDENTITY_MISSING", "Cannot verify without the saved source contract")
        self.verify(generation, descriptor.physical_index, source_identity(record["source"]))
        observed = digest(sorted(self.store.readback(descriptor.physical_index), key=lambda row: row["id"]))
        if observed != record["inventory_digest"]:
            raise ContractError("PUBLICATION_VERIFY_FAILED", "Physical generation changed since apply verification")
        previous = record["publication"].get("previous_descriptor")
        self._check_readers_follow(record, previous["physical_index"] if previous else None, descriptor.physical_index)
        return descriptor

    def publish(self, generation: str, *, approved: bool = False) -> Descriptor:
        if not approved:
            raise ContractError("PUBLISH_APPROVAL_REQUIRED", "Local descriptor publication requires separate approval")
        with publication_lock(), self.state.publisher_lock():
            record = self.state.generation(generation)
            require_publication_version(record)
            descriptor = Descriptor(**record["descriptor"])
            if not any(e.get("generation_id") == generation and e.get("stage") == "verify" and e.get("state") == "verified" for e in self.state.events()):
                raise ContractError("PUBLICATION_VERIFY_REQUIRED", "Verify must be journaled before publication")
            publication = record["publication"]
            if publication.get("home") != str(grz_home().resolve()):
                raise ContractError("PUBLISH_BINDING_MISMATCH", "GRZ_HOME differs from the approved plan")
            current = checked_current()
            if any(e.get("phase") == "publish-current" for e in self.state.unresolved_writes(record["plan_id"])):
                raise ContractError("RECONCILE_REQUIRED", "Reconcile the uncertain local publication before retrying")
            if record.get("published_current") == current and record["status"] == "published":
                return self._verify_publication(generation, record)
            if digest(current) != publication["expected_current"]:
                raise ContractError("PUBLICATION_CHANGED", "Local selection changed since planning. Use the verified generation's existing descriptor explicitly; this stale approval cannot change the local default.")
            self._verify_publication(generation, record)
            pointer = current_record(
                descriptor.to_dict(), endpoint=publication["binding"]["endpoint"], auth="entra",
                tenant_id=publication["binding"].get("tenant_id", ""),
                publication={"publication_version": PUBLICATION_VERSION, "binding": publication["binding"],
                             "publication_revision": uuid.uuid4().hex})
            detail = {"expected_current": publication["expected_current"], "current": pointer,
                      "descriptor_digest": digest(descriptor.to_dict())}
            self.state.record_write(record["plan_id"], generation, "publish", "publish-current",
                                    descriptor.physical_index, detail=detail)
            try:
                commit_current(descriptor.to_dict(), pointer)
                record.update(status="published", published_current=pointer)
                self.state.save_generation(generation, record)
                self.state.record(record["plan_id"], generation, "publish", "published", evidence_ids=[descriptor.physical_index])
                self.state.record_write(record["plan_id"], generation, "publish", "publish-current",
                                        descriptor.physical_index, status="confirmed", detail=detail)
            except (OSError, ContractError) as exc:
                self.state.record_write(record["plan_id"], generation, "publish", "publish-current",
                                        descriptor.physical_index, status="ambiguous", detail=detail,
                                        error_code="PUBLICATION_UNCERTAIN")
                raise ContractError("PUBLICATION_UNCERTAIN", "Local publication needs reconciliation; no automatic retry or rollback") from exc
            return descriptor

    def status(self) -> dict[str, Any]:
        events = self.state.events()
        latest = {event["generation_id"]: event for event in events if event["generation_id"]}
        incomplete = [generation for generation, event in latest.items() if event["state"] == "failed"]
        current = checked_current()
        return {"local_current": current, "active_physical_index": current["physical_index"] if current else None,
                "incomplete_generations": incomplete, "events": events, "writes": self.state.write_events(),
                "recovery": "Retry the same approved plan for missing immutable keys; inspect failed indexes; never delete automatically"}

    def reconcile(self, planned: dict[str, Any]) -> dict[str, Any]:
        require_publication_version(planned)
        with publication_lock(), self.state.publisher_lock():
            return self._reconcile(planned)

    def _reconcile(self, planned: dict[str, Any]) -> dict[str, Any]:
        plan_id = planned["plan_id"]
        if digest({k: v for k, v in planned.items() if k != "plan_id"}) != plan_id:
            raise ContractError("PLAN_CHANGED", "Reconcile needs the exact approved plan")
        if planned["publication"].get("home") != str(grz_home().resolve()):
            raise ContractError("PUBLISH_BINDING_MISMATCH", "Reconcile must use the approved GRZ_HOME")
        pending = self.state.unresolved_writes(plan_id)
        for event in pending:
            if event["phase"] != "publish-current":
                continue
            record = self.state.generation(event["generation_id"])
            require_publication_version(record)
            detail = event["detail"]
            current = checked_current()
            if current == detail["current"]:
                if digest(record["descriptor"]) != detail["descriptor_digest"]:
                    raise ContractError("DESCRIPTOR_CHANGED", "Publication intent and generation descriptor differ")
                if record["plan_id"] != plan_id or record["descriptor"]["physical_index"] != event["target"]:
                    raise ContractError("PUBLISH_BINDING_MISMATCH", "Publication intent differs from the generation record")
                self._verify_publication(event["generation_id"], record)
                record.update(status="published", published_current=current)
                self.state.save_generation(event["generation_id"], record)
                self.state.record(plan_id, event["generation_id"], "publish", "published", evidence_ids=[event["target"]])
                outcome = "committed"
            elif digest(current) == detail["expected_current"]:
                outcome = "not-committed"
            else:
                raise ContractError("PUBLICATION_CHANGED", "A later local selection exists; reconciliation will not overwrite it")
            self.state.record_write(plan_id, event["generation_id"], "publish", "publish-current", event["target"],
                                    status="reconciled", detail={**detail, "outcome": outcome})
        target = planned.get("target_index")
        if not target:
            raise ContractError("RECONCILE_UNSUPPORTED", "Reconcile requires a planned target index")
        target_exists = True
        try:
            docs = self.store.readback(target)
        except ContractError as exc:
            if exc.code == "INDEX_MISSING":
                docs = []
                target_exists = False
            else:
                raise
        present = sorted(doc.get("id") for doc in docs if isinstance(doc, dict) and doc.get("id"))
        intents = [e for e in self.state.write_events() if e.get("plan_id") == plan_id and e.get("status") == "intent"
                   and e.get("phase") in {"upload-batch", "manifest-upload"}]
        intended_count = sum(int((e.get("detail") or {}).get("count", 1)) for e in intents)
        summary = {"target_index": target, "target_exists": target_exists,
                   "intended_count": intended_count, "present_count": len(present),
                   "missing_count": max(intended_count - len(present), 0),
                   "present_digest": digest(present),
                   "unresolved": self.state.unresolved_writes(plan_id)}
        compatibility = planned.get("source_compatibility") or {}
        if compatibility.get("resolved_mode") == "snapshot-copy":
            from grz_build.compatibility import assert_schema, read_copy
            capture = compatibility.get("captured_input")
            if capture is not None:
                from grz_build.captured_input import validate_artifact
                from grz_build.compatibility import assert_snapshot
                assert_snapshot(compatibility, validate_artifact(capture))
            copy_index = compatibility["copy_index"]
            exists = self.store.target_exists(copy_index)
            if exists:
                if not self.state.owns_index(plan_id, copy_index):
                    raise ContractError("INDEX_COLLISION", "Reconcile cannot adopt an unknown compatibility index")
                assert_schema(self.store, compatibility)
                copy_rows = read_copy(self.store, compatibility)
            else:
                copy_rows = []
            summary["source_compatibility"] = {
                "copy_index": copy_index, "exists": exists, "present_count": len(copy_rows),
                "expected_count": compatibility["document_count"], "original_source": compatibility["original_source"],
                "snapshot_digest": compatibility["snapshot_digest"], "parity_verified": False,
                "next_step": ("Explicit resume loads only the retained captured bytes and verifies every existing copy record before any write."
                              if capture is not None else
                              "Explicit resume reexports the original and verifies every existing copy record before any write.")}
        self.state.record_write(plan_id, None, "reconcile", "readback", target, status="reconciled", detail=summary)
        resumable_phases = {"create-index", "upload-batch", "manifest-upload", "reader-grant", "compatibility-upload"}
        if any(event["phase"] in resumable_phases for event in pending):
            self.state.record_write(plan_id, None, "reconcile", "resume-required", target, status="confirmed")
        for event in pending:
            if event["phase"] in resumable_phases:
                detail = {"readback_digest": summary["present_digest"]}
                if compatibility.get("resolved_mode") == "snapshot-copy" and event["target"] == compatibility["copy_index"]:
                    detail = {"readback_digest": digest(copy_rows), "parity_verified": False,
                              "resume_requires_original_recheck": True}
                self.state.record_write(plan_id, event.get("generation_id"), event["operation"], event["phase"],
                                        event["target"], key_digest=event.get("key_digest"), status="reconciled",
                                        detail=detail)
        return summary
