"""Approval-gated publisher for new, generation-scoped Azure Search sidecars."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from typing import Any

from grz_core.contracts import ContractError, digest, require_public

from .azure_source import get_field
from .sidecar_schema import (
    check_created_index, generation_index_definition, load_sidecar_schema, prepare_document, sdk_index_model,
)

# Leave 1 MiB below Search's 16 MiB request limit for SDK serialization changes.
MAX_UPLOAD_BYTES = 15 * 1024 * 1024


def _upload_batches(documents: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    envelope_bytes = len(b'{"value": []}')
    batches: list[list[dict[str, Any]]] = []
    batch: list[dict[str, Any]] = []
    size = envelope_bytes
    for doc in documents:
        try:
            action_bytes = len(json.dumps(
                {"@search.action": "upload", **doc}, ensure_ascii=True, allow_nan=False,
            ).encode("utf-8"))
        except (TypeError, ValueError) as exc:
            raise ContractError("SIDECAR_DOCUMENT_INVALID",
                                f"Document {doc['id']!r} cannot encode as finite JSON") from exc
        if envelope_bytes + action_bytes > MAX_UPLOAD_BYTES:
            raise ContractError("PUBLICATION_DOCUMENT_TOO_LARGE",
                                f"Document {doc['id']!r} exceeds the {MAX_UPLOAD_BYTES}-byte upload budget; "
                                "reduce the document payload before replanning")
        added = action_bytes + (2 if batch else 0)
        if size + added > MAX_UPLOAD_BYTES:
            batches.append(batch)
            batch, size, added = [], envelope_bytes, action_bytes
        batch.append(doc)
        size += added
    if batch:
        batches.append(batch)
    return batches


@dataclass(frozen=True)
class PublicationApproval:
    tenant: str
    resource: str
    dataset: str
    owner_approval: str
    security_inspection: str
    replication_approval: str
    budget_approval: str
    write_approval: str


def _status(exc: Exception) -> int | None:
    return get_field(exc, "status_code", get_field(get_field(exc, "response"), "status_code"))


def _denied(operation: str) -> ContractError:
    return ContractError("PUBLICATION_PERMISSION_DENIED", f"Insufficient Search rights for {operation}")


def _is_sdk_client(client: Any) -> bool:
    return type(client).__module__.startswith("azure.")


class AzurePublicationAdapter:
    """Injected index admin and document-client factory, with no credential creation.

    Builds immutable physical indexes only. Descriptor publication is local
    and requires no Search routing mutation.
    """

    def __init__(
        self, index_client: Any, search_client_factory: Any,
        *, approval: PublicationApproval, batch_size: int = 500,
    ):
        if not 1 <= batch_size <= 1000:
            raise ContractError("PUBLICATION_BATCH_INVALID", "Batch size must be 1..1000")
        self.index_client = index_client
        self.search_client_factory = search_client_factory
        self.approval = approval
        self.batch_size = batch_size
        self.confirmed_ids: set[str] = set()
        self.verified_indexes: set[str] = set()
        self.verified_fingerprints: dict[str, str] = {}
        self.index_dimensions: dict[str, int] = {}

    def _approve(self, index: str, *, write: bool = True) -> None:
        a = self.approval
        required = [a.tenant, a.resource, a.dataset, a.owner_approval, a.security_inspection]
        if write:
            required += [a.replication_approval, a.budget_approval, a.write_approval]
        if not all(required):
            raise ContractError("PUBLICATION_APPROVAL_REQUIRED", "Named tenant/service/dataset, owner, security, replication, budget and write approvals required")
        planned_prefix = f"grz-{a.dataset}-"
        if not index.startswith("grz-") or not (index.startswith(planned_prefix) and index[len(planned_prefix):]):
            raise ContractError("PUBLICATION_TARGET_MISMATCH", "Physical generation index must belong to the approved dataset")

    def search_client(self, index: str) -> Any:
        client = self.search_client_factory(index)
        bound = get_field(client, "index_name")
        if bound is not None and bound != index:
            raise ContractError("PUBLICATION_TARGET_MISMATCH", "Document client bound to wrong physical index")
        return client

    def create_generation_index(self, index: str, dimension: int) -> None:
        self._approve(index)
        if not isinstance(dimension, int) or dimension < 1:
            raise ContractError("SOURCE_VECTOR_INVALID", "Positive source vector dimension required")
        schema = load_sidecar_schema()
        try:
            self.index_client.get_index(index)
        except Exception as exc:
            if _status(exc) != 404:
                raise _denied("index inspection") from exc
        else:
            raise ContractError("GENERATION_EXISTS", "Never overwrite an existing generation index; verify exact retries instead")
        definition = generation_index_definition(index, dimension, schema)
        try:
            self.index_client.create_index(sdk_index_model(definition) if _is_sdk_client(self.index_client) else definition)
            observed = self.index_client.get_index(index)
        except Exception as exc:
            raise _denied("index creation/readback") from exc
        check_created_index(observed, definition, dimension, schema["vector_profile"])
        self.index_dimensions[index] = dimension

    def _target_dimension(self, index: str) -> int:
        dimension = self.index_dimensions.get(index)
        if dimension is None:
            try:
                definition = self.index_client.get_index(index)
                vector = next(field for field in get_field(definition, "fields", [])
                              if get_field(field, "name") == "centroid")
                dimension = get_field(vector, "vector_search_dimensions",
                                 get_field(vector, "vectorSearchDimensions"))
            except Exception as exc:
                raise ContractError("SIDECAR_SCHEMA_MISMATCH", "Cannot inspect target index vector dimension") from exc
        if not isinstance(dimension, int) or dimension < 1:
            raise ContractError("SIDECAR_SCHEMA_MISMATCH", "Target index lacks a usable centroid dimension")
        return dimension

    def upload_batch(self, index: str, documents: list[dict[str, Any]]) -> list[dict[str, Any]]:
        self._approve(index)
        if not documents or len(documents) > self.batch_size:
            raise ContractError("PUBLICATION_BATCH_INVALID", "Supply a nonempty bounded document batch")
        prepared = [prepare_document(doc) for doc in documents]
        dimension = self._target_dimension(index)
        for doc in prepared:
            vector = doc.get("centroid") if doc["kind"] == "representative" else None
            if vector is not None and (not isinstance(vector, (list, tuple)) or len(vector) != dimension
                    or any(isinstance(x, bool) or not isinstance(x, (int, float))
                           or not math.isfinite(x) for x in vector)
                    or not any(x != 0 for x in vector)):
                raise ContractError("SIDECAR_DOCUMENT_INVALID", "Vector must be finite, nonzero and match source dimension")
        ids = [doc["id"] for doc in prepared]
        if len(set(ids)) != len(ids) or any(key in self.confirmed_ids for key in ids):
            raise ContractError("SIDECAR_DOCUMENT_INVALID", "Duplicate or previously confirmed document ID")
        batches = _upload_batches(prepared)
        client = self.search_client(index)
        results: dict[str, dict[str, Any]] = {}
        for batch in batches:
            confirmed = self._upload_once(client, batch)
            self.confirmed_ids.update(confirmed)
            results.update(confirmed)
        return [results[key] for key in ids]

    @staticmethod
    def _upload_once(client: Any, prepared: list[dict[str, Any]], key_field: str = "id") -> dict[str, dict[str, Any]]:
        """One attempt per batch: any failure is final and left for the journal and reconcile to resolve."""
        try:
            response = list(client.upload_documents(documents=prepared))
        except Exception as exc:
            raise ContractError("PUBLICATION_UPLOAD_FAILED", "Upload failed; no unconfirmed document may be published") from exc
        returned = [get_field(item, "key") for item in response]
        if len(returned) != len(prepared) or set(returned) != {doc[key_field] for doc in prepared}:
            raise ContractError("PUBLICATION_RESULT_INCOMPLETE", "Batch results must account for each document exactly once")
        results: dict[str, dict[str, Any]] = {}
        for item in response:
            key = get_field(item, "key")
            if get_field(item, "succeeded") is not True:
                status = get_field(item, "status_code", get_field(item, "statusCode"))
                raise ContractError("PUBLICATION_UPLOAD_FAILED", f"Document {key!r} failed indexing (status {status})")
            results[key] = {"key": key, "succeeded": True}
        return results

    def readback(self, index: str) -> list[dict[str, Any]]:
        self._approve(index, write=False)
        client = self.search_client(index)
        last: str | None = None
        result: list[dict[str, Any]] = []
        seen: set[str] = set()
        while True:
            where = None if last is None else f"sort_key gt '{last.replace(chr(39), chr(39) * 2)}'"
            try:
                page = list(client.search(search_text="*", filter=where, order_by=["sort_key asc"],
                                          top=self.batch_size))
            except Exception as exc:
                if _status(exc) == 404:
                    raise ContractError("INDEX_MISSING", "Physical generation index does not exist") from exc
                raise ContractError("PUBLICATION_READBACK_FAILED", "Cannot verify physical generation index") from exc
            if len(page) > self.batch_size:
                raise ContractError("PUBLICATION_READBACK_FAILED", "Readback exceeded bounded page")
            for row in page:
                row = {key: value for key, value in dict(row).items()
                       if not key.startswith("@search.") and value is not None and value != []}
                key, sort_key = row.get("id"), row.get("sort_key")
                if not isinstance(sort_key, str) or not sort_key or (last is not None and sort_key <= last) or key in seen:
                    raise ContractError("PUBLICATION_READBACK_FAILED", "Duplicate, missing or unordered sidecar keys")
                seen.add(key)
                last = sort_key
                require_public(row.get("visibility"))
                if row.get("kind") == "manifest":
                    try:
                        row["payload"] = json.loads(row["payload"])
                    except (TypeError, ValueError) as exc:
                        raise ContractError("PUBLICATION_READBACK_FAILED", "Corrupt manifest payload") from exc
                result.append(row)
            if len(page) < self.batch_size:
                break
        try:
            count = client.get_document_count()
        except Exception as exc:
            if _status(exc) == 404:
                raise ContractError("INDEX_MISSING", "Physical generation index does not exist") from exc
            raise ContractError("PUBLICATION_READBACK_FAILED", "Document count read permission required") from exc
        if count != len(result):
            raise ContractError("READBACK_NOT_SETTLED",
                                f"Search is still indexing: document count {count} differs from keyset scan {len(result)}")
        return result

    def verify(self, index: str, expected: list[dict[str, Any]]) -> None:
        self._approve(index, write=False)
        if not expected or len({doc["id"] for doc in expected}) != len(expected):
            raise ContractError("PUBLICATION_VERIFY_FAILED", "Complete expected document inventory required")
        actual = {doc["id"]: doc for doc in self.readback(index)}
        wanted = {doc["id"]: doc for doc in expected}
        if len(actual) != len(expected) or set(actual) != set(wanted):
            raise ContractError("PUBLICATION_VERIFY_FAILED", "Physical index inventory differs from expected generation")
        for key, original in wanted.items():
            observed = actual[key]
            projected = prepare_document(original)
            if observed.get("kind") == "manifest":
                projected["payload"] = original["payload"]
            for vector_field in ("centroid",):
                if vector_field in projected and vector_field in observed:
                    left, right = projected[vector_field], observed[vector_field]
                    if len(left) != len(right) or any(abs(float(x) - float(y)) > 1e-6 for x, y in zip(left, right)):
                        raise ContractError("PUBLICATION_VERIFY_FAILED", f"Physical vector {key!r} differs from build output")
                    projected[vector_field] = observed[vector_field]
            if observed != projected:
                raise ContractError("PUBLICATION_VERIFY_FAILED", f"Physical document {key!r} differs from build output")
        self.verified_indexes.add(index)
        self.verified_fingerprints[index] = digest(actual)
