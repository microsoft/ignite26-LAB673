"""Read-only, stable keyset export of a frozen public Search index."""

from __future__ import annotations

import hashlib
import math
from collections.abc import Mapping
import time
from copy import deepcopy
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any

from grz_core.contracts import (INPUT_VERSION, VISIBILITY_BASES, CapturedSourceIdentity,
                                ContractError, Source, canonical_json, digest)


def get_field(value: Any, name: str, default: Any = None) -> Any:
    if isinstance(value, dict):
        return value.get(name, default)
    if isinstance(value, Mapping):
        default = value.get(name, default)
    return getattr(value, name, default)


def enum_value(value: Any) -> Any:
    return value.value if isinstance(value, Enum) else value


def _fail(code: str, detail: str) -> None:
    raise ContractError(code, detail)


def validate_compatibility_fields(index: Any) -> None:
    def check(field: Any, nested: bool = False) -> None:
        if get_field(field, "hidden", False) or get_field(field, "retrievable", True) is False:
            _fail("COMPATIBILITY_UNSUPPORTED", "A faithful copy needs every original field retrievable")
        if nested and any(part in str(get_field(field, "name")).lower()
                          for part in ("acl", "permission", "security", "visibility", "principal", "tenant", "group", "access")):
            _fail("SOURCE_SECURITY_UNINSPECTED", "Nested security-bearing fields cannot be mapped by this public-only copy contract")
        for child in get_field(field, "fields", []) or []:
            check(child, True)
    for field in get_field(index, "fields", []):
        check(field)


@dataclass(frozen=True)
class SourceFields:
    key: str
    text: str
    source: str
    vector: str
    scan_key: str
    security_fields: tuple[str, ...] = ()
    # "public-attested" confirms already public content, not anonymous index access.
    # It never overrides a mapped per-document visibility field.
    visibility_basis: str = "per-document"


@dataclass(frozen=True)
class SourceExportApproval:
    tenant: str
    resource: str
    dataset: str
    owner_approval: str
    security_inspection: str
    frozen_evidence: str | None


class AzureSourceAdapter:
    """Requires query and index-read clients for the named *physical* source index.

    Export performs three ordered scans: baseline fingerprint, materialization,
    and post-export fingerprint. This detects changes, but cannot replace the
    producer's write freeze: Azure Search does not provide snapshot isolation.
    """

    def __init__(
        self, search_client: Any, index_client: Any, fields: SourceFields,
        *, approval: SourceExportApproval, page_size: int = 500,
        allow_compatibility_export: bool = False,
        capture_source: bool = False,
    ):
        if not 1 <= page_size <= 1000:
            _fail("SOURCE_PAGE_INVALID", "Page size must be between 1 and 1000")
        self.search_client = search_client
        self.index_client = index_client
        self.fields = fields
        self.approval = approval
        self.page_size = page_size
        self.allow_compatibility_export = allow_compatibility_export
        self.capture_source = capture_source
        self._capture_deadline: float | None = None

    def _preflight(self, source: Source) -> tuple[str, list[str]]:
        source.validate(live=True)
        approval = self.approval
        captured = isinstance(source, CapturedSourceIdentity)
        if captured != self.capture_source or (captured and not self.allow_compatibility_export):
            _fail("CAPTURE_MODE_INVALID", "Captured identities require explicit capture mode and compatibility auto")
        if not all((approval.tenant, approval.resource, approval.dataset,
                    approval.owner_approval, approval.security_inspection)) or (not captured and not approval.frozen_evidence):
            _fail("SOURCE_APPROVAL_REQUIRED", "Named tenant/resource/dataset, owner, security inspection and freeze evidence required")
        if source.owner_approval != approval.owner_approval or (
                not captured and source.frozen_generation != approval.frozen_evidence):
            _fail("SOURCE_APPROVAL_MISMATCH", "Owner approval and producer freeze evidence must match source identity")
        if source.service != approval.resource or source.index != approval.dataset:
            _fail("SOURCE_TARGET_MISMATCH", "Approval must identify the physical source service and index")
        if captured:
            from grz_build.captured_input import LIMITS
            if source.expected_count > LIMITS["documents"] or self.page_size > LIMITS["page_documents"]:
                _fail("CAPTURE_LIMIT_EXCEEDED", "Captured input exceeds the document/page bound")
        bound = get_field(self.search_client, "index_name")
        if bound is not None and bound != source.index:
            _fail("SOURCE_TARGET_MISMATCH", "Search client is bound to a different physical index")
        if len({self.fields.key, self.fields.text, self.fields.source, self.fields.vector}) != 4:
            _fail("SOURCE_FIELDS_INVALID", "Key, text, source and vector fields must be distinct")
        try:
            index = self.index_client.get_index(source.index)
        except Exception as exc:
            raise ContractError("SOURCE_INSPECT_FAILED", "Cannot inspect the named physical source index") from exc
        if get_field(index, "name") != source.index:
            _fail("SOURCE_TARGET_MISMATCH", "Index definition does not match physical source index")
        definitions = {get_field(f, "name"): f for f in get_field(index, "fields", [])}
        if self.allow_compatibility_export:
            validate_compatibility_fields(index)
        requested = [self.fields.key, self.fields.text, self.fields.source, self.fields.vector, self.fields.scan_key]
        if any(not name or name not in definitions for name in requested + list(self.fields.security_fields)):
            _fail("SOURCE_FIELDS_INVALID", "Every mapped field must exist in the source index")
        if not get_field(definitions[self.fields.key], "key", False):
            _fail("SOURCE_KEY_INVALID", "Mapped document ID must be the physical index key")
        scan = definitions[self.fields.scan_key]
        if not get_field(scan, "sortable", False) or (
                not get_field(scan, "filterable", False) and not self.allow_compatibility_export):
            _fail("SOURCE_SCAN_UNSUPPORTED",
                  f"Physical key {self.fields.scan_key!r} has sortable={get_field(scan, 'sortable', False)!r}, "
                  f"filterable={get_field(scan, 'filterable', False)!r}. A sortable physical key is required; "
                  "the pinned native builder also requires filterability for direct batched vector lookups. "
                  "This source is unsupported; no source index was copied or modified")
        if not get_field(scan, "filterable", False) and source.expected_count > 100_000:
            _fail("SOURCE_SCAN_LIMIT", "Compatibility export of a nonfilterable key is limited to 100000 "
                  "documents; no truncation or source writes are permitted")
        for name in requested + list(self.fields.security_fields):
            field = definitions[name]
            if get_field(field, "hidden", False) or get_field(field, "retrievable", True) is False:
                code = "SOURCE_VECTORS_NOT_RETRIEVABLE" if name == self.fields.vector else "SOURCE_FIELDS_INVALID"
                _fail(code, f"Field {name!r} is not retrievable; request a producer-created portable snapshot")
        vector = definitions[self.fields.vector]
        if get_field(vector, "stored", True) is False:
            _fail("SOURCE_VECTORS_NOT_RETRIEVABLE", f"Field {self.fields.vector!r} is not stored; request a producer-created portable snapshot")
        if enum_value(get_field(vector, "type")) != "Collection(Edm.Single)" or get_field(vector, "vector_search_dimensions", get_field(vector, "dimensions")) != source.dimension:
            _fail("SOURCE_VECTOR_INVALID", "Stored vector type or dimension differs from the owner-provided model identity")
        for name in (self.fields.key, self.fields.scan_key, self.fields.text, self.fields.source):
            if enum_value(get_field(definitions[name], "type")) != "Edm.String":
                _fail("SOURCE_FIELDS_INVALID", f"Field {name!r} must be a string")
        if self.fields.scan_key != self.fields.key:
            # Search index metadata cannot prove another field unique. Even when
            # scans detect duplicates, it cannot prove no missing rows.
            _fail("SOURCE_SCAN_UNSUPPORTED", "Continuation must use the unique physical document key")
        suspicious = ("acl", "permission", "security", "visibility", "principal", "tenant", "group", "access")
        security_names = set(self.fields.security_fields)
        attested = self.fields.visibility_basis == "public-attested"
        if self.fields.visibility_basis not in VISIBILITY_BASES:
            _fail("SOURCE_VISIBILITY_INVALID", "--source-visibility must be per-document or public-attested")
        if any(any(part in str(name).lower() for part in suspicious) and name not in security_names
               for name in definitions):
            _fail("SOURCE_SECURITY_UNINSPECTED", "ACL/security-bearing fields must be explicitly mapped and inspected"
                  + ("; the whole-index attestation doesn't cover a per-document field" if attested else ""))
        if len(security_names) != len(self.fields.security_fields):
            _fail("SOURCE_SECURITY_UNINSPECTED", "Duplicate security field mapping")
        if not security_names and not attested:
            _fail("SOURCE_VISIBILITY_UNVERIFIED",
                  f"{source.index} has no mapped visibility field, so GRZ cannot verify that every "
                  "source document is already publicly available")
        return digest([{"name": name, "type": get_field(f, "type"), "key": get_field(f, "key"),
                        "sortable": get_field(f, "sortable"), "filterable": get_field(f, "filterable"),
                        "hidden": get_field(f, "hidden"), "stored": get_field(f, "stored"),
                        "dimensions": get_field(f, "vector_search_dimensions", get_field(f, "dimensions"))}
                       for name, f in sorted(definitions.items())]), requested + list(security_names - set(requested))

    def _count(self, expected: int) -> None:
        try:
            actual = self.search_client.get_document_count()
        except Exception as exc:
            raise ContractError("SOURCE_COUNT_UNAVAILABLE", "Cannot verify full source count") from exc
        if actual != expected:
            _fail("SOURCE_CHANGED", f"Expected {expected} source rows; observed {actual}")

    def _scan(self, source: Source, select: list[str], *, documents: bool = False):
        last = None
        seen: set[str] = set()
        capture_bytes = 0
        index = self.index_client.get_index(source.index)
        key_field = next(f for f in get_field(index, "fields", []) if get_field(f, "name") == self.fields.key)
        offset = not get_field(key_field, "filterable", False)
        if offset and not self.allow_compatibility_export:
            _fail("SOURCE_SCAN_UNSUPPORTED", "Nonfilterable source requires an approved compatibility plan")
        while True:
            self._capture_time()
            continuation = None if last is None or offset else f"{self.fields.scan_key} gt '{last.replace(chr(39), chr(39) * 2)}'"
            try:
                page = list(self.search_client.search(
                    search_text="*", filter=continuation,
                    order_by=[f"{self.fields.scan_key} asc"], select=select,
                    top=self.page_size,
                    **({"skip": len(seen)} if offset else {}),
                ))
            except Exception as exc:
                raise ContractError("SOURCE_SCAN_FAILED", "Cannot complete stable ordered source scan") from exc
            if len(page) > self.page_size:
                _fail("SOURCE_PAGE_INCOMPLETE", "Source returned an overfull bounded page")
            if not page:
                break
            for row in page:
                key = get_field(row, self.fields.key)
                if not isinstance(key, str) or not key.strip() or (last is not None and key <= last) or key in seen:
                    _fail("SOURCE_SCAN_UNSTABLE", "Missing, duplicate or out-of-order source key")
                seen.add(key)
                last = key
                text, ref, vector = (get_field(row, name) for name in (self.fields.text, self.fields.source, self.fields.vector))
                if not isinstance(text, str) or not text.strip() or not isinstance(ref, str) or not ref.strip():
                    _fail("SOURCE_ROW_INVALID", "Source row lacks text or source reference")
                if not isinstance(vector, (list, tuple)) or len(vector) != source.dimension or any(
                    isinstance(x, bool) or not isinstance(x, (int, float)) or not math.isfinite(x) for x in vector
                ) or not any(x != 0 for x in vector):
                    _fail("SOURCE_VECTORS_NOT_RETRIEVABLE", f"Missing/nonfinite/zero vector in {self.fields.vector!r}; request a producer snapshot")
                restricted = [field for field in self.fields.security_fields if get_field(row, field) != "public"]
                if restricted:
                    _fail("VISIBILITY_UNSUPPORTED", f"A document's {restricted[0]!r} isn't 'public'"
                          + ("; the whole-index attestation can't override per-document visibility"
                             if self.fields.visibility_basis == "public-attested" else ""))
                if len(seen) > source.expected_count:
                    _fail("SOURCE_CHANGED", "Scan exceeded expected source count")
                if documents:
                    document = {name: get_field(row, name) for name in select}
                    if self.capture_source:
                        from grz_build.captured_input import LIMITS
                        try:
                            size = len(canonical_json(document).encode("utf-8")) + 1
                        except (TypeError, ValueError) as exc:
                            raise ContractError("CAPTURE_VALUE_UNSUPPORTED", "Captured fields must be losslessly JSON representable") from exc
                        capture_bytes += size
                        if size > LIMITS["document_bytes"] or capture_bytes > LIMITS["total_bytes"]:
                            _fail("CAPTURE_LIMIT_EXCEEDED", "Capture document or total byte bound exceeded")
                        if any(abs(x) > 3.4028234663852886e38 for x in vector) or not any(abs(x) >= 1.401298464324817e-45 / 2 for x in vector):
                            _fail("INPUT_VECTOR_INVALID", "Raw captured vector cannot be stored as float32")
                        self._capture_time()
                    yield document
                else:
                    yield key, text, ref, list(vector)
            if len(page) < self.page_size:
                break
        if len(seen) != source.expected_count:
            _fail("SOURCE_PAGE_INCOMPLETE", "Scan ended before the expected count; producer snapshot required")

    def _capture_time(self) -> None:
        if self._capture_deadline is not None and time.monotonic() >= self._capture_deadline:
            _fail("CAPTURE_LIMIT_EXCEEDED", "Capture duration bound exceeded; no automatic retry")

    def inspect(self, source: Source) -> dict[str, Any]:
        schema_fingerprint, selected = self._preflight(source)
        self._count(source.expected_count)
        return {"source": asdict(source), "fields": asdict(self.fields),
                "schema_fingerprint": schema_fingerprint, "selected_fields": selected,
                "page_size": self.page_size, "snapshot_isolation": False}

    def export_snapshot(self, source: Source, destination: Path) -> Path:
        from grz_build.captured_input import LIMITS, VERSION
        started = datetime.now(timezone.utc).isoformat()
        if self.capture_source:
            self._capture_deadline = time.monotonic() + LIMITS["duration_seconds"]
        preflight = self.inspect(source)
        select = preflight["selected_fields"]
        preserve = self.allow_compatibility_export
        if preserve:
            definition = self.index_client.get_index(source.index)
            select = [get_field(f, "name") for f in get_field(definition, "fields", [])
                      if not get_field(f, "hidden", False) and get_field(f, "retrievable", True) is not False]
        schema = None
        if self.capture_source:
            schema = deepcopy(definition if isinstance(definition, dict) else definition.as_dict())
        def checkpoint() -> None:
            if self.capture_source:
                self._capture_time()
                self._count(source.expected_count)
                definition_now = self.index_client.get_index(source.index)
                wire = definition_now if isinstance(definition_now, dict) else definition_now.as_dict()
                if digest(wire) != digest(schema) or self._preflight(source)[0] != preflight["schema_fingerprint"]:
                    _fail("SOURCE_CHANGED", "Full source schema changed during capture")
        def fingerprint() -> str:
            checkpoint()
            h = hashlib.sha256()
            for row in self._scan(source, select, documents=preserve):
                h.update((canonical_json(row) + "\n").encode("utf-8"))
            checkpoint()
            return h.hexdigest()

        baseline = fingerprint()
        self._count(source.expected_count)
        destination = Path(destination)
        if destination.exists() and any(destination.iterdir()):
            _fail("SNAPSHOT_DESTINATION_NOT_EMPTY", "Export destination must be empty")
        destination.mkdir(parents=True, exist_ok=True, mode=0o700)
        rows_path, vectors_path = destination / "rows.jsonl", destination / "vectors.jsonl"
        originals_path = destination / "source-documents.jsonl"
        try:
            checkpoint()
            with rows_path.open("w", encoding="utf-8", newline="\n") as rows, vectors_path.open("w", encoding="utf-8", newline="\n") as vectors, \
                    originals_path.open("w", encoding="utf-8", newline="\n") as originals:
                h = hashlib.sha256()
                rows_hash = hashlib.sha256()
                vectors_hash = hashlib.sha256()
                originals_hash = hashlib.sha256()
                for record in self._scan(source, select, documents=preserve):
                    if preserve:
                        key, text, ref, vector = (record[name] for name in (
                            self.fields.key, self.fields.text, self.fields.source, self.fields.vector))
                        original_line = canonical_json(record) + "\n"
                        originals.write(original_line)
                        originals_hash.update(original_line.encode("utf-8"))
                    else:
                        key, text, ref, vector = record
                    h.update((canonical_json(record) + "\n").encode("utf-8"))
                    row_line = canonical_json({"chunk_id": key, "text": text, "source": ref, "visibility": "public"}) + "\n"
                    vector_line = canonical_json({"chunk_id": key, "embedding": vector}) + "\n"
                    rows.write(row_line)
                    vectors.write(vector_line)
                    rows_hash.update(row_line.encode("utf-8"))
                    vectors_hash.update(vector_line.encode("utf-8"))
                    if self.capture_source:
                        if rows.tell() + vectors.tell() + originals.tell() > LIMITS["total_bytes"]:
                            _fail("CAPTURE_LIMIT_EXCEEDED", "Total retained capture byte bound exceeded")
            checkpoint()
            if h.hexdigest() != baseline or fingerprint() != baseline:
                _fail("SOURCE_CHANGED", "Source keys, content or vectors changed while exporting")
            self._count(source.expected_count)
            after = self._preflight(source)[0]
            if after != preflight["schema_fingerprint"]:
                _fail("SOURCE_CHANGED", "Source index field capabilities changed while exporting")
            manifest = {
                "version": INPUT_VERSION, "source": asdict(source),
                "rows_file": rows_path.name, "vectors_file": vectors_path.name,
                "rows_sha256": rows_hash.hexdigest(),
                "vectors_sha256": vectors_hash.hexdigest(),
                "provenance_status": "owner-attested",
            }
            if preserve:
                manifest.update(source_documents_file=originals_path.name,
                                source_documents_sha256=originals_hash.hexdigest())
            else:
                originals_path.unlink()
            if self.capture_source:
                completed = datetime.now(timezone.utc).isoformat()
                manifest["version"] = VERSION
                manifest["capture"] = {"version": VERSION, "atomic_snapshot": False, "passes": 3,
                                       "started_at": started, "completed_at": completed, "limits": LIMITS}
                (destination / "source-schema.json").write_text(canonical_json(schema) + "\n", encoding="utf-8")
                (destination / "capture-evidence.json").write_text(canonical_json({
                    "version": VERSION, "atomic_snapshot": False, "passes": 3, "started_at": started,
                    "completed_at": completed, "source": asdict(source), "schema_digest": digest(schema),
                    "inventory_digest": baseline, "key_field": self.fields.key,
                    "source_approval": asdict(self.approval),
                }) + "\n", encoding="utf-8")
                self._capture_time()
            result = destination / "manifest.json"
            result.write_text(canonical_json(manifest) + "\n", encoding="utf-8")
            return result
        except BaseException:
            for path in (rows_path, vectors_path, originals_path, destination / "manifest.json"):
                path.unlink(missing_ok=True)
            raise
        finally:
            self._capture_deadline = None
