"""Integrity of the native producer's partial, potentially ragged community forest."""

from __future__ import annotations

from collections import defaultdict
import math
from typing import Any

from .contracts import ContractError

NATIVE_FOREST_REVISION = "grz-native-poc-v3"


def native_coverage(payload: dict[str, Any]) -> dict[str, Any] | None:
    if payload.get("algorithm_revision") != NATIVE_FOREST_REVISION or "partial_coverage" not in payload:
        return None
    coverage = payload["partial_coverage"]
    if not isinstance(coverage, dict):
        raise ContractError("NATIVE_HIERARCHY_INVALID", "Native coverage must be an object")
    return coverage


def validate_native_forest(representatives: dict[str, dict[str, Any]],
                           members: dict[str, set[str]], evidence: set[str],
                           coverage: dict[str, Any]) -> None:
    def invalid(message: str) -> None:
        raise ContractError("NATIVE_HIERARCHY_INVALID", message)

    fields = ("source_document_count", "observed_node_count", "assigned_node_count",
              "unassigned_source_document_count")
    if any(type(coverage.get(key)) is not int or coverage[key] < 0 for key in fields):
        invalid("Native coverage requires explicit nonnegative integer counts")
    source, observed, assigned, unassigned = (coverage[key] for key in fields)
    ratio = coverage.get("node_coverage")
    if (source != len(evidence) or not 0 < assigned <= observed <= source
            or unassigned != source - assigned or type(ratio) not in (float, int)
            or not math.isfinite(ratio) or not math.isclose(ratio, observed / source, abs_tol=1e-12)):
        invalid("Native source/observed/assigned/unassigned coverage is inconsistent")
    if not representatives or set(members) != set(representatives):
        invalid("Every native community must have memberships")
    children: dict[str, list[str]] = defaultdict(list)
    levels: dict[int, set[str]] = defaultdict(set)
    roots: list[str] = []
    for cid, rep in representatives.items():
        level, parent = rep.get("level"), rep.get("parent_id")
        chunks = members[cid]
        if (type(level) is not int or level < 0 or not chunks or not chunks <= evidence
                or type(rep.get("member_count")) is not int or rep["member_count"] != len(chunks)):
            invalid("Native community level, evidence or member count differs")
        if levels[level] & chunks:
            invalid("A native chunk belongs to multiple communities at one level")
        levels[level].update(chunks)
        if parent is None:
            roots.append(cid)
        elif (parent not in representatives
              or representatives[parent].get("level") != level + 1
              or not chunks <= members[parent]):
            invalid("Native community must nest in its immediate parent")
        else:
            children[parent].append(cid)
    if sorted(levels) != list(range(len(levels))) or not roots:
        invalid("Native forest has missing levels or roots")
    for parent, kids in children.items():
        if set().union(*(members[kid] for kid in kids)) != members[parent]:
            invalid("Native children must exactly partition their parent's members")
    root_chunks: set[str] = set()
    for root in roots:
        if representatives[root]["level"] != max(levels) or root_chunks & members[root]:
            invalid("Native roots must be disjoint coarsest communities")
        root_chunks.update(members[root])
    if len(root_chunks) != assigned or set().union(*levels.values()) != root_chunks:
        invalid("Native memberships differ from the receipt's assigned coverage")


def vector_coverage(representatives: list[dict[str, Any]]) -> dict[str, int]:
    available = sum("centroid" in rep for rep in representatives)
    return {"representative_count": len(representatives), "vector_count": available,
            "missing_vector_count": len(representatives) - available}


def validate_native_manifest(payload: dict[str, Any], representatives: dict[str, dict[str, Any]],
                             members: dict[str, set[str]], evidence: set[str],
                             coverage: dict[str, Any]) -> None:
    validate_native_forest(representatives, members, evidence, coverage)
    if (payload.get("vector_coverage") != vector_coverage(list(representatives.values()))
            or payload.get("levels") != len({rep["level"] for rep in representatives.values()})
            or payload.get("graph_edges") != coverage.get("graph_edge_count")
            or any(payload.get(key) != coverage[key] for key in (
                "source_document_count", "observed_node_count", "assigned_node_count",
                "unassigned_source_document_count", "node_coverage",
            ))):
        raise ContractError("NATIVE_HIERARCHY_INVALID", "Native manifest summaries differ from validated coverage")
