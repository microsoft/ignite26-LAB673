"""Versioned standalone contracts and deterministic identities."""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from typing import Any, Literal

INPUT_VERSION = "grz-input-v1"
BUILD_VERSION = "grz-build-v1"
SIDECAR_VERSION = "grz-sidecar-v2"
DESCRIPTOR_VERSION = "grz-descriptor-v1"
PUBLICATION_VERSION = "grz-publication-v2"
ALGORITHM_REVISION = "grz-native-poc-v3"
PINNED_DEPENDENCIES = {"numpy": "2.5.3", "GRZBuildPoc": "0.1.4-local"}


class ContractError(ValueError):
    def __init__(self, code: str, detail: str):
        super().__init__(f"{code}: {detail}")
        self.code = code


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


SIDECAR_VERSIONS = ("grz-sidecar-v1", SIDECAR_VERSION)
VISIBILITY_BASES = ("per-document", "public-attested")
PUBLIC_CONTENT_CONFIRMATION = (
    "Confirm the source documents are already publicly available. "
    "This confirmation does not make your Search or GRZ indexes public, "
    "enable anonymous access, or change access permissions. "
    "Existing Search authentication and access controls still apply. "
    "This preview cannot preserve different per-document access rules."
)


def attestation_text(index: str) -> str:
    return f"Source index: {index}. {PUBLIC_CONTENT_CONFIRMATION}"


def require_public(visibility: str | None) -> None:
    if visibility != "public":
        raise ContractError("VISIBILITY_UNSUPPORTED",
                            "Only verified already publicly available or synthetic source data is supported; "
                            "this preview cannot preserve different per-document access rules")


@dataclass(frozen=True)
class SourceIdentity:
    service: str
    index: str
    frozen_generation: str
    embedding_model_id: str
    dimension: int
    visibility: str
    expected_count: int
    owner_approval: str | None = None

    def validate(self, live: bool = False) -> None:
        require_public(self.visibility)
        if not all((self.service, self.index, self.frozen_generation, self.embedding_model_id)):
            raise ContractError("SOURCE_IDENTITY_INVALID", "Service, index, freeze evidence and model ID are required")
        if self.dimension < 1 or self.expected_count < 1:
            raise ContractError("SOURCE_IDENTITY_INVALID", "Positive dimension and count are required")
        if live and not self.owner_approval:
            raise ContractError("OWNER_APPROVAL_REQUIRED", "Named source and security inspection approval required")


@dataclass(frozen=True)
class CapturedSourceIdentity:
    service: str
    index: str
    embedding_model_id: str
    dimension: int
    visibility: str
    expected_count: int
    owner_approval: str | None = None
    input_kind: str = "immutable-capture"
    version: str = "grz-captured-source-v1"

    def validate(self, live: bool = False) -> None:
        require_public(self.visibility)
        if (self.input_kind != "immutable-capture" or self.version != "grz-captured-source-v1"
                or any(not isinstance(v, str) or not v.strip()
                       for v in (self.service, self.index, self.embedding_model_id))
                or type(self.dimension) is not int or self.dimension < 1
                or type(self.expected_count) is not int or self.expected_count < 1):
            raise ContractError("SOURCE_IDENTITY_INVALID", "Invalid versioned captured source identity")
        if live and not self.owner_approval:
            raise ContractError("OWNER_APPROVAL_REQUIRED", "Named source and security inspection approval required")


Source = SourceIdentity | CapturedSourceIdentity


def source_identity(fields: dict[str, Any]) -> Source:
    """Keep legacy identities byte-compatible; captured inputs never invent freeze evidence."""
    try:
        source = (CapturedSourceIdentity(**fields) if "input_kind" in fields else SourceIdentity(**fields))
    except (TypeError, ValueError) as exc:
        raise ContractError("SOURCE_IDENTITY_INVALID", "Invalid source identity fields") from exc
    source.validate()
    return source


@dataclass(frozen=True)
class BuildProfile:
    k: int = 10
    candidate_probes: int = 32
    similarity_cutoff: float = 0.0
    cluster_size_limit: int = 1000
    memory_budget_bytes: int = 512_000_000
    seed: int = 42
    strategy: Literal["exact", "hnsw"] = "exact"
    version: str = BUILD_VERSION

    def validate(self) -> None:
        if self.version != BUILD_VERSION or self.k < 1 or self.candidate_probes < self.k:
            raise ContractError("BUILD_PROFILE_INVALID", "Unsupported version, k or probe count")
        if not -1 <= self.similarity_cutoff <= 1 or self.cluster_size_limit < 1 or self.memory_budget_bytes < 1:
            raise ContractError("BUILD_PROFILE_INVALID", "Invalid cutoff, cluster limit or memory budget")


@dataclass(frozen=True)
class Descriptor:
    physical_index: str
    generation_id: str
    source_service: str
    source_index: str
    embedding_model_id: str
    dimension: int
    visibility: str = "public"
    schema_version: str = SIDECAR_VERSION
    version: str = DESCRIPTOR_VERSION
    visibility_basis: str = "per-document"
    source_compatibility: dict[str, Any] | None = None

    def validate(self) -> None:
        require_public(self.visibility)
        if self.visibility_basis not in VISIBILITY_BASES:
            raise ContractError("DESCRIPTOR_INVALID", "Unknown visibility basis")
        if self.version != DESCRIPTOR_VERSION or self.schema_version not in SIDECAR_VERSIONS:
            raise ContractError("SCHEMA_UNSUPPORTED", "Descriptor/schema version mismatch")
        if not all((self.physical_index, self.generation_id, self.source_service, self.source_index, self.embedding_model_id)) or self.dimension < 1:
            raise ContractError("DESCRIPTOR_INVALID", "Incomplete physical index/generation/model identity")
        spec = self.source_compatibility
        if spec is not None:
            if not isinstance(spec, dict):
                raise ContractError("DESCRIPTOR_INVALID", "Invalid compatibility provenance")
            original, native = spec.get("original_source"), spec.get("native_input")
            if (not isinstance(original, dict) or not isinstance(native, dict)
                    or spec.get("version") != "grz-source-compatibility-v1"
                    or spec.get("resolved_mode") != "snapshot-copy" or spec.get("requested_mode") != "auto"
                    or spec.get("direct_handoff") is not False
                    or any(original.get(key) != value for key, value in (
                        ("service", self.source_service), ("index", self.source_index),
                        ("embedding_model_id", self.embedding_model_id), ("dimension", self.dimension)))
                    or native.get("source_index") != spec.get("copy_index")
                    or not str(spec.get("copy_index", "")).startswith("grz-")
                    or spec.get("copy_index") in (self.source_index, self.physical_index)
                    or digest(spec.get("snapshot_manifest")) != spec.get("snapshot_manifest_digest")
                    or any(not isinstance(spec.get(key), str) or len(spec[key]) != 64
                           for key in ("snapshot_digest", "source_documents_sha256"))):
                raise ContractError("DESCRIPTOR_INVALID", "Compatibility provenance differs from authoritative source")
            capture = spec.get("captured_input")
            if capture is not None:
                from grz_build.captured_input import validate_contract
                validate_contract(capture)
                if (original != capture["manifest"]["source"]
                        or spec["snapshot_manifest"] != capture["manifest"]):
                    raise ContractError("DESCRIPTOR_INVALID", "Captured provenance differs from original input")
            elif original.get("input_kind") == "immutable-capture":
                raise ContractError("DESCRIPTOR_INVALID", "Captured source requires retained provenance")

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        if self.source_compatibility is None:
            data.pop("source_compatibility")
        return data


def document_id(generation_id: str, kind: str, stable_id: str) -> str:
    return digest([generation_id, kind, stable_id])


def community_id(generation_id: str, level: int, members: list[str]) -> str:
    if len(members) != len(set(members)):
        raise ContractError("DUPLICATE_MEMBER", "Community IDs require unique members")
    return digest([generation_id, level, sorted(members)])


def require_publication_version(record: dict[str, Any]) -> None:
    if record.get("publication_version") != PUBLICATION_VERSION:
        raise ContractError("LEGACY_PUBLICATION", "This record cannot authorize descriptor publication; create and approve a new alias-free plan. Existing physical descriptors remain readable.")
