"""Read-only consumption of persisted generation documents."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from grz_core.contracts import ContractError


class FixtureReadStore:
    """In-memory sidecar documents behind the generation-scoped ReadStore boundary."""

    def __init__(self, documents: list[dict[str, Any]]):
        self.rows = documents

    def documents(self, physical_index: str, kind: str, generation_id: str) -> list[dict[str, Any]]:
        # Leave mixed generations visible so the service detects invalid persisted records.
        return [row for row in self.rows if row.get("kind") == kind]


def load_fixture_documents(path: Path) -> FixtureReadStore:
    rows = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(rows, list):
        raise ContractError("QUERY_INVALID", "Offline documents must be an array")
    return FixtureReadStore(rows)
