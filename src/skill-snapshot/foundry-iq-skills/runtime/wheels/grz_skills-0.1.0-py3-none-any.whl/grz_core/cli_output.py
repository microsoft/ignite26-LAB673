"""Shared CLI output: a short summary by default, the full JSON with --json, one next step per error."""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Callable

from grz_core.contracts import PUBLIC_CONTENT_CONFIRMATION

NEXT_STEPS = {
    "CAPTURE_MODE_INVALID": "use plan --capture-source only with compatibility auto and approved --capture-coverage, without --frozen-evidence. Existing strict plans remain unchanged.",
    "CAPTURE_COVERAGE_INVALID": "supply an approved grz-capture-coverage-v1 inventory mapping every chunk to exactly the approved original documents and binding the evidence hashes; do not infer missing approval.",
    "CAPTURE_LIMIT_EXCEEDED": "stop and report the exact capture bound; no truncation or automatic retry. A new capture requires a separate explicit request.",
    "CAPTURE_VALUE_UNSUPPORTED": "stop and report the unsupported original value; never omit, coerce or silently replace original evidence.",
    "CAPTURE_ARTIFACT_INVALID": "stop and preserve the retained files/copy. Do not recapture or reconstruct from the live source; a new capture and plan require separate approval.",
    # Operator environment (doctor)
    "PYTHON_TOO_OLD": "use Python 3.12 or newer in the runtime environment, then run doctor again.",
    "AZ_CLI_MISSING": "install the Azure CLI, then run doctor again with --tenant-id.",
    "AZ_SIGNIN_REQUIRED": "sign in to the tenant passed in --tenant-id (az login --tenant ...), then run doctor again.",
    "STATE_DIR_NOT_WRITABLE": "pass a writable --state-dir, or fix permissions on this one.",
    "NAMING_DEPLOYMENT_UNREACHABLE": "check --naming-endpoint and --naming-deployment, and that this identity can read the Azure OpenAI resource.",
    "CLI_ERROR": "run doctor, fix the first failed check, then retry.",
    "MCP_DEPENDENCY_UNAVAILABLE": "prepare the pinned Apps dependencies in the same Python environment used to launch MCP (see CONTRIBUTING.md for source; use the supplied setup launcher for a distribution), then reload grz-skills.",
    # Arguments and inputs
    "INPUT_INVALID": "check the flags and input files named in the error, then retry.",
    "ARGS_INVALID": "pass tool arguments as a JSON object with only the listed properties.",
    "TOOL_NOT_FOUND": "call tools/list to see the available grz_ tools.",
    "RESOURCE_NOT_FOUND": "call resources/list and use one of the advertised GRZ resource URIs.",
    "APP_ASSETS_INVALID": "reinstall the reviewed plugin package; its pinned Apps assets are incomplete or changed.",
    "AUTH_UNSUPPORTED": "set --auth (or GRZ_SEARCH_AUTH) to query-key or entra.",
    "AZURE_LIVE_ARGS_REQUIRED": "add the missing flags listed above.",
    "COMMAND_UNSUPPORTED": "run --help and select a supported command.",
    "DATASET_INVALID": "pass --dataset as a lowercase slug (letters, digits, hyphens).",
    "SEARCH_SERVICE_INVALID": "pass --search-service as the service name, not a URL.",
    "ENDPOINT_INVALID": "pass a canonical https://<service>.search.windows.net origin without credentials, ports, paths, query or fragment.",
    "NAMING_ARGS_REQUIRED": "add the missing naming flags listed above, or drop --naming-deployment.",
    # Dataset fetch (tools/fetch_wiki_revisions.py)
    "MANIFEST_INVALID": "restore the pinned manifest.json from git; don't edit it.",
    "FETCH_FAILED": "check the network, then run the fetch again; it resumes where it stopped.",
    "REVISION_MISMATCH": "delete the output directory and fetch again; if it repeats, the pinned revision is no longer served.",
    "NAMING_ENDPOINT_INVALID": "pass --naming-endpoint as an https:// Azure OpenAI endpoint.",
    "PROFILE_NOT_FOUND": "pass --profile as a JSON file path or one of the bundled profile names.",
    "BUILD_PROFILE_INVALID": "fix the build profile named in the error, then run plan again.",
    "READER_INVALID": "pass --reader as a principal object ID (GUID).",
    "SOURCE_REQUIRED": "pass exactly one of --documents or --endpoint (or GRZ_DOCUMENTS / GRZ_SEARCH_ENDPOINT).",
    "DESCRIPTOR_REQUIRED": "publish a build from this account, or pass --descriptor (or set GRZ_DESCRIPTOR) with the file the builder gave you.",
    "CURRENT_INVALID": "publish the build again, or pass --descriptor (or set GRZ_DESCRIPTOR) to skip the record.",
    "DESCRIPTOR_INVALID": "ask the builder for a fresh descriptor from apply or verify.",
    "QUERY_INVALID": "check the query arguments named in the error, then retry.",
    "SOURCE_SEED_INVALID": "fix the seed JSONL: unique ids with id, text, source, title and a 384-dim vector.",
    "SOURCE_INDEX_INVALID": "name the seed source index with the grz-src- prefix.",
    "SOURCE_VERIFY_FAILED": "re-run tools/seed_source_index.py verify after the seed upload completes.",
    "PAGE_SIZE_INVALID": "pass --page-size between 1 and 1000.",
    "LIMIT_INVALID": "pass a limit between 1 and 100.",
    "CURSOR_INVALID": "drop the cursor and start from the first page.",
    "LEVEL_INVALID": "run status to see the levels this generation has.",
    "LEVEL_NOT_FOUND": "run status to see the levels this generation has.",
    "COMMUNITY_NOT_FOUND": "run list-communities to see valid community IDs.",
    "CHUNK_NOT_FOUND": "run list-members to see chunk IDs in a community.",
    # Source snapshot and inspection
    "INPUT_COUNT_MISMATCH": "re-export the snapshot; its manifest count does not match the files.",
    "INPUT_DUPLICATE_ID": "re-export the snapshot with unique chunk IDs.",
    "INPUT_HASH_MISMATCH": "re-export the snapshot; a file changed after its checksum was recorded.",
    "INPUT_ID_MISMATCH": "re-export the snapshot so rows and vectors share IDs.",
    "INPUT_MALFORMED": "re-export the snapshot as valid JSONL.",
    "INPUT_VECTOR_INVALID": "re-export the snapshot with finite vectors of one dimension.",
    "SOURCE_IDENTITY_INVALID": "re-export the snapshot with a complete source identity.",
    "SOURCE_IDENTITY_MISSING": "run plan and apply again so the source contract is saved.",
    "VISIBILITY_UNSUPPORTED": "use already publicly available or synthetic source data only; map every --security-field and confirm it reads public. This is a content classification, not anonymous index access; the preview cannot preserve different per-document access rules.",
    "OWNER_APPROVAL_REQUIRED": "pass --owner-approval, --frozen-evidence and --security-inspection.",
    "SOURCE_APPROVAL_REQUIRED": "pass --owner-approval, --frozen-evidence and --security-inspection.",
    "SOURCE_APPROVAL_MISMATCH": "pass approvals that name this tenant, service and source index.",
    "SOURCE_TARGET_MISMATCH": "pass approvals that name this Search service and source index.",
    "SOURCE_FIELDS_INVALID": "map distinct, retrievable key, text, source and vector fields.",
    "SOURCE_KEY_INVALID": "pass --key-field as the source index key.",
    "SOURCE_SCAN_UNSUPPORTED": "the unchanged native builder needs a sortable, filterable physical key. New plans may use --source-compatibility auto to disclose and request approval for a faithful copy; off requires direct compatibility. Never copy as an unapproved apply fallback or mutate the original source.",
    "SOURCE_SCAN_LIMIT": "the nonfilterable-source export is bounded to 100000 documents; do not truncate. Use a supported complete source or wait for a qualified native direct-reader capability.",
    "COMPATIBILITY_UNSUPPORTED": "stop and report the exact unsupported source field/export contract; do not omit evidence, re-embed vectors or alter the original source.",
    "COMPATIBILITY_PARITY_FAILED": "run read-only reconcile and inspect the retained copy/source; do not run native or retry writes until the exact original snapshot and approved copy match.",
    "SOURCE_VECTORS_NOT_RETRIEVABLE": "ask the source owner for a Search index with retrievable stored vectors.",
    "SOURCE_SECURITY_UNINSPECTED": "pass --security-field for every security-bearing field.",
    "SOURCE_VISIBILITY_UNVERIFIED": "map the visibility field with --security-field; if the index has none, ask the source owner to confirm before passing --source-visibility public-attested. " + PUBLIC_CONTENT_CONFIRMATION,
    "SOURCE_VISIBILITY_MISMATCH": "pass the same --source-visibility the plan was made with, or re-plan.",
    "SOURCE_VISIBILITY_INVALID": "use --source-visibility public-attested only with --backend azure.",
    "SOURCE_VECTOR_INVALID": "check --vector-field names a vector field with a positive dimension.",
    "NATIVE_SOURCE_INCOMPATIBLE": "review the observed profile, metric, compression and stored-vector settings with the source owner; any compatible replacement requires separate approval and content/visibility verification.",
    "SOURCE_ROW_INVALID": "fix the source rows missing text or a source reference, then run plan again.",
    "SOURCE_PAGE_INVALID": "use a page size between 1 and 1000.",
    "SOURCE_PAGE_INCOMPLETE": "wait until the source is frozen, then run plan again.",
    "SOURCE_SCAN_UNSTABLE": "wait until the source is frozen, then run plan again.",
    "SOURCE_SCAN_FAILED": "run doctor to check reader access, then run plan again.",
    "SOURCE_COUNT_UNAVAILABLE": "run doctor to check reader access on the source index.",
    "SOURCE_INSPECT_FAILED": "run doctor to check reader access on the source index.",
    "SOURCE_CHANGED": "the source changed; wait until it is frozen, then run plan again.",
    "SNAPSHOT_DESTINATION_NOT_EMPTY": "pass an empty export destination.",
    # Build
    "PLAN_CHANGED": "run plan again and approve the new plan ID.",
    "PLAN_ID_MISMATCH": "pass the plan ID printed by the plan you approved.",
    "PLAN_NOT_FOUND": "run plan first, or pass --plan-file.",
    "PLAN_BOUND_FLAG": "drop those flags from apply; to change them, run plan again and approve the new plan ID.",
    "BUDGET_APPROVAL_REQUIRED": "get approval for an --approved-budget-bytes at least the byte count the error reports.",
    "WRITE_CONFIRMATION_REQUIRED": "add --confirm-writes once the plan is approved.",
    "MODEL_APPROVAL_REQUIRED": "add --approve-model-calls once the naming budget is approved.",
    "MODEL_CALLS_NOT_APPROVED": "add --approve-model-calls once the naming budget is approved.",
    "NAMING_BUDGET_REQUIRED": "pass positive --naming-max-calls, --naming-max-tokens, --naming-max-spend-usd and --naming-timeout-seconds.",
    "NAMING_MODEL_UNSUPPORTED": "verify the actual deployment model with doctor; use a model covered by the pinned naming policy, then plan again.",
    "NAMING_POLICY_CHANGED": "create and explicitly approve a new plan using the current naming request policy.",
    "NAMING_PRICING_INVALID": "provide both finite nonnegative per-million-token prices; these are estimates, not Azure billing.",
    "NAMING_USAGE_UNKNOWN": "stop model calls, retain the usage journal and review provider usage before explicitly approving another budget.",
    "NAMING_BUDGET_EXCEEDED": "run reconcile, then plan again with a larger approved naming budget.",
    "NAMING_PROVIDER_REQUIRED": "pass the same --naming-* flags used at plan time.",
    "NAMING_ACCESS_DENIED": "ask for Cognitive Services OpenAI User on the naming resource, then run doctor.",
    "NAMING_DEPLOYMENT_NOT_FOUND": "fix --naming-deployment to a deployment on the Azure OpenAI account, then run doctor again.",
    "NAMING_DEPLOYMENT_NOT_READY": "wait for the naming deployment to finish provisioning, or fix --naming-deployment.",
    "NAMING_MODEL_RETIRED": "deploy a GenerallyAvailable chat model, then plan again with its --naming-deployment and --naming-model.",
    "NAMING_ACCOUNT_NOT_FOUND": "check --subscription-id, --naming-resource-group and the account in --naming-endpoint.",
    "NAMING_ARM_ACCESS_DENIED": "ask for Reader on the Azure OpenAI account, or omit --subscription-id to skip the deployment check.",
    "MEMORY_BUDGET_EXCEEDED": "use a smaller snapshot or a profile with a larger memory budget.",
    "DEPENDENCY_UNAVAILABLE": "reinstall the plugin so its pinned dependencies are present, then run doctor.",
    "AZURE_DEPENDENCY_MISSING": "reinstall the plugin with its azure extra, then run doctor.",
    "GRAPH_INVALID": "re-export the snapshot with unique chunk IDs, then run plan again.",
    "HIERARCHY_INVALID": "use a snapshot with at least one chunk, then run plan again.",
    "CENTROID_INVALID": "re-export the snapshot with nonzero finite vectors.",
    "COMMUNITY_ID_COLLISION": "run plan again with a different profile; report this collision.",
    "DUPLICATE_MEMBER": "run plan again; report this as a build bug.",
    "GENERATION_INVALID": "pass a full 64-character generation ID from apply or generations.",
    "GENERATION_CHANGED": "use the retained physical descriptor explicitly; a same-content generation cannot be rebound to a different plan in this state directory.",
    "GENERATION_EXISTS": "run verify on the existing generation instead of apply.",
    "GENERATION_REQUIRED": "pass --generation-id with the ID that apply or verify printed.",
    "GENERATION_UNKNOWN": "run apply first, or pass --generation-id from its output; if apply stopped, run status and reconcile before any retry.",
    "REPRODUCIBILITY_DEVIATION": "run reconcile; do not publish this generation.",
    "RECONCILE_REQUIRED": "run reconcile, review it, then apply again with --resume-after-reconcile.",
    "RECONCILE_UNSUPPORTED": "run plan again; reconcile needs a plan with a target index.",
    "STATE_INVALID": "point --state-dir at the directory this plan was made in, or run plan again.",
    "PUBLISHER_BUSY": "wait for the other publish to finish, then run status.",
    "BUILD_FAILED": "run grz-build status to see where apply stopped, then reconcile before any retry.",
    "WRITE_FAILED": "run reconcile before any retry; never repeat an unknown-outcome write.",
    "UPLOAD_FAILED": "run reconcile before any retry; never repeat an unknown-outcome write.",
    "READBACK_MISMATCH": "run reconcile, then verify.",
    "READBACK_NOT_SETTLED": "wait a minute for Search to finish indexing, then run reconcile and verify.",
    # Search service and publication
    "TENANT_REQUIRED": "pass --tenant-id for the tenant that owns the Search service.",
    "TENANT_MISMATCH": "sign in to the tenant passed in --tenant-id (az login --tenant ...).",
    "TOKEN_INVALID": "sign in again (az login --tenant ...), then run doctor.",
    "ARM_REQUEST_FAILED": "run doctor, then check --subscription-id and --resource-group.",
    "SEARCH_REQUEST_FAILED": "run doctor to check sign-in and Search reader access.",
    "SEARCH_SERVICE_NOT_FOUND": "check --subscription-id, --resource-group and --search-service.",
    "SEARCH_SERVICE_MISMATCH": "check --search-service names the service in this resource group.",
    "SEARCH_HEADROOM_INSUFFICIENT": "inspect capacity and eligible incomplete staging indexes; completed generations are retained and require separately managed decommissioning.",
    "SEARCH_STATISTICS_INVALID": "obtain complete numeric Search index statistics before replanning.",
    "PLACEMENT_UNSUPPORTED": "publish into the same Search service and tenant as the source.",
    "INDEX_COLLISION": "run plan again; the target index already exists.",
    "INDEX_EXISTS": "run verify on the existing generation instead of apply.",
    "INDEX_INVALID": "use the generation index name printed by plan.",
    "INDEX_MISSING": "run status; the generation index is gone, so run plan and apply again.",
    "SCHEMA_UNSUPPORTED": "upgrade the plugin; this sidecar schema is not supported.",
    "SIDECAR_SCHEMA_UNAVAILABLE": "reinstall the plugin; its sidecar schema file is missing.",
    "SIDECAR_SCHEMA_MISMATCH": "run reconcile; the target index does not match the sidecar schema.",
    "SIDECAR_DOCUMENT_INVALID": "run plan again; report this as a build bug.",
    "DOCUMENT_INVALID": "run plan again; report this as a build bug.",
    "DUPLICATE_DOCUMENT": "run reconcile; never overwrite another document.",
    "VECTOR_DIMENSION_INVALID": "run plan again with a snapshot of one vector dimension.",
    "VECTOR_PROBE_FAILED": "run verify again; if it repeats, run reconcile.",
    "PUBLICATION_APPROVAL_REQUIRED": "pass every approval flag named in the error.",
    "PUBLICATION_BATCH_INVALID": "use an upload batch size between 1 and 1000.",
    "PUBLICATION_DOCUMENT_TOO_LARGE": "reduce the named document payload and create a new plan; do not retry this write.",
    "PUBLICATION_PERMISSION_DENIED": "ask for Search Service Contributor and Search Index Data Contributor, then run doctor.",
    "PUBLICATION_READBACK_FAILED": "run doctor to check reader access, then verify.",
    "PUBLICATION_RESULT_INCOMPLETE": "run reconcile before any retry.",
    "PUBLICATION_TARGET_INVALID": "pass --dataset as a lowercase slug.",
    "PUBLICATION_TARGET_MISMATCH": "run plan again; the target index must belong to --dataset.",
    "PUBLICATION_UPLOAD_FAILED": "run reconcile before any retry; never repeat an unknown-outcome write.",
    "PUBLICATION_VERIFY_FAILED": "run reconcile, then verify.",
    "PUBLICATION_VERIFY_REQUIRED": "run verify first.",
    # Native binary runner and adapters
    "NATIVE_ARTIFACTS_MISSING": "check that the native binary completed and wrote all output artifacts to the artifact directory.",
    "NATIVE_ARTIFACTS_INVALID": "check native build logs and ensure output artifacts are complete and valid.",
    "NATIVE_HIERARCHY_INVALID": "inspect retained native membership and receipt evidence; resolve the source/partition mismatch before requesting a new build approval.",
    "CHUNK_UNASSIGNED": "choose a chunk from list-members; this source chunk was not assigned by the native run and has no community citation.",
    "NATIVE_SOURCE_BINDING_INVALID": "inspect the source and prepare a new plan with its exact vector field, tenant and Search API binding.",
    "NATIVE_REPRESENTATIVE_MISSING": "browse the hierarchy without vectors; naming and vector verification require genuine native representatives for every requested community.",
    "NATIVE_BINARY_NOT_FOUND": "configure GRZ_NATIVE_BINARY or pass --native-binary pointing to the GRZBuildPoc binary for your platform.",
    "NATIVE_PLATFORM_UNSUPPORTED": "use Windows x64, Linux x64/ARM64, or macOS x64/ARM64.",
    "NATIVE_BINARY_CHECKSUM_REQUIRED": "supply a trusted expected_sha256 to NativeRunner for this platform.",
    "NATIVE_BINARY_UNREADABLE": "check that the native binary file is readable.",
    "NATIVE_BINARY_NOT_EXECUTABLE": "grant execute permission to the native binary with chmod +x.",
    "BINARY_HASH_MISMATCH": "ensure GRZBuildPoc matches the approved SHA-256 hash for your platform or update the pinned digest.",
    "CONFIG_INVALID": "fix the invalid configuration keys or values in the native build config.",
    "NATIVE_CLI_PROTOCOL_ERROR": "ensure the native CLI outputs a valid grz-cli-v1 JSON envelope on stdout.",
    "NATIVE_COMMAND_UNSUPPORTED": "use a supported native CLI command (validate, plan, or execute).",
    "NATIVE_EXECUTION_TIMEOUT": "increase native CLI execution timeout or reduce dataset size.",
    "NATIVE_EXECUTION_FAILED": "check native CLI error logs and stderr output for failure details.",
    "UNASSIGNED_CHUNK_LABELED": "verify that post-clustering enrichment only labels assigned communities, not unassigned chunks.",
    "PUBLISH_APPROVAL_REQUIRED": "add --approve-publish once selecting this descriptor locally is approved.",
    "PUBLISH_BINDING_MISMATCH": "use the same resource, dataset, source, vector field and GRZ_HOME as the approved plan.",
    "LEGACY_PUBLICATION": "create and approve a new alias-free plan; use --previous-descriptor to explicitly acknowledge a legacy current record.",
    "PUBLICATION_CHANGED": "select the retained descriptor with grz-consume --descriptor <file> --endpoint <endpoint> --auth entra --tenant-id <tenant>; do not replay stale publish approval.",
    "PUBLICATION_UNCERTAIN": "run reconcile with the build plan ID before any retry; do not roll back automatically.",
    "DESCRIPTOR_CHANGED": "preserve the immutable descriptor and inspect the conflicting file; never overwrite it.",
    "QUERY_ONLY_VIOLATION": "use the descriptor from verify; it binds one physical index.",
    "READ_ACCESS_DENIED": "ask the builder to grant Search Index Data Reader on the sidecar, then run doctor.",
    "READERS_MISSING": "run plan with --reader for each listed reader (or --drop-reader), then apply.",
    "READER_GRANTS_FORBIDDEN": "ask an owner of the Search service to run this, or drop --reader.",
    "READER_GRANTS_UNREADABLE": "ask for rights to read role assignments on the Search service, then plan again.",
    "READER_GRANTS_UNSUPPORTED": "drop --reader and --drop-reader; this backend has no role assignments.",
    "READER_GRANT_FAILED": "run reconcile before any retry.",
    "READER_REVOKE_FAILED": "remove the listed read grant by hand, then run generations.",
    # Retire
    "RETIRE_BINDING_MISMATCH": "run plan-retire again with the same resource, dataset, source and vector field.",
    "RETIRE_PLAN_STALE": "run plan-retire again and approve the new plan.",
    "RETIRE_TARGET_PROTECTED": "run generations; only journal-owned, unexposed incomplete staging indexes qualify. Completed generations are retained.",
    "RETIRE_TARGET_UNKNOWN": "run generations to see the retirable indexes.",
    "RETIRE_DELETE_FAILED": "run generations before any retry; never repeat an unknown-outcome delete.",
    "RETIRE_READBACK_FAILED": "run reconcile with the retire plan to inspect index existence and remaining grants.",
    # Consume
    "SIDECAR_INTEGRITY_FAILED": "ask the builder to run verify on this generation.",
}


def add_json_option(parser: argparse.ArgumentParser, *, subcommand: bool = False) -> None:
    """Accept --json before or after the subcommand; SUPPRESS keeps a subparser from resetting it."""
    parser.add_argument("--json", action="store_true", default=argparse.SUPPRESS if subcommand else False,
                        help="Print the full JSON result instead of a short summary")


def add_version_option(parser: argparse.ArgumentParser) -> None:
    from importlib.metadata import PackageNotFoundError, version
    try:
        installed = version("grz-skills")
    except PackageNotFoundError:
        installed = "unknown"
    parser.add_argument("--version", action="version", version=f"%(prog)s {installed}")


def next_step(code: str) -> str:
    return NEXT_STEPS.get(code) or NEXT_STEPS["CLI_ERROR"]


def error_body(exc: BaseException, default_code: str) -> dict[str, str]:
    """The one blocked envelope: status, UPPER_SNAKE code, message, exactly one next step."""
    code = getattr(exc, "code", None) or default_code
    message = str(exc)
    if message.startswith(f"{code}: "):
        message = message[len(code) + 2:]
    embedded = None
    if "Next step:" in message:
        message, embedded = (part.strip() for part in message.split("Next step:", 1))
    step = getattr(exc, "next_step", None) or embedded or next_step(code)
    return {"status": "blocked", "error_code": code, "error": message, "next_step": step}


def emit(result: Any, as_json: bool, summary: Callable[[Any], str] | None, *, compact: bool = True) -> None:
    if as_json or summary is None:
        print(json.dumps(result, sort_keys=True, ensure_ascii=False, allow_nan=False,
                         separators=(",", ":") if compact else None))
    else:
        print(summary(result))


def emit_error(exc: BaseException, as_json: bool, default_code: str) -> int:
    body = error_body(exc, default_code)
    if as_json:
        print(json.dumps(body, sort_keys=True, ensure_ascii=False), file=sys.stderr)
    else:
        print(f"Blocked. {body['error_code']}: {body['error']}\nNext step: {body['next_step']}", file=sys.stderr)
    return 2


def mb(value: Any) -> str:
    size = int(value or 0)
    return f"{size / 1_000_000:.1f} MB" if size >= 100_000 else f"{size / 1_000:.1f} KB"
