"""The per-user record of the last published build, so browsing needs no paths or environment variables."""

from __future__ import annotations

import json
import os
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from grz_core.contracts import PUBLICATION_VERSION, ContractError, Descriptor, canonical_json, digest


def grz_home() -> Path:
    """GRZ_HOME wins; otherwise a per-user state folder (LOCALAPPDATA on Windows, XDG state elsewhere)."""
    override = os.environ.get("GRZ_HOME")
    if override:
        return Path(override)
    if os.name == "nt" and os.environ.get("LOCALAPPDATA"):
        return Path(os.environ["LOCALAPPDATA"]) / "grz"
    return Path(os.environ.get("XDG_STATE_HOME") or Path.home() / ".local" / "state") / "grz"


def current_path() -> Path:
    return grz_home() / "current.json"


def atomic_json(path: Path, value: Any, *, immutable: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if immutable and path.exists():
        if load_json(path) != value:
            raise ContractError("DESCRIPTOR_CHANGED", f"Refusing to overwrite immutable descriptor {path}")
        return
    fd, name = tempfile.mkstemp(prefix=path.name + "-", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(canonical_json(value))
            stream.flush()
            os.fsync(stream.fileno())
        if immutable:
            # A hard link creates the immutable name only if it is still absent.
            try:
                os.link(name, path)
            except FileExistsError:
                if load_json(path) != value:
                    raise ContractError("DESCRIPTOR_CHANGED", f"Conflicting immutable descriptor {path}")
        else:
            os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise ContractError("CURRENT_INVALID", f"Cannot read JSON record {path}") from exc
    if not isinstance(value, dict):
        raise ContractError("CURRENT_INVALID", f"Expected an object in {path}")
    return value


def load_physical_descriptor(path: Path) -> dict[str, Any]:
    data = load_json(path)
    try:
        Descriptor(**data).validate()
    except (TypeError, ContractError) as exc:
        raise ContractError("DESCRIPTOR_INVALID", f"Invalid physical descriptor {path}") from exc
    return data


@contextmanager
def publication_lock() -> Iterator[None]:
    home = grz_home()
    home.mkdir(parents=True, exist_ok=True)
    lock = home / "publication.lock"
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as exc:
        raise ContractError("PUBLISHER_BUSY", "Another local publisher owns GRZ_HOME; inspect before recovering a stale lock") from exc
    try:
        with os.fdopen(fd, "w") as stream:
            stream.write(str(os.getpid()))
        yield
    finally:
        lock.unlink(missing_ok=True)


def checked_current() -> dict[str, Any] | None:
    pointer = read_current()
    if pointer is not None:
        descriptor = load_physical_descriptor(Path(pointer["descriptor"]))
        if (pointer.get("generation_id") != descriptor["generation_id"]
                or pointer.get("physical_index") != descriptor["physical_index"]
                or pointer.get("descriptor_digest", digest(descriptor)) != digest(descriptor)):
            raise ContractError("CURRENT_INVALID", "Current descriptor no longer matches its saved identity")
    return pointer


def publication_context(binding: dict[str, Any], previous: Path | None = None) -> dict[str, Any]:
    current = checked_current()
    descriptor = load_physical_descriptor(previous) if previous is not None else None
    if current:
        if current.get("publication_version") != PUBLICATION_VERSION and previous is None:
            raise ContractError("LEGACY_PUBLICATION", "Re-plan with --previous-descriptor to acknowledge the legacy current record; no alias lookup or migration is automatic")
        if descriptor is None and current.get("binding") == binding:
            descriptor = load_physical_descriptor(Path(current["descriptor"]))
    if descriptor is not None and (descriptor["source_service"].rstrip("/") != binding["endpoint"].rstrip("/")
                                   or descriptor["source_index"] != binding["source_index"]):
        raise ContractError("PUBLISH_BINDING_MISMATCH", "Previous descriptor belongs to another service or source")
    return {"binding": binding, "expected_current": digest(current),
            "previous_descriptor": descriptor,
            "previous_descriptor_digest": digest(descriptor),
            "home": str(grz_home().resolve())}


def current_record(descriptor: dict[str, Any], *, endpoint: str, auth: str, tenant_id: str,
                   publication: dict[str, Any] | None = None) -> dict[str, Any]:
    Descriptor(**descriptor).validate()
    copy = grz_home() / "descriptors" / f"{descriptor['generation_id']}-{digest(descriptor)[:16]}.json"
    return {"descriptor": str(copy.resolve()), "endpoint": endpoint, "auth": auth, "tenant_id": tenant_id,
            "generation_id": descriptor["generation_id"], "physical_index": descriptor["physical_index"],
            "descriptor_digest": digest(descriptor), **(publication or {})}


def commit_current(descriptor: dict[str, Any], pointer: dict[str, Any]) -> None:
    atomic_json(Path(pointer["descriptor"]), descriptor, immutable=True)
    atomic_json(current_path(), pointer)
    if checked_current() != pointer:
        raise ContractError("PUBLICATION_UNCERTAIN", "Current selection was not confirmed; reconcile before retrying")


def record_current(descriptor: dict[str, Any], *, endpoint: str, auth: str, tenant_id: str) -> dict[str, Any]:
    """Local selection helper. Build uses its journaled intent before commit_current."""
    with publication_lock():
        pointer = current_record(descriptor, endpoint=endpoint, auth=auth, tenant_id=tenant_id)
        commit_current(descriptor, pointer)
        return {**pointer, "pointer": str(current_path().resolve())}


def read_current() -> dict[str, Any] | None:
    path = current_path()
    if not path.is_file():
        return None
    try:
        pointer = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ContractError("CURRENT_INVALID", f"Cannot read the current-build record {path}") from exc
    if not isinstance(pointer, dict) or not all(isinstance(pointer.get(k), str) and pointer[k]
                                                for k in ("descriptor", "endpoint", "auth", "tenant_id")):
        raise ContractError("CURRENT_INVALID", f"The current-build record {path} is incomplete")
    return pointer
