"""Consume reader that rehashes and cross-checks the whole generation on every call.

Used for any ReadStore that is not Azure Search: the offline test/dev fixture
and in-memory test stores. It is only practical for small generations.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from grz_core.adapters import ReadStore
from grz_core.contracts import ContractError, Descriptor
from grz_core.hierarchy import native_coverage, validate_native_manifest

from .checks import (
    KINDS, check_build_health, check_manifest_identity, community_summary, documents_digest, fail,
    has_evidence_text, is_valid_representative, member_summary,
)
from .paging import page_in_memory

Records = dict[str, list[dict[str, Any]]]


class FullGenerationReader:
    verification_scope = "full_generation_readback"

    def __init__(self, store: ReadStore, descriptor: Descriptor):
        self.store = store
        self.descriptor = descriptor
        self._documents_digest: str | None = None

    def _context(self, operation: str, scope: Any) -> list[Any]:
        return [
            self.descriptor.physical_index,
            self.descriptor.generation_id,
            self._documents_digest,
            operation,
            scope,
        ]

    def load(self) -> tuple[dict[str, Any], Records]:
        descriptor = self.descriptor
        records = {
            kind: list(self.store.documents(descriptor.physical_index, kind, descriptor.generation_id))
            for kind in (*KINDS, "manifest")
        }
        if len(records["manifest"]) != 1:
            fail("Exactly one manifest is required")
        self._check_document_identities(records)
        payload = check_manifest_identity(records["manifest"][0].get("payload"), descriptor)
        counts = payload.get("counts")
        if not isinstance(counts, dict) or any(
            type(counts.get(kind)) is not int or counts[kind] != len(records[kind]) for kind in KINDS
        ):
            fail("Manifest record counts are incomplete or incorrect")
        actual = documents_digest([row for kind in KINDS for row in records[kind]])
        if payload.get("documents_digest") != actual:
            fail("Manifest document digest is missing or incorrect")
        check_build_health(payload)
        self._documents_digest = payload["documents_digest"]
        reps = self._index_representatives(records["representative"])
        evidence = self._index_evidence(records["evidence"])
        members, levels = self._index_membership(records["membership"], reps, evidence)
        try:
            coverage = native_coverage(payload)
            if coverage is None:
                self._check_hierarchy(reps, members, levels, evidence)
            else:
                validate_native_manifest(payload, reps, {
                    cid: {row["chunk_id"] for row in rows} for cid, rows in members.items()
                }, set(evidence), coverage)
        except ContractError as exc:
            if exc.code == "SIDECAR_INTEGRITY_FAILED":
                raise
            raise ContractError("SIDECAR_INTEGRITY_FAILED", str(exc)) from exc
        return payload, records

    def _check_document_identities(self, records: Records) -> None:
        ids: set[str] = set()
        sort_keys: set[str] = set()
        for kind, rows in records.items():
            for row in rows:
                if not isinstance(row, dict) or row.get("kind") != kind:
                    fail(f"Incorrect {kind} record kind")
                if row.get("generation_id") != self.descriptor.generation_id:
                    fail("Mixed or missing generation identity")
                if row.get("visibility") != "public":
                    raise ContractError("VISIBILITY_UNSUPPORTED", "All records must be verified public")
                if not isinstance(row.get("id"), str) or not row["id"]:
                    fail("Missing document ID")
                if not isinstance(row.get("sort_key"), str) or not row["sort_key"]:
                    fail("Missing sort key")
                if row["id"] in ids or row["sort_key"] in sort_keys:
                    fail("Duplicate document ID or sort key")
                ids.add(row["id"])
                sort_keys.add(row["sort_key"])

    def _index_representatives(self, rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
        reps: dict[str, dict[str, Any]] = {}
        for row in rows:
            if not is_valid_representative(row, self.descriptor) or row["community_id"] in reps:
                fail("Invalid or duplicate representative")
            reps[row["community_id"]] = row
        if not reps:
            fail("No representative communities")
        return reps

    @staticmethod
    def _index_evidence(rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
        evidence: dict[str, dict[str, Any]] = {}
        for row in rows:
            chunk = row.get("chunk_id")
            if not isinstance(chunk, str) or not chunk or chunk in evidence or not has_evidence_text(row):
                fail("Invalid or duplicate chunk evidence")
            evidence[chunk] = row
        if not evidence:
            fail("No chunk evidence")
        return evidence

    @staticmethod
    def _index_membership(rows: list[dict[str, Any]], reps: dict[str, dict[str, Any]],
                          evidence: dict[str, dict[str, Any]]) -> tuple[Records, dict[int, dict[str, str]]]:
        members: Records = defaultdict(list)
        levels: dict[int, dict[str, str]] = defaultdict(dict)
        pairs: set[tuple[str, str]] = set()
        for row in rows:
            cid, chunk = row.get("community_id"), row.get("chunk_id")
            if cid not in reps or chunk not in evidence or row.get("level") != reps[cid]["level"]:
                fail("Member references absent community/evidence or wrong level")
            if (cid, chunk) in pairs:
                fail("Duplicate community membership")
            pairs.add((cid, chunk))
            members[cid].append(row)
            level = reps[cid]["level"]
            if chunk in levels[level]:
                fail("Chunk assigned to multiple communities at one level")
            levels[level][chunk] = cid
        return members, levels

    @staticmethod
    def _check_hierarchy(reps: dict[str, dict[str, Any]], members: Records,
                         levels: dict[int, dict[str, str]], evidence: dict[str, dict[str, Any]]) -> None:
        for cid, rep in reps.items():
            if len(members[cid]) != rep["member_count"]:
                fail("Community member count mismatch")
        if sorted(levels) != list(range(len(levels))) or any(set(rows) != set(evidence) for rows in levels.values()):
            fail("Every published level must cover all evidenced chunks exactly once")
        for cid, rep in reps.items():
            level = rep["level"]
            parent = rep.get("parent_id")
            if level == max(levels):
                if parent is not None:
                    fail("Coarsest community must not have a parent")
            elif (
                not isinstance(parent, str) or parent not in reps
                or reps[parent]["level"] != level + 1
                or any(levels[level + 1][row["chunk_id"]] != parent for row in members[cid])
            ):
                fail("Community must nest wholly within one immediate parent")

    def manifest_payload(self) -> dict[str, Any]:
        return self.load()[0]

    def representatives_at(self, level: int) -> tuple[list[dict[str, Any]], int]:
        _, records = self.load()
        return [r for r in records["representative"] if r["level"] == level], len(records["evidence"])

    @staticmethod
    def _summary(row: dict[str, Any], records: Records) -> dict[str, Any]:
        children = [r["community_id"] for r in records["representative"] if r.get("parent_id") == row["community_id"]]
        return community_summary(row, children)

    def level_counts(self) -> dict[int, int]:
        _, records = self.load()
        levels = sorted({r["level"] for r in records["representative"]})
        return {level: sum(1 for r in records["representative"] if r["level"] == level) for level in levels}

    def list_communities(self, level: int | None, page_size: int, cursor: str | None) -> dict[str, Any]:
        _, records = self.load()
        rows = [r for r in records["representative"] if level is None or r["level"] == level]
        result = page_in_memory(rows, page_size, cursor, self._context("community", level))
        result["items"] = [self._summary(r, records) for r in result["items"]]
        return result

    def get_community(self, community_id: str, children_page_size: int,
                      children_cursor: str | None) -> dict[str, Any]:
        _, records = self.load()
        row = next((r for r in records["representative"] if r["community_id"] == community_id), None)
        if row is None:
            raise ContractError("COMMUNITY_NOT_FOUND", community_id)
        children = [r for r in records["representative"] if r.get("parent_id") == community_id]
        page = page_in_memory(children, children_page_size, children_cursor,
                              self._context("children", community_id))
        result = community_summary(row, [child["community_id"] for child in page["items"]])
        result["children_next_cursor"] = page["next_cursor"]
        return result

    def list_members(self, community_id: str, page_size: int, cursor: str | None) -> dict[str, Any]:
        _, records = self.load()
        if not any(r["community_id"] == community_id for r in records["representative"]):
            raise ContractError("COMMUNITY_NOT_FOUND", community_id)
        evidence = {r["chunk_id"]: r for r in records["evidence"]}
        rows = [r for r in records["membership"] if r["community_id"] == community_id]
        result = page_in_memory(rows, page_size, cursor, self._context("member", community_id))
        result["items"] = [member_summary(row, evidence[row["chunk_id"]]) for row in result["items"]]
        return result

    def get_chunk(self, chunk_id: str) -> dict[str, Any]:
        _, records = self.load()
        row = next((r for r in records["evidence"] if r["chunk_id"] == chunk_id), None)
        if row is None:
            raise ContractError("CHUNK_NOT_FOUND", chunk_id)
        if not any(member["chunk_id"] == chunk_id for member in records["membership"]):
            raise ContractError("CHUNK_UNASSIGNED", "Source evidence is retained but this chunk has no native community assignment")
        return {"chunk_id": chunk_id, "source_id": row["source_id"], "text": row["text"]}
