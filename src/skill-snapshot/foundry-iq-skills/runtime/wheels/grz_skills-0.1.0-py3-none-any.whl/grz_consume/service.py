"""Validated, generation-bound browsing of the candidate sidecar."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from grz_core.adapters import ReadStore
from grz_core.contracts import ContractError, Descriptor

from .bounded_azure import BoundedAzureReader
from .checks import documents_digest, normalize_document
from .full_generation import FullGenerationReader
from .search_store import AzureSearchReadStore

if TYPE_CHECKING:
    from .native_reader import NativeConsumeReader

__all__ = ["ConsumeService", "documents_digest", "normalize_document"]


def __getattr__(name: str) -> Any:
    if name == "NativeConsumeReader":
        from .native_reader import NativeConsumeReader
        return NativeConsumeReader
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def _check_level(level: Any) -> None:
    if type(level) is not int or level < 0:
        raise ContractError("LEVEL_INVALID", "level must be a nonnegative integer")


BROWSE_TARGET = 20


def browse_level(per_level: dict[int, int]) -> int | None:
    """Pick the level a person can scan at a glance: 10-30 communities, else the count nearest 20."""
    if not per_level:
        return None
    return min(per_level, key=lambda level: (not 10 <= per_level[level] <= 30,
                                             abs(per_level[level] - BROWSE_TARGET), -level))


class ConsumeService:
    """Browse one explicitly bound physical generation without alias privileges.

    The store needs only read access: no alias, index-management, embedding or
    mutation capability. Callers opt into a new descriptor when a publisher cuts
    over the serving alias. Azure Search stores get the bounded reader; any
    other store gets the full-generation reader, which rehashes everything.
    """

    def __init__(self, store: ReadStore, descriptor: Descriptor):
        descriptor.validate()
        self.store = store
        self.descriptor = descriptor
        self._reader: BoundedAzureReader | FullGenerationReader | NativeConsumeReader = (
            store.native_reader(descriptor) if hasattr(store, "native_reader")
            else BoundedAzureReader(store, descriptor) if isinstance(store, AzureSearchReadStore)
            else FullGenerationReader(store, descriptor)
        )

    def status(self) -> dict[str, Any]:
        payload = self._reader.manifest_payload()
        per_level = self._reader.level_counts()
        res = {
            "physical_index": self.descriptor.physical_index,
            "generation_id": self.descriptor.generation_id,
            "schema_version": self.descriptor.schema_version,
            "visibility_basis": self.descriptor.visibility_basis,
            "build_health": payload.get("health", "unknown"),
            "active": "unknown",
            "verified": True,
            "verification_scope": self._reader.verification_scope,
            "communities_per_level": {str(level): count for level, count in per_level.items()},
            "browse_level": browse_level(per_level),
        }
        capture = (self.descriptor.source_compatibility or {}).get("captured_input")
        if capture is not None:
            res["input_kind"] = "immutable-capture"
            res["captured_input"] = {
                "capture_id": capture["capture_id"], "atomic_snapshot": False,
                "observation": {key: capture["manifest"]["capture"][key] for key in ("started_at", "completed_at")},
                "limitation": capture["limitation"],
            }
        for k in (
            "assigned_node_count",
            "unassigned_source_document_count",
            "node_coverage",
            "source_document_count",
            "isolated_node_count",
            "vector_coverage",
        ):
            if k in payload:
                res[k] = payload[k]
        return res

    def browse_level(self) -> int | None:
        """The level to show when the caller doesn't pick one."""
        return browse_level(self._reader.level_counts())

    def representatives_at(self, level: int) -> tuple[list[dict[str, Any]], int]:
        """Validated representatives, with native vectors when present, plus the evidence count."""
        _check_level(level)
        return self._reader.representatives_at(level)

    def list_communities(
        self, level: int | None = None, page_size: int = 100, cursor: str | None = None
    ) -> dict[str, Any]:
        if level is not None:
            _check_level(level)
        return self._reader.list_communities(level, page_size, cursor)

    def get_community(
        self, community_id: str, children_page_size: int = 1000, children_cursor: str | None = None,
    ) -> dict[str, Any]:
        return self._reader.get_community(community_id, children_page_size, children_cursor)

    def list_members(self, community_id: str, page_size: int = 100, cursor: str | None = None) -> dict[str, Any]:
        return self._reader.list_members(community_id, page_size, cursor)

    def get_chunk(self, chunk_id: str) -> dict[str, Any]:
        return self._reader.get_chunk(chunk_id)
