"""One connection config for grz-consume and grz-mcp: flags first, then GRZ_* environment variables."""

from __future__ import annotations

import argparse
import json
import os
from dataclasses import dataclass, replace
from pathlib import Path

from grz_core.contracts import ContractError, Descriptor
from grz_core.current import read_current

from .service import ConsumeService
from .endpoint import validate_search_endpoint

AUTH_MODES = ("query-key", "entra")


@dataclass(frozen=True)
class ConsumeConfig:
    descriptor: Path | None = None
    documents: Path | None = None
    endpoint: str | None = None
    auth: str = "query-key"
    tenant_id: str | None = None
    query_key: str | None = None
    from_current: bool = False


def descriptor_endpoint(descriptor: Descriptor) -> str:
    """Published sidecars live on the source Search service, not the prior binding."""
    service = descriptor.source_service
    return validate_search_endpoint(service if service.startswith("https://") else
                                    f"https://{service}.search.windows.net")


def _env_path(name: str) -> Path | None:
    value = os.environ.get(name)
    return Path(value) if value else None


def add_connection_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--descriptor", type=Path, help="Published physical-index descriptor JSON (or GRZ_DESCRIPTOR)")
    parser.add_argument("--documents", type=Path, help="Offline test/dev only: sidecar document array JSON (or GRZ_DOCUMENTS)")
    parser.add_argument("--endpoint", help="HTTPS Azure Search endpoint (or GRZ_SEARCH_ENDPOINT)")
    parser.add_argument("--auth", choices=AUTH_MODES, help="Azure auth mode (or GRZ_SEARCH_AUTH); query-key reads GRZ_SEARCH_QUERY_KEY")
    parser.add_argument("--tenant-id", help="Tenant ID for --auth entra (or GRZ_TENANT_ID)")


def resolve_config(args: argparse.Namespace) -> ConsumeConfig:
    """Flags, then GRZ_* variables, then the build the user last published. Missing pieces are reported later."""
    auth = getattr(args, "auth", None) or os.environ.get("GRZ_SEARCH_AUTH")
    config = ConsumeConfig(
        descriptor=getattr(args, "descriptor", None) or _env_path("GRZ_DESCRIPTOR"),
        documents=getattr(args, "documents", None) or _env_path("GRZ_DOCUMENTS"),
        endpoint=getattr(args, "endpoint", None) or os.environ.get("GRZ_SEARCH_ENDPOINT"),
        auth=auth or "query-key",
        tenant_id=getattr(args, "tenant_id", None) or os.environ.get("GRZ_TENANT_ID"),
        query_key=getattr(args, "query_key", None),
    )
    if config.descriptor is None and config.documents is None:
        current = read_current()
        if current is not None:
            config = replace(config, descriptor=Path(current["descriptor"]), from_current=True,
                             endpoint=config.endpoint or current["endpoint"], auth=auth or current["auth"],
                             tenant_id=config.tenant_id or current["tenant_id"])
    if config.auth not in AUTH_MODES:
        raise ContractError("AUTH_UNSUPPORTED", f"Auth mode {config.auth!r} is not query-key or entra")
    return config


def load_descriptor(config: ConsumeConfig) -> Descriptor:
    if config.descriptor is None:
        raise ContractError("DESCRIPTOR_REQUIRED", "No build to browse: nothing published from this account, "
                                                   "and no --descriptor or GRZ_DESCRIPTOR")
    try:
        data = json.loads(config.descriptor.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ContractError("DESCRIPTOR_INVALID", f"Cannot read {config.descriptor}: {exc.strerror or exc}") from exc
    except json.JSONDecodeError as exc:
        raise ContractError("DESCRIPTOR_INVALID", f"{config.descriptor} is not JSON") from exc
    if not isinstance(data, dict):
        raise ContractError("DESCRIPTOR_INVALID", f"{config.descriptor} is not a descriptor object")
    try:
        descriptor = Descriptor(**data)
    except TypeError as exc:
        raise ContractError("DESCRIPTOR_INVALID", f"{config.descriptor} has unknown or missing fields") from exc
    descriptor.validate()
    return descriptor


def build_service(config: ConsumeConfig) -> ConsumeService:
    descriptor = load_descriptor(config)
    if bool(config.documents) == bool(config.endpoint):
        raise ContractError("SOURCE_REQUIRED", "Pass exactly one of --documents or --endpoint "
                                               "(or GRZ_DOCUMENTS / GRZ_SEARCH_ENDPOINT)")
    if config.documents is not None:
        if config.query_key:
            raise ContractError("QUERY_INVALID", "--query-key cannot be used with offline documents")
        from grz_core.offline_fixture import load_fixture_documents

        store = load_fixture_documents(config.documents)
    else:
        from .connect import build_store

        store = build_store(descriptor, config.endpoint or "", config.auth, config.tenant_id,  # type: ignore[arg-type]
                            query_key=config.query_key)
    return ConsumeService(store, descriptor)
